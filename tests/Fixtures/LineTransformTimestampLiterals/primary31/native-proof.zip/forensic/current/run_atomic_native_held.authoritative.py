from pathlib import Path
import subprocess,ctypes,json,hashlib,time,threading,datetime,sys,os
from ctypes import wintypes
import argparse
parser=argparse.ArgumentParser();parser.add_argument('--preflight-only',action='store_true');parser.add_argument('--execute-parent-go',action='store_true');args=parser.parse_args();assert not (args.preflight_only and args.execute_parent_go)
execute=args.execute_parent_go
stage=Path('C:\\Users\\IMT\\AppData\\Local\\Codex\\TaskArtifacts\\DiffBeacon\\timestamp-atomic-link-prep-20261012-171720-fbd4c7dd');work=Path('C:\\Users\\IMT\\AppData\\Local\\Temp\\Codex\\DiffBeacon\\timestamp-atomic-link-prep-20261012-171720-fbd4c7dd');keep=stage/('wrapper-execution-proof' if execute else 'wrapper-preflight-proof')
assert hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest()=='955abd94682c5a420c414df94fe640682775bdde4983006ca1244dd487aad15b' and sys.version=='3.14.7 (main, Aug  5 2026, 16:11:39) [MSC v.1944 64 bit (AMD64)]'
assert Path(sys.executable).samefile('C:\\Users\\IMT\\AppData\\Roaming\\uv\\python\\cpython-3.14.7-windows-x86_64-none\\python.exe')
keep.mkdir()

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(n,v):
 with (keep/n).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert sha(stage/'execution-authority.json')=='b5a2165c8cc81533c4a878812a1fafcda413fda045f75fa2380de16e9d8e0c2e'
assert sha(stage/'native_execution_supervisor.authoritative.py')=='39cc2440e13f51610c2eccf5e5dc6c6c0c2d2c697235421e6f4d6b283ebea49c'
if execute:
 go=json.loads((stage/'parent-exact-execution-go.json').read_text());assert go['approved'] and go['authoritySha256'].lower()==sha(stage/'execution-authority.json') and go['supervisorSha256'].lower()==sha(stage/'native_execution_supervisor.authoritative.py')
save('wrapper-started.json',{'utc':utc(),'wrapperPid':os.getpid(),'noResubmission':True,'timeoutSeconds':7200,'parentGoSha256':sha(stage/'parent-exact-execution-go.json') if execute else None})
k=ctypes.WinDLL('kernel32',use_last_error=True)
k.GetProcessTimes.argtypes=[wintypes.HANDLE,ctypes.POINTER(wintypes.FILETIME),ctypes.POINTER(wintypes.FILETIME),ctypes.POINTER(wintypes.FILETIME),ctypes.POINTER(wintypes.FILETIME)];k.GetProcessTimes.restype=wintypes.BOOL
k.GetExitCodeProcess.argtypes=[wintypes.HANDLE,ctypes.POINTER(wintypes.DWORD)];k.GetExitCodeProcess.restype=wintypes.BOOL
k.WaitForSingleObject.argtypes=[wintypes.HANDLE,wintypes.DWORD];k.WaitForSingleObject.restype=wintypes.DWORD
k.CreateJobObjectW.argtypes=[ctypes.c_void_p,wintypes.LPCWSTR];k.CreateJobObjectW.restype=wintypes.HANDLE
k.SetInformationJobObject.argtypes=[wintypes.HANDLE,ctypes.c_int,ctypes.c_void_p,wintypes.DWORD];k.SetInformationJobObject.restype=wintypes.BOOL
k.AssignProcessToJobObject.argtypes=[wintypes.HANDLE,wintypes.HANDLE];k.AssignProcessToJobObject.restype=wintypes.BOOL
k.TerminateJobObject.argtypes=[wintypes.HANDLE,wintypes.UINT];k.TerminateJobObject.restype=wintypes.BOOL
k.TerminateProcess.argtypes=[wintypes.HANDLE,wintypes.UINT];k.TerminateProcess.restype=wintypes.BOOL
k.CloseHandle.argtypes=[wintypes.HANDLE];k.CloseHandle.restype=wintypes.BOOL
class BASIC(ctypes.Structure):_fields_=[('processTime',ctypes.c_longlong),('jobTime',ctypes.c_longlong),('flags',wintypes.DWORD),('minWS',ctypes.c_size_t),('maxWS',ctypes.c_size_t),('active',wintypes.DWORD),('affinity',ctypes.c_size_t),('priority',wintypes.DWORD),('scheduling',wintypes.DWORD)]
class IO(ctypes.Structure):_fields_=[(x,ctypes.c_ulonglong) for x in ['readOps','writeOps','otherOps','readBytes','writeBytes','otherBytes']]
class EXT(ctypes.Structure):_fields_=[('basic',BASIC),('io',IO),('processMemory',ctypes.c_size_t),('jobMemory',ctypes.c_size_t),('peakProcess',ctypes.c_size_t),('peakJob',ctypes.c_size_t)]
def times(h):
 vals=[wintypes.FILETIME() for _ in range(4)];assert k.GetProcessTimes(h,*[ctypes.byref(v) for v in vals]);return {'birth':(vals[0].dwHighDateTime<<32)|vals[0].dwLowDateTime,'exit':(vals[1].dwHighDateTime<<32)|vals[1].dwLowDateTime}
job=k.CreateJobObjectW(None,None);assert job;limits=EXT();limits.basic.flags=0x2000;assert k.SetInformationJobObject(job,9,ctypes.byref(limits),ctypes.sizeof(limits))
command=['C:\\Users\\IMT\\AppData\\Roaming\\uv\\python\\cpython-3.14.7-windows-x86_64-none\\python.exe','-B',str(stage/'native_execution_supervisor.authoritative.py'),str(stage),'--execute-parent-go' if execute else '--preflight-only'];p=subprocess.Popen(command,cwd=work,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=subprocess.CREATE_NEW_PROCESS_GROUP);h=int(p._handle);born=times(h);assigned=bool(k.AssignProcessToJobObject(job,h));channels={};errors=[]
save('supervisor-start.json',{'command':command,'pid':p.pid,'birthFileTime':born['birth'],'heldHandle':h,'jobAssigned':assigned,'launchUtc':utc(),'supervisorSha256':sha(stage/'native_execution_supervisor.authoritative.py'),'timeoutSeconds':7200,'noResubmission':True})
def drain(stream,key):
 path=keep/('supervisor.'+key+'.bin');digest=hashlib.sha256();size=0
 try:
  with path.open('xb') as f:
   while True:
    data=stream.read(65536)
    if not data:break
    f.write(data);size+=len(data);digest.update(data)
  channels[key]={'path':str(path),'size':size,'sha256':digest.hexdigest(),'eof':True,'utc':utc()}
 except Exception as e:errors.append(str(e));channels[key]={'path':str(path),'size':size,'eof':False,'error':str(e)}
threads=[threading.Thread(target=drain,args=(p.stdout,'stdout')),threading.Thread(target=drain,args=(p.stderr,'stderr'))]
for t in threads:t.start()
stop=None;terminated=None;deadline=time.monotonic()+7200
if not assigned:
 assert times(h)['birth']==born['birth'];stop='owned-job-assignment-failed';terminated=bool(k.TerminateProcess(h,125))
while p.poll() is None:
 if stop is None and time.monotonic()>=deadline:
  assert times(h)['birth']==born['birth'];stop='owned-wrapper-timeout-7200';terminated=bool(k.TerminateJobObject(job,124))
  if not terminated:terminated=bool(k.TerminateProcess(h,124))
 time.sleep(.1)
p.wait()
for t in threads:t.join(timeout=15)
if any(t.is_alive() for t in threads):
 assert times(h)['birth']==born['birth'];stop=stop or 'owned-job-eof-timeout';k.TerminateJobObject(job,126)
 for t in threads:t.join(timeout=15)
after=times(h);ec=wintypes.DWORD();assert k.GetExitCodeProcess(h,ctypes.byref(ec));wait=k.WaitForSingleObject(h,0)
receipt={'command':command,'pid':p.pid,'birthFileTime':born['birth'],'osExitFileTime':after['exit'],'heldProcessHandle':h,'birthMatchedAfterExit':born['birth']==after['birth'],'waitResult':wait,'osExitCode':ec.value,'pythonExitCode':p.returncode,'stdout':channels.get('stdout'),'stderr':channels.get('stderr'),'bothEof':all(channels.get(x,{}).get('eof') for x in ['stdout','stderr']),'handleHeldThroughOsExitAndBothEof':wait==0 and all(channels.get(x,{}).get('eof') for x in ['stdout','stderr']),'jobAssigned':assigned,'jobKillOnClose':True,'stopReason':stop,'terminationRequested':terminated,'errors':errors,'finishedUtc':utc(),'noResubmission':True,'authoritativeSourceUnchanged':sha(stage/'native_execution_supervisor.authoritative.py')=='39cc2440e13f51610c2eccf5e5dc6c6c0c2d2c697235421e6f4d6b283ebea49c'}
save('supervisor-held-receipt.json',receipt);k.CloseHandle(job)
