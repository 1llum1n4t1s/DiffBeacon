from pathlib import Path
import ctypes,sys,hashlib
from ctypes import wintypes
kernel=ctypes.WinDLL('kernel32',use_last_error=True)
kernel.CreateFileW.argtypes=[wintypes.LPCWSTR,wintypes.DWORD,wintypes.DWORD,ctypes.c_void_p,wintypes.DWORD,wintypes.DWORD,wintypes.HANDLE];kernel.CreateFileW.restype=wintypes.HANDLE
kernel.CloseHandle.argtypes=[wintypes.HANDLE];kernel.CloseHandle.restype=wintypes.BOOL
class FILEINFO(ctypes.Structure):_fields_=[('attributes',wintypes.DWORD),('created',wintypes.FILETIME),('accessed',wintypes.FILETIME),('written',wintypes.FILETIME),('volumeSerial',wintypes.DWORD),('sizeHigh',wintypes.DWORD),('sizeLow',wintypes.DWORD),('links',wintypes.DWORD),('indexHigh',wintypes.DWORD),('indexLow',wintypes.DWORD)]
kernel.GetFileInformationByHandle.argtypes=[wintypes.HANDLE,ctypes.POINTER(FILEINFO)];kernel.GetFileInformationByHandle.restype=wintypes.BOOL
LOCAL=Path(r'C:\Users\IMT\AppData\Local');PACKAGE=LOCAL/'Packages'/'OpenAI.Codex_2p2nqsd0c76g0'/'LocalCache'/'Local';TEMP=LOCAL/'Temp';REPO=Path(r'C:\Users\IMT\dev\DiffBeacon');CODEX=Path(r'C:\Users\IMT\.codex')
def inside(p,root):return str(p).casefold()==str(root).casefold() or str(p).casefold().startswith(str(root).casefold()+'\\')
def file_id(p):
 h=kernel.CreateFileW(str(p),0,7,None,3,0x02000000,None);assert h not in [None,ctypes.c_void_p(-1).value],('open identity failed',str(p),ctypes.get_last_error())
 try:
  info=FILEINFO();assert kernel.GetFileInformationByHandle(h,ctypes.byref(info));return {'volumeSerial':info.volumeSerial,'fileId':(info.indexHigh<<32)|info.indexLow}
 finally:kernel.CloseHandle(h)
def scope(p):
 assert not inside(p,REPO) and not inside(p,CODEX),('forbidden root',str(p))
 assert not any(x.casefold() in ['artifacts','.codex'] for x in p.parts),('forbidden segment',str(p))
 assert inside(p,LOCAL) or inside(p,TEMP),('outside local/temp',str(p))
def resolve_checked(value,kind):
 logical=Path(value).absolute();canonical=logical.resolve(strict=True);scope(logical);scope(canonical)
 for path in [logical,canonical]:
  for ancestor in [path,*path.parents]:
   assert not ancestor.is_symlink() and not ancestor.is_junction(),('unknown reparse',str(ancestor))
 same=logical.samefile(canonical);assert same
 li=file_id(logical);ci=file_id(canonical);assert li==ci
 alias='identity path'
 if logical!=canonical:
  assert kind=='stage' and inside(logical,LOCAL/'Codex'/'TaskArtifacts'/'DiffBeacon'),('unrecognized logical alias',str(logical))
  expected=PACKAGE/logical.relative_to(LOCAL);assert str(expected).casefold()==str(canonical).casefold(),('unrecognized canonical alias',str(canonical));alias='known OpenAI.Codex LocalCache Local alias, samefile/volumeFileId measured'
 if kind=='stage':assert inside(logical,LOCAL/'Codex'/'TaskArtifacts'/'DiffBeacon')
 if kind=='work':assert inside(logical,TEMP/'Codex'/'DiffBeacon')
 return {'logical':str(logical),'canonical':str(canonical),'samefile':same,'logicalIdentity':li,'canonicalIdentity':ci,'aliasQualification':alias,'logicalAndCanonicalAncestorReparseChecked':True,'kind':kind}
def validate_contract(contract):
 assert hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest()==contract['python']['sha256'] and sys.version==contract['python']['version']
 assert Path(sys.executable).samefile(contract['python']['canonical'])
 measured=[]
 for x in contract['roots']:
  now=resolve_checked(x['logical'],x['kind']);assert now==x,('root identity changed',x['logical']);measured.append(now)
 return measured
