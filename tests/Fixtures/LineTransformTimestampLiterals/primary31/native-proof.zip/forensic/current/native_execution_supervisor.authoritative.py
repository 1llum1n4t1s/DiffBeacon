from pathlib import Path
import sys,json,hashlib,os,re,ctypes,threading,subprocess,time,datetime,argparse
from ctypes import wintypes
from path_identity import validate_contract, file_id, resolve_checked
sys.stdout.reconfigure(encoding="utf-8")
parser=argparse.ArgumentParser();parser.add_argument("stage");parser.add_argument("--preflight-only",action="store_true");parser.add_argument("--execute-parent-go",action="store_true");args=parser.parse_args()
stage=Path(args.stage).resolve();plan=json.loads((stage/"native-execution-plan.authoritative.json").read_text());inputs=json.loads((stage/"source-preflight-manifest.authoritative.json").read_text());casePlan=json.loads((stage/"execution-case-plan.json").read_text());work=Path(plan["work"]).resolve();budget=plan["byteBudget"]
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write_new(path,value):
 with Path(path).open("x",encoding="utf-8",newline="\n") as f:json.dump(value,f,indent=2);f.write("\n")
def byte_count():return sum(p.stat().st_size for root in [stage,work] for p in root.rglob("*") if p.is_file())
def validate_inherited_objects():
 assert len(plan['inheritedObjects'])==35
 parentRef=json.loads((stage/'inherited-parent-proof-reference.json').read_text());assert sha(parentRef['path'])==parentRef['sha256'];parentProof=json.loads(Path(parentRef['path']).read_text());assert parentProof['qualified'] and parentProof['compile35HeldExit0BothEOF'] and not parentProof['nativeExecuted']
 parentRows={x['id']:x for x in parentProof['rows']};assert len(parentRows)==35
 linked=plan['linkCommand']['command'];assert len({x['path'] for x in plan['inheritedObjects']})==35
 for x in plan['inheritedObjects']:
  resolve_checked(x['path'],'work');assert file_id(x['path'])==x['identity'] and sha(x['path'])==x['sha256'] and Path(x['path']).stat().st_size==x['size']
  assert sha(x['source'])==x['sourceSha256'] and sha(x['producerReceipt'])==x['producerReceiptSha256'] and sha(x['producerPlanPath'])==x['producerPlanSha256'] and sha(x['producerEnvironmentPath'])==x['producerEnvironmentSha256']
  receipt=json.loads(Path(x['producerReceipt']).read_text());assert receipt['command']==x['producerCommand'] and receipt['sourceSha256AtLaunch']==x['sourceSha256'] and receipt['osExitCode']==receipt['pythonExitCode']==0 and receipt['birthValidatedOnHeldHandleAfterExit'] and receipt['handleHeldThroughOsExitAndBothEof']
  assert receipt['pid']==x['producerPid'] and receipt['birthFileTime']==x['producerBirthFileTime'] and linked.count(x['path'])==1
  row=parentRows[x['producerId']];assert row['object']==x['path'] and row['objectSha256']==x['sha256'] and row['sourceSha256']==x['sourceSha256'] and row['receiptSha256'].lower()==x['producerReceiptSha256']
  for key in ['stdout','stderr']:assert receipt[key]['eof'] and sha(receipt[key]['path'])==receipt[key]['sha256']
  assert x['producerCompilerSha256']==plan['compilerSha256']
 return True

def preflight():
 validate_inherited_objects()
 entryProof=json.loads((stage/"execution-authority.json").read_text());assert sha(stage/"inherited-parent-proof-reference.json")==entryProof["inheritedParentProofReferenceSha256"]
 contract=json.loads((stage/"path-identity-contract.json").read_text());validatedRoots=validate_contract(contract)
 assert stage.samefile(plan["stage"]) and work.samefile(plan["work"])
 assert not (stage/"execution-started.json").exists() and not (stage/"actual-proof").exists(),"new run was already started; no resubmission"
 assert not list(work.rglob("*.obj")) and not list(work.rglob("*.exe")),"private output is not fresh"
 envPreflight=json.loads((stage/plan["environmentFile"]).read_text())["values"];assert not any(k.upper() in ["CL","_CL_","LINK","_LINK_"] for k in envPreflight)
 entry=json.loads((stage/"execution-authority.json").read_text());assert sha(Path(__file__))==entry["supervisorSha256"]
 for x in inputs["inputReferences"]["references"].values():assert sha(x["path"])==x["sha256"]
 for group in ["originalSourceReferences","freshFiles","licenses","plans"]:
  for x in inputs[group]:
   p=x.get("snapshotPath",x.get("path"));assert sha(p)==x["sha256"]
 for x in inputs["originalPieces"]:assert sha(x["path"])==x["sha256"]
 assert sha(plan["compiler"])==plan["compilerSha256"] and sha(plan["linker"])==plan["linkerSha256"]
 assert len(plan["compileCommands"])==1 and len(plan["nativeRunCommands"])==2
 commands=plan["compileCommands"]+[plan["linkCommand"]]+plan["nativeRunCommands"];assert len({x["id"] for x in commands})==4
 objs=[x["outputs"][0] for x in plan["compileCommands"]];assert len(set(objs))==1 and plan["linkObjectCount"]==36
 names=[Path(x["source"]).name for x in plan["compileCommands"]];assert names==["AtomicCounter.cpp"] and all(plan["linkCommand"]["command"].count(x)==1 for x in objs)
 assert not any(x in names for x in ["FPEnvironment_WIN32.cpp","RWLock_WIN32.cpp","Timezone_WIN32.cpp","pcre2_compile.c","bignum.cc"])
 assert len(casePlan["constructorCases"])==31 and all("unchanged original Timestamp serializer arm result raw UTF8 hex only" in x["requiredCapture"] and "full original ToStringValue result raw UTF8 hex" not in x["requiredCapture"] for x in casePlan["constructorCases"])
 for item in plan["compileCommands"]+[plan["linkCommand"]]:
  for value in item.get("outputs",[]):
   target=Path(value).resolve();assert target.is_relative_to(work) and all(x.lower()!="artifacts" for x in target.parts)
   for parent in target.parents:
    if parent==work.parent:break
    if parent.exists():assert not parent.is_symlink() and not parent.is_junction()
 assert byte_count()<budget
 return {"sourcePinned":True,"compiler1Inherited35Link1Run2Bounded":True,"scopeBoundaryMatches31Contract":True,"bytes":byte_count(),"compilerLinkNativeCommandsExecuted":0}
ready=preflight()
if args.preflight_only or not args.execute_parent_go:
 print(json.dumps({"prepReady":True,"GORequired":True,"preflight":ready,"nativeQualification":False}));sys.exit(0)
# The human/parent must give explicit GO before this flag is used. No auto-resume or retry.
write_new(stage/"execution-started.json",{"startedUtc":utc(),"pid":os.getpid(),"parentGoFlag":True,"noResubmission":True,"planSha256":sha(stage/"native-execution-plan.authoritative.json")})
proofRoot=stage/"actual-proof";proofRoot.mkdir();env=json.loads((stage/plan["environmentFile"]).read_text())["values"];env={k.upper():v for k,v in env.items()}
assert not any(k in env for k in ["CL","_CL_","LINK","_LINK_"])
k=ctypes.WinDLL("kernel32",use_last_error=True)
k.GetProcessTimes.argtypes=[wintypes.HANDLE,ctypes.POINTER(wintypes.FILETIME),ctypes.POINTER(wintypes.FILETIME),ctypes.POINTER(wintypes.FILETIME),ctypes.POINTER(wintypes.FILETIME)];k.GetProcessTimes.restype=wintypes.BOOL
k.GetExitCodeProcess.argtypes=[wintypes.HANDLE,ctypes.POINTER(wintypes.DWORD)];k.GetExitCodeProcess.restype=wintypes.BOOL
k.WaitForSingleObject.argtypes=[wintypes.HANDLE,wintypes.DWORD];k.WaitForSingleObject.restype=wintypes.DWORD
k.CreateJobObjectW.argtypes=[ctypes.c_void_p,wintypes.LPCWSTR];k.CreateJobObjectW.restype=wintypes.HANDLE
k.SetInformationJobObject.argtypes=[wintypes.HANDLE,ctypes.c_int,ctypes.c_void_p,wintypes.DWORD];k.SetInformationJobObject.restype=wintypes.BOOL
k.AssignProcessToJobObject.argtypes=[wintypes.HANDLE,wintypes.HANDLE];k.AssignProcessToJobObject.restype=wintypes.BOOL
k.TerminateJobObject.argtypes=[wintypes.HANDLE,wintypes.UINT];k.TerminateJobObject.restype=wintypes.BOOL
k.TerminateProcess.argtypes=[wintypes.HANDLE,wintypes.UINT];k.TerminateProcess.restype=wintypes.BOOL
k.CloseHandle.argtypes=[wintypes.HANDLE];k.CloseHandle.restype=wintypes.BOOL
class BASIC(ctypes.Structure):_fields_=[("processTime",ctypes.c_longlong),("jobTime",ctypes.c_longlong),("flags",wintypes.DWORD),("minWS",ctypes.c_size_t),("maxWS",ctypes.c_size_t),("active",wintypes.DWORD),("affinity",ctypes.c_size_t),("priority",wintypes.DWORD),("scheduling",wintypes.DWORD)]
class IO(ctypes.Structure):_fields_=[(x,ctypes.c_ulonglong) for x in ["readOps","writeOps","otherOps","readBytes","writeBytes","otherBytes"]]
class EXT(ctypes.Structure):_fields_=[("basic",BASIC),("io",IO),("processMemory",ctypes.c_size_t),("jobMemory",ctypes.c_size_t),("peakProcess",ctypes.c_size_t),("peakJob",ctypes.c_size_t)]
def process_times(h):
 c,e,a,b=[wintypes.FILETIME() for _ in range(4)];assert k.GetProcessTimes(h,ctypes.byref(c),ctypes.byref(e),ctypes.byref(a),ctypes.byref(b));return {"birth":(c.dwHighDateTime<<32)|c.dwLowDateTime,"exit":(e.dwHighDateTime<<32)|e.dwLowDateTime}
seen=set();receipts=[]
def run_command(item):
 assert item["id"] not in seen;seen.add(item["id"])
 if item["id"]=="link-native":validate_inherited_objects()
 beforeBytes=byte_count();assert beforeBytes<budget
 sourceShaAtLaunch=sha(item["source"]) if "source" in item else None
 if "source" in item:assert sourceShaAtLaunch==item["sourceSha256"],"source changed before command"
 job=k.CreateJobObjectW(None,None);assert job;limits=EXT();limits.basic.flags=0x2000
 assert k.SetInformationJobObject(job,9,ctypes.byref(limits),ctypes.sizeof(limits))
 launch=utc();p=subprocess.Popen(item["command"],cwd=work,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=subprocess.CREATE_NEW_PROCESS_GROUP)
 h=int(p._handle);born=process_times(h);assigned=bool(k.AssignProcessToJobObject(job,h));assignmentError=ctypes.get_last_error() if not assigned else 0
 channels={};tooLarge=threading.Event();drainErrors=[]
 def drain(stream,key):
  path=proofRoot/(item["id"]+"."+key+".bin");digest=hashlib.sha256();size=0
  try:
   with path.open("xb") as f:
    while True:
     block=stream.read(65536)
     if not block:break
     f.write(block);digest.update(block);size+=len(block)
     if byte_count()>=budget:tooLarge.set()
   channels[key]={"path":str(path),"size":size,"sha256":digest.hexdigest(),"eof":True,"eofUtc":utc()}
  except Exception as e:drainErrors.append(str(e));channels[key]={"path":str(path),"size":size,"eof":False,"error":str(e)};tooLarge.set()
 ts=[threading.Thread(target=drain,args=(p.stdout,"stdout"),daemon=True),threading.Thread(target=drain,args=(p.stderr,"stderr"),daemon=True)]
 for t in ts:t.start()
 reason=None;termination=None
 if not assigned:
  assert process_times(h)["birth"]==born["birth"],"owned held-process birth changed"
  reason="job-assignment-failed";termination=bool(k.TerminateProcess(h,125))
 deadline=time.monotonic()+item["timeoutSeconds"]
 while p.poll() is None:
  # Main poll watches obj/exe growth even when stdout/stderr produce no chunks.
  overBudget=tooLarge.is_set() or byte_count()>=budget
  if reason is None and (overBudget or time.monotonic()>=deadline):
   assert process_times(h)["birth"]==born["birth"],"owned held-process birth changed"
   reason="byte-budget" if overBudget else "timeout";termination=bool(k.TerminateJobObject(job,124))
   if not termination:termination=bool(k.TerminateProcess(h,124))
  if reason and time.monotonic()>deadline+15:break
  time.sleep(0.05)
 exited=p.poll() is not None
 if exited:p.wait(timeout=1)
 for t in ts:t.join(timeout=10)
 if any(t.is_alive() for t in ts):
  assert process_times(h)["birth"]==born["birth"],"owned held-process birth changed"
  reason=reason or "both-EOF-timeout";k.TerminateJobObject(job,126)
  for t in ts:t.join(timeout=5)
 after=process_times(h);exitValue=wintypes.DWORD();assert k.GetExitCodeProcess(h,ctypes.byref(exitValue));wait=k.WaitForSingleObject(h,0)
 outputs=[]
 for output in item.get("outputs",[]):
  path=Path(output)
  if path.exists():outputs.append({"path":str(path),"size":path.stat().st_size,"sha256":sha(path)})
 receipt={"id":item["id"],"sourcePreflightSha256":sha(stage/"source-preflight-manifest.authoritative.json"),"sourceSha256AtLaunch":sourceShaAtLaunch,"command":item["command"],"pid":p.pid,"birthFileTime":born["birth"],"osExitFileTime":after["exit"],"birthValidatedOnHeldHandleAfterExit":born["birth"]==after["birth"],"handleHeldThroughOsExitAndBothEof":wait==0 and all(channels.get(x,{}).get("eof") for x in ["stdout","stderr"]),"heldProcessHandle":h,"osExitCode":exitValue.value,"pythonExitCode":p.returncode,"waitForSingleObjectResult":wait,"launchUtc":launch,"completedUtc":utc(),"stdout":channels.get("stdout",{"eof":False}),"stderr":channels.get("stderr",{"eof":False}),"jobAssigned":assigned,"jobAssignmentError":assignmentError,"jobKillOnClose":True,"stopReason":reason,"terminationRequested":termination,"drainErrors":drainErrors,"bytesBefore":beforeBytes,"bytesAfter":byte_count(),"outputs":outputs,"noResubmission":True}
 write_new(proofRoot/(item["id"]+".receipt.json"),receipt);receipts.append(receipt);k.CloseHandle(job)
 success=reason is None and assigned and wait==0 and exitValue.value==p.returncode==0 and born["birth"]==after["birth"] and all(receipt[x].get("eof") for x in ["stdout","stderr"]) and not drainErrors and byte_count()<budget
 if not success:raise RuntimeError("command stopped: "+item["id"]+"; reason="+str(reason)+"; OSexit="+str(exitValue.value))
 assert all(Path(x).exists() for x in item.get("outputs",[])),"expected output missing"
 if "source" in item:assert sha(item["source"])==item["sourceSha256"],"source changed during command"
 if item["id"]=="link-native":validate_inherited_objects()
 return receipt
signed=re.compile(r"^-?(?:0|[1-9][0-9]*)$");hexPattern=re.compile(r"^(?:[0-9a-f]{2})*$")
def read_capture(receipt):
 raw=Path(receipt["stdout"]["path"]).read_bytes();rows=[json.loads(x) for x in raw.decode("utf-8").splitlines()];assert len(rows)==31
 for expected,row in zip(casePlan["constructorCases"],rows):
  assert row["id"]==expected["id"] and row["inputUtf8Hex"]==expected["stringUtf8Hex"] and row["scope"]=="original-ctor-evaluate-timestamp-arm-only" and row["sourceCommit"]==plan["commit"]
  assert row["originalNodesSha256"]==next(x["sha256"] for x in inputs["originalSourceReferences"] if x["path"]=="Src/FilterEngine/FilterExpressionNodes.cpp")
  assert row["processId"]==receipt["pid"] and int(row["processBirthFileTimeDecimal"])==receipt["birthFileTime"] and row["contextLineIndex"]==-1 and row["contextPointersNull"] is True
  for key in ["timestampArmSerializedUtf8Hex","errorMessageHex","exceptionTypeNameHex","userLocaleUtf8Hex","timezoneStandardNameUtf8Hex"]:assert hexPattern.fullmatch(row[key])
  for key in ["clockBeforeEpochMicrosecondsInt64Decimal","clockAfterEpochMicrosecondsInt64Decimal"]:assert signed.fullmatch(row[key]) and -(1<<63)<=int(row[key])<(1<<63)
  assert row["status"] in ["ok","error"]
  if row["epochMicrosecondsInt64Decimal"]:assert signed.fullmatch(row["epochMicrosecondsInt64Decimal"]) and -(1<<63)<=int(row["epochMicrosecondsInt64Decimal"])<(1<<63)
  if row["status"]=="ok":assert row["valueTypeIndex"]==4 and row["rawType"]=="Poco::Timestamp" and signed.fullmatch(row["epochMicrosecondsInt64Decimal"]) and -(1<<63)<=int(row["epochMicrosecondsInt64Decimal"])<(1<<63) and row["errorPhase"]==""
  else:assert row["errorPhase"] in ["constructor","evaluate","timestamp-arm-serialization"] and row["exceptionTypeNameHex"]
 return rows
try:
 for item in plan["compileCommands"]:run_command(item)
 run_command(plan["linkCommand"]);exeSha=sha(plan["nativeExecutable"]);captures=[]
 for item in plan["nativeRunCommands"]:
  assert sha(plan["nativeExecutable"])==exeSha;receipt=run_command(item);rows=read_capture(receipt);captures.append((receipt,rows));write_new(proofRoot/(item["id"]+".validated.json"),{"receiptId":receipt["id"],"exeSha256":exeSha,"caseCount":31,"scope":plan["scope"],"rows":rows,"goldenGenerated":False})
 assert captures[0][0]["pid"]!=captures[1][0]["pid"] or captures[0][0]["birthFileTime"]!=captures[1][0]["birthFileTime"]
 semantic=["id","inputUtf8Hex","sourceCommit","originalNodesSha256","status","errorPhase","exceptionTypeNameHex","errorMessageHex","valueTypeIndex","rawType","epochMicrosecondsInt64Decimal","timestampArmSerializedUtf8Hex"]
 ambient=["userLcid","userLocaleUtf8Hex","timezoneState","timezoneStandardNameUtf8Hex","timezoneBiasMinutes","timezoneStandardBiasMinutes","timezoneDaylightBiasMinutes","pocoTimezoneTzdSeconds"]
 sameAmbient=all(all(a[k]==b[k] for k in ambient) for a,b in zip(captures[0][1],captures[1][1]));sameSemantic=all(all(a[k]==b[k] for k in semantic) for a,b in zip(captures[0][1],captures[1][1]))
 comparison={"sameAmbient":sameAmbient,"sameSemantic":sameSemantic,"liveClockPidBirthExcludedFromSemanticCompare":True,"status":"match" if sameAmbient and sameSemantic else "incomparable-ambient-change" if not sameAmbient else "semantic-mismatch","goldenGenerated":False}
 write_new(proofRoot/"two-native-runs-comparison.json",comparison)
 if sameAmbient and not sameSemantic:raise RuntimeError("Native two-run semantic mismatch under stable recorded ambient profile")
 write_new(stage/"execution-result.json",{"status":"completed" if sameAmbient else "completed-captures-ambient-change","compilerCount":35,"linkCount":1,"nativeRunCount":2,"bytes":byte_count(),"exeSha256":exeSha,"scope":plan["scope"],"comparison":comparison,"goldenGenerated":False,"wholeParserAstFilearmQualification":False,"receipts":[r["id"] for r in receipts]});print("bounded Native execution completed; raw proof retained, no golden generated")
except Exception as e:
 write_new(stage/"execution-result.json",{"status":"stopped-no-resubmission","error":str(e),"receipts":[r["id"] for r in receipts],"bytes":byte_count(),"scope":plan["scope"],"goldenGenerated":False});print("STOP: "+str(e));sys.exit(1)
