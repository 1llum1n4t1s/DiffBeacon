/**
 * @file  FilterExpressionNodes.h
 *
 * @brief Filter expression evaluation classes.
 */
#pragma once

#include "FilterParser.h"
#include <string>
#include <map>
#include <variant>
#include <vector>
#include <Poco/Timestamp.h>

namespace Poco { class RegularExpression; }
struct FilterExpression;
struct FileContentRef;
class DIFFITEM;
struct ValueType2;
using ValueType = std::variant<std::monostate, bool, double, int64_t, Poco::Timestamp, std::shared_ptr<Poco::RegularExpression>, std::string, std::shared_ptr<FileContentRef>, std::shared_ptr<std::vector<ValueType2>>>;
struct ValueType2 { ValueType value; };
struct FilterEvalContext;

std::string ToStringValue(const ValueType& val);

struct ExprNode
{
	virtual ~ExprNode() { }
	virtual ExprNode* Optimize() { return this; }
	virtual ValueType Evaluate(const FilterEvalContext& ectxt) const = 0;
};

struct NotNode : public ExprNode
{
	NotNode(ExprNode* e) : right(e) { }
	virtual ~NotNode()
	{
		delete right;
	}
	ExprNode* Optimize() override;
	ValueType Evaluate(const FilterEvalContext& ectxt) const override;
	ExprNode* right;
};

struct OrNode : public ExprNode
{
	OrNode(ExprNode* l, ExprNode* r) : left(l), right(r) { }
	virtual ~OrNode()
	{
		delete left;
		delete right;
	}
	ExprNode* Optimize() override;
	ValueType Evaluate(const FilterEvalContext& ectxt) const override;
	ExprNode* left;
	ExprNode* right;
};

struct AndNode : public ExprNode
{
	AndNode(ExprNode* l, ExprNode* r) : left(l), right(r) { }
	virtual ~AndNode()
	{
		delete left;
		delete right;
	}
	ExprNode* Optimize() override;
	ValueType Evaluate(const FilterEvalContext& ectxt) const override;
	ExprNode* left;
	ExprNode* right;
};

struct BinaryOpNode : public ExprNode
{
	BinaryOpNode(const FilterExpression* c, ExprNode* l, int o, ExprNode* r) : ctxt(c), left(l), right(r), op(o) { }
	virtual ~BinaryOpNode()
	{
		delete left;
		delete right;
	}
	ExprNode* Optimize() override;
	ValueType Evaluate(const FilterEvalContext& ectxt) const override;
	const FilterExpression* ctxt;
	int op;
	ExprNode* left;
	ExprNode* right;
};

struct NegateNode : public ExprNode
{
	NegateNode(ExprNode* r) : right(r) { }
	virtual ~NegateNode()
	{
		delete right;
	}
	ExprNode* Optimize() override;
	ValueType Evaluate(const FilterEvalContext& ectxt) const override;
	ExprNode* right;
};

struct FieldNode : public ExprNode
{
	FieldNode(const FilterExpression* ctxt, const std::string& v);
	ValueType Evaluate(const FilterEvalContext& ectxt) const override;
	const FilterExpression* ctxt;
	std::string field;
	std::function<ValueType(const FilterEvalContext& ectxt)> func;
};

struct FunctionNode : public ExprNode
{
	FunctionNode(const FilterExpression* ctxt, const std::string& name, std::vector<ExprNode*>* args);
	virtual ~FunctionNode();
	ExprNode* Optimize() override;
	ValueType Evaluate(const FilterEvalContext& ectxt) const override;
	void SetPropFunc(int side, int prefixlen, bool singlePane);
	void SetLineAtFunc(int side, int prefixlen, bool singlePane, ValueType(*func)(int, const FilterEvalContext&, std::vector<ExprNode*>*));
	void SetColumnFunc(int side, int prefixlen, bool singlePane);
	void SetColumnRangeFunc(int side, int prefixlen, bool singlePane);
	void SetColumnAtFunc(int side, int prefixlen, bool singlePane, ValueType(*func)(int, const FilterEvalContext&, std::vector<ExprNode*>*));
	const FilterExpression* ctxt;
	std::string functionName;
	std::vector<ExprNode*>* args;
	std::function<ValueType(const FilterEvalContext& ectxt, std::vector<ExprNode*>* args)> func;
};

struct BoolLiteral : public ExprNode
{
	BoolLiteral(bool v) : value(v) { }
	inline ValueType Evaluate(const FilterEvalContext& ectxt) const override { return value; }
	bool value;
};

/**
 * @brief Represents a null/undefined value literal.
 * 
 * Supports both `none` and `undefined` keywords in filter expressions.
 * Evaluates to std::monostate{} for null value handling.
 * 
 * Usage examples:
 *   property == none
 *   field != undefined
 */
struct NoneLiteral : public ExprNode
{
	NoneLiteral() { }
	inline ValueType Evaluate(const FilterEvalContext& ectxt) const override { return std::monostate{}; }
};

struct DoubleLiteral : public ExprNode
{
	DoubleLiteral(double v) : value(v) { }
	inline ValueType Evaluate(const FilterEvalContext& ectxt) const override { return value; }
	double value;
};

struct IntLiteral : public ExprNode
{
	IntLiteral(int64_t v) : value(v) { }
	inline ValueType Evaluate(const FilterEvalContext& ectxt) const override { return value; }
	int64_t value;
};

struct StringLiteral : public ExprNode
{
	StringLiteral(const std::string& v) : value(v) { }
	inline ValueType Evaluate(const FilterEvalContext& ectxt) const override { return value; }
	std::string value;
};

struct SizeLiteral : public ExprNode
{
	SizeLiteral(const std::string& v);
	inline ValueType Evaluate(const FilterEvalContext& ectxt) const override { return value; }
	int64_t value;
};

struct DateTimeLiteral : public ExprNode
{
	DateTimeLiteral(const std::string& v);
	DateTimeLiteral(const Poco::Timestamp& v) : value(v) { }
	inline ValueType Evaluate(const FilterEvalContext& ectxt) const override { return value; }
	Poco::Timestamp value;
};

struct DurationLiteral : public ExprNode
{
	DurationLiteral(const std::string& v);
	inline ValueType Evaluate(const FilterEvalContext& ectxt) const override { return value; }
	int64_t value;
};

struct VersionLiteral : public ExprNode
{
	VersionLiteral(const std::string& v);
	inline ValueType Evaluate(const FilterEvalContext& ectxt) const override { return value; }
	int64_t value;
};

struct RegularExpressionLiteral : public ExprNode
{
	RegularExpressionLiteral(const std::string& v, bool caseSensitive = false);
	inline ValueType Evaluate(const FilterEvalContext& ectxt) const override { return value; }
	std::shared_ptr<Poco::RegularExpression> value;
};

struct ArrayLiteral : public ExprNode
{
	ArrayLiteral(std::shared_ptr<std::vector<ValueType2>> v) : value(v) {}
	inline ValueType Evaluate(const FilterEvalContext& ectxt) const override { return value; }
	std::shared_ptr<std::vector<ValueType2>> value;
};
