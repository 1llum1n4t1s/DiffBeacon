"""Read existing captures only. No compiler/native oracle is started."""
import hashlib,importlib.util,json,os,pathlib,sys
P=pathlib.Path(__file__).resolve().parent;R=P.parent
sha=lambda b:hashlib.sha256(b).hexdigest()
spec=importlib.util.spec_from_file_location('frozen_executor',R/'execute-native.py');executor=importlib.util.module_from_spec(spec);spec.loader.exec_module(executor)
assert executor.verified_inputs()=='a78ac48b729592446f7c4b9aca1ff48bb267089bffa161e6b302a2b414451c0b'
env=dict(os.environ,TEMP=str(R/'temp'),TMP=str(R/'temp'),PYTHONDONTWRITEBYTECODE='1')
receipt,out,err=executor.child([sys.executable,'-E','-B','-X','utf8',str(P/'check-post-capture.py'),'--native',str(R/'run1/native.ndjson'),str(R/'run2/native.ndjson')],R,env,120,P/'strict-reader')
receipt.update(readerOnlyRevision=True,nativeRecompileExecuted=False,postReaderChainSha256=sha((P/'post-reader-chain.json').read_bytes()),nativeInputFreezeSha256=executor.verified_inputs(),readerSha256=sha((P/'check-post-capture.py').read_bytes()),pythonSha256=sha(pathlib.Path(sys.executable).read_bytes()))
executor.js(P/'strict-reader.receipt.json',receipt)
if receipt['exitCode'] or receipt['timeout'] or err:raise RuntimeError('post-capture reader failed: '+err.decode(errors='replace'))
print(out.decode(),end='')
