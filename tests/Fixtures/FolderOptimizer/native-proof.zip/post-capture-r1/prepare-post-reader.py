"""Freeze a post-capture metadata erratum; never changes native compile inputs."""
import hashlib,json,pathlib
P=pathlib.Path(__file__).resolve().parent;R=P.parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(n,x):(P/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
FROZEN='a78ac48b729592446f7c4b9aca1ff48bb267089bffa161e6b302a2b414451c0b'
assert sha((R/'prepared-inputs.json').read_bytes())==FROZEN
for n,h in json.loads((R/'prepared-inputs.json').read_bytes())['inputSha256'].items():assert sha((R/n).read_bytes())==h,n
cpp=(R/'source/Src/FilterEngine/FilterExpressionNodes.cpp').read_bytes()
def span(a,b):
 start=cpp.index(a.encode());end=cpp.index(b.encode(),start)
 return dict(startByte=start,endByte=end,startLine=cpp[:start].count(b'\n')+1,endLine=cpp[:end].count(b'\n')+1,sha256=sha(cpp[start:end]))
spans=[span('static auto lineAt(', 'static auto lineOffsetAt('),span('void FunctionNode::SetLineAtFunc(', 'void FunctionNode::SetColumnFunc('),span('AttrParseResult ParseAttributeName(', '\nstruct FieldInfo'),span('FunctionNode::FunctionNode(', 'FunctionNode::~FunctionNode(')]
cases=json.loads((R/'cases.json').read_bytes());byid={c['id']:c for c in cases}
ids=['c03916','c03917','c03922','c03923']
side=pathlib.Path(r'D:\Codex\DiffBeacon\folder-side-functions-20261023-native01')
sidefiles=['cases.json','source-manifest.json','run1-golden.ndjson','run2-golden.ndjson','proof-receipt.json']
assert sha((side/'native-proof.zip').read_bytes())=='ee9f13ee2e8de0684b376d97f8a1467a2591919f9ab1e0d2a49693c5c4e54a21'
assert sha((side/'FilterExpressionNodes.cpp.original').read_bytes())==sha(cpp)
write('expectation-erratum.json',dict(reason='Original SetLineAtFunc wraps every unprefixed side into an array; lineAt provider-null guard returns None per side before evaluating its argument. The original nooptKind=none metadata was wrong.',nativeInputFreezeSha256=FROZEN,cases=[dict(id=i,dirs=byid[i]['dirs'],caseSensitive=byid[i]['caseSensitive'],originalExpectation=byid[i]['expect'],correctedValue=dict(kind='array',items=[dict(kind='none') for _ in range(byid[i]['dirs'])])) for i in ids],source=dict(path='source/Src/FilterEngine/FilterExpressionNodes.cpp',commit='6780924ba35f7f55af0f6f14dd302561175830a6',sha256=sha(cpp),blob=hashlib.sha1(b'blob '+str(len(cpp)).encode()+b'\0'+cpp).hexdigest(),spans=spans,reason='prefixlen==0 and !singlePane loops i=0..dirs-1; lineAt returns monostate when provider=null; prefixed middlelineat uses the scalar branch.'),sideOracle=dict(root=str(side),proofSha256=sha((side/'native-proof.zip').read_bytes()),files={n:sha((side/n).read_bytes()) for n in sidefiles},samples=[dict(id='c00008',dirs=2,name='lineat'),dict(id='c00612',dirs=2,name='middlelineat'),dict(id='c01216',dirs=3,name='lineat'),dict(id='c01820',dirs=3,name='middlelineat')]),nativeTruthNotRedefined=True,caseAstLabelCountAndCompileInputsUnchanged=True))
native=['prepared-inputs.json','cases.json','cases.inc','source-manifest.json','check-prepared.py','execute-native.py','native-build-plan.json','native-reader.stdout','native-reader.stderr']
for run in ['run1','run2']:
 native += [run+'/'+n for n in ['compile-receipt.json','pcre-process.receipt.json','cpp-process.receipt.json','link-process.receipt.json','native.receipt.json','native.ndjson','native.stdout','native.stderr','reference.exe','pcre-process.stdout','pcre-process.stderr','cpp-process.stdout','cpp-process.stderr','link-process.stdout','link-process.stderr']]
post=['check-post-capture.py','prepare-post-reader.py','read-post-capture.py','expectation-erratum.json']
write('post-reader-chain.json',dict(nativeInputFreezeSha256=FROZEN,postReaderInputs={n:sha((P/n).read_bytes()) for n in post},nativeEvidence={n:sha((R/n).read_bytes()) for n in native},priorReaderFailurePreserved=True,readerOnlyRevision=True,nativeRecompileExecuted=False))
print(json.dumps(dict(postReaderChainSha256=sha((P/'post-reader-chain.json').read_bytes()),erratumSha256=sha((P/'expectation-erratum.json').read_bytes()),sourceSpans=spans)))
