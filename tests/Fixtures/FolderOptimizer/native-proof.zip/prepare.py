"""Preparation only. Never starts a compiler, native executable, dotnet or app."""
import hashlib, io, json, pathlib, re, zipfile
R=pathlib.Path(__file__).resolve().parent
REPO=pathlib.Path(r'D:\Dev\DiffBeacon')
COMMIT='6780924ba35f7f55af0f6f14dd302561175830a6'
sha=lambda b:hashlib.sha256(b).hexdigest()
blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def put(p,b):
    p=R/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b if isinstance(b,bytes) else b.encode())
def js(p,v):put(p,json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def safe_entry(n):
    p=pathlib.PurePosixPath(n)
    assert not p.is_absolute() and '..' not in p.parts and ':' not in n
    return p

def main():
    # Sources are already present, fixed native fixtures. No download or dependency install.
    outer=REPO/'tests/Fixtures/LineTransformTimestampClockFunctions/clock-native-portable-v1.zip'
    fixed=json.loads((REPO/'tests/Fixtures/LineTransformTimestampClockFunctions/fixed-manifest.json').read_bytes())
    # The portable proof stores content-addressed raw source; verify the address before use.
    with zipfile.ZipFile(outer) as z:
        address='044a1e0497951b740f6b11185592983ed9fee921df8d98ca4ffd987031eaa120'
        raw=z.read('blobs/'+address);assert sha(raw)==address
        clock_manifest=json.loads(z.read('manifest.json'))
    deps=[];sources={}
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        for n in z.namelist():
            if n.endswith('/') or not (n.startswith('source/') or n.startswith('licenses/')):continue
            safe_entry(n);b=z.read(n);put(n,b)
            deps.append(dict(file=n,size=len(b),sha256=sha(b),blob=blob(b),containerSha256=address))
            if n.startswith('source/'):sources[n[7:]]=b
    # Confirm primary sources against the independent fixed reference manifest.
    primary=json.loads((REPO/'tests/Fixtures/LineTransformAggregates/source-manifest.json').read_bytes())
    for e in primary['sources']:
        if e['path'] in sources:
            assert sha(sources[e['path']])==e['sha256']
            assert blob(sources[e['path']])==e['blob']
    extra=json.loads((REPO/'tests/Fixtures/LineTransformReplaceLists/source-manifest.json').read_bytes())
    for e in extra['sources']:
        if e['path'].startswith('Src/FilterEngine/ReplaceList.'):
            b=(REPO/'tests/Fixtures/LineTransformReplaceLists/additional-original'/e['path']).read_bytes()
            assert sha(b)==e['sha256'] and blob(b)==e['blob'];sources[e['path']]=b;put('source/'+e['path'],b)
            deps.append(dict(file='source/'+e['path'],size=len(b),sha256=sha(b),blob=blob(b),origin='LineTransformReplaceLists/additional-original'))
    spans=[]
    def span(file,path,a,b):
        data=sources[path];out=data[a:b];put(file,out)
        spans.append(dict(file=file,path='source/'+path,startByte=a,endByte=b,startLine=data[:a].count(b'\n')+1,endLine=data[:b].count(b'\n')+1,sha256=sha(out)))
    def lines(file,path,a,b):
        ll=sources[path].splitlines(keepends=True);span(file,path,sum(map(len,ll[:a-1])),sum(map(len,ll[:b])))
    cp='Src/FilterEngine/FilterExpressionNodes.cpp';hp='Src/FilterEngine/FilterExpressionNodes.h'
    span('nodes.inc',hp,sources[hp].index(b'namespace Poco'),len(sources[hp]))
    # All six override bodies, their common literal helpers and runtime operator implementation.
    lines('operators.inc',cp,34,883)
    lines('parse-datetime.inc',cp,1012,1047)
    lines('column-helpers.inc',cp,1408,1441)
    lines('attribute-name.inc',cp,1507,1518)
    lines('scalar-lifting.inc',cp,1684,1704)
    lines('numeric-array-string.inc',cp,1706,1912)
    lines('replace-list-functions.inc',cp,1952,2091)
    lines('clock-calendar.inc',cp,2093,2143)
    lines('to-string-regexreplace.inc',cp,2315,2397)
    lines('if.inc',cp,2433,2442)
    lines('choose.inc',cp,2471,2492)
    lines('conversions.inc',cp,2519,2661)
    lines('string-regex-observers.inc',cp,2923,3220)
    lines('side-functions.inc',cp,3877,4219)
    lines('function-constructor.inc',cp,4221,4295)
    lines('function-optimize-evaluate.inc',cp,4297,4493)
    lines('literal-constructors.inc',cp,4495,len(sources[cp].splitlines()))
    lines('utf8-lead.inc','Src/Common/unicoder.cpp',112,122)
    lines('utf8-length.inc','Src/Common/unicoder.cpp',145,156)
    lines('function-info.inc',cp,3778,3785)
    lines('function-lookup.inc',cp,3860,3875)
    # Keep exact selected rows and source locations; do not impersonate absent functions.
    functions=['abs','array','at','choose','if','now','today','strlen','substr','strcount','strfind','replace','regexreplace','regexcount','regexfind','regexextract','replacewithlist','regexreplacewithlist','startofweek','startofmonth','startofyear','tonumber','toint','todouble','todatetime']
    rows=[]
    for name in functions:
        pat=rb'\t\{"'+name.encode()+rb'",[^\n]+\n';m=re.search(pat,sources[cp]);assert m,name
        file='table-row-'+name+'.inc';span(file,cp,*m.span());rows.append(file)
    put('selected-table.inc','static constexpr FunctionInfo functionTable[] = {\n'+''.join('#include "'+f+'"\n' for f in sorted(rows))+'};\n')
    # Original parser reduction action is executable, but grammar/tokenization is NOT run.
    parser='Src/FilterEngine/FilterParser.y';p=sources[parser]
    a=p.index(b'\tif (pCtx->errorCode == 0 && pCtx->optimize)');b=p.index(b'\n}\n',a)
    span('parser-reduction-action.inc',parser,a,b)
    loader='Src/FilterEngine/ReplaceList.cpp';p=sources[loader]
    span('original-loaders.inc',loader,p.index(b'static void GuessEncoding'),p.rfind(b'}'))
    # Localized date fallback remains the original function, including Windows OLE calls.
    loc='Src/Common/locality.cpp';p=sources[loc];m=re.search(rb'bool ParseDateTime\(',p)
    if m:
        a=m.start();depth=0;start=p.index(b'{',a);end=None
        for i in range(start,len(p)):
            if p[i]==123:depth+=1
            if p[i]==125:
                depth-=1
                if depth==0:end=i+1;break
        span('locality-parse.inc',loc,a,end)
    # Reuse the same transparent UTF-8 file adapter as loader oracle; bodies above are original.
    text=(REPO/'tests/Fixtures/LineTransformReplaceLists/adapter.cpp').read_bytes()
    a=text.index(b'#define _T(x) x');b=text.index(b'namespace ReplaceList{',a)
    reader=text[a:b]
    marker=b'bool OpenReadOnly(const String& p){'
    assert reader.count(marker)==1
    reader=reader.replace(marker,marker+b'ioReads.push_back(p);')
    put('utf8-loader-adapter.inc',reader)
    put('dependency-compile-reference.json',json.dumps(dict(objects=clock_manifest['objects'],note='Historical commands only; no existing object reused or execution performed.'),indent=2)+'\n')
    js('source-manifest.json',dict(commit=COMMIT,sourceArchiveSha256=address,outerArchiveSha256=sha(outer.read_bytes()),files=deps,extractions=spans,selectedFunctions=functions,sourceBodiesUnmodified=True,parserScope='original reduction action only; no original lexer/full parser execution',loaderScope='original LoadList/LoadRegexList/LoadListImpl; shared existing UTF-8 reader adapter, not original UniMemFile/encoding/env'))
    # Exact source guard inventory is independently derived by check-prepared.py.
    optimize=sources[cp].splitlines()[4296:4488]
    guards=[dict(line=4297+i,text=x.decode()) for i,x in enumerate(optimize) if x.startswith(b'\tif (functionName') or x.startswith(b'\tif ((functionName') or x.startswith(b'\tif (functionName.compare')]
    regions=[('literal-helpers',160,252),('OrNode',254,269),('AndNode',285,300),('NotNode',316,329),('constant-fold',339,556),('BinaryOpNode',559,579),('NegateNode',854,873),('FunctionNode',4297,4488)]
    conditionals=[]
    for owner,a,b in regions:
        for line in range(a,b+1):
            text=sources[cp].splitlines()[line-1].decode()
            if re.match(r'\s*(?:if\s*\(|else if\s*\(|catch\s*\()',text):conditionals.append(dict(owner=owner,line=line,text=text))
    js('rule-inventory.json',dict(defaultIdentity=dict(path=hp,line=29),overrides=['OrNode','AndNode','NotNode','BinaryOpNode','NegateNode','FunctionNode'],functionTopLevelGuards=guards,functionTopLevelGuardCount=len(guards),allOptimizerConditionalSites=conditionals,conditionalSiteCount=len(conditionals),countMeaning='syntactic conditional/catch sites, not a count of distinct semantic contracts',defensiveNullChildren='source included unchanged; null-child malformed native AST runtime is outside corpus',binaryFamilies=['Double/Double','IntLike/IntLike','String/String','Bool/Bool','DateTime/DateTime','DateTime/IntLike'],intLikeLiteralClasses=['IntLiteral','SizeLiteral','DurationLiteral','VersionLiteral'],arrayConstantClasses=['IntLiteral','DoubleLiteral','StringLiteral','DateTimeLiteral','BoolLiteral'],notFolded=['Double/IntLike mixed','None','nested Array','Size/Duration/Version inside Array unless child transforms to primitive literal'],allChildrenBeforeParent=True,defaultOptimizationAndExplicitOpt='same Optimize call; grammar directives not parsed'))
    js('status.json',dict(stage='SOURCE_PREPARED_NOT_COMPILED',nativeCompileExecuted=False,nativeChildExecuted=False,fullParserExecuted=False))
    print(json.dumps(dict(prepared=True,sourceFiles=len(deps),sourceSpans=len(spans),optimizerOverrideCount=6,functionGuardCount=len(guards),nativeCompileExecuted=False)))
if __name__=='__main__':main()
