"""Execution is a separate stage: requires explicit --execute after timing work completes."""
import argparse,ctypes,datetime,hashlib,json,os,pathlib,subprocess,sys
R=pathlib.Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def js(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf8')
def verified_inputs():
 m=json.loads((R/'prepared-inputs.json').read_bytes())
 for p,h in m['inputSha256'].items():assert sha((R/p).read_bytes())==h,p
 return sha((R/'prepared-inputs.json').read_bytes())
class FT(ctypes.Structure):_fields_=[('low',ctypes.c_uint32),('high',ctypes.c_uint32)]
class THREADENTRY32(ctypes.Structure):
 _fields_=[('dwSize',ctypes.c_uint32),('cntUsage',ctypes.c_uint32),('th32ThreadID',ctypes.c_uint32),('th32OwnerProcessID',ctypes.c_uint32),('tpBasePri',ctypes.c_long),('tpDeltaPri',ctypes.c_long),('dwFlags',ctypes.c_uint32)]
def windows_api():
 k=ctypes.WinDLL('kernel32',use_last_error=True);H=ctypes.c_void_p;D=ctypes.c_uint32;B=ctypes.c_int
 signatures={'CreateJobObjectW':([H,ctypes.c_wchar_p],H),'AssignProcessToJobObject':([H,H],B),'GetProcessTimes':([H,*([ctypes.POINTER(FT)]*4)],B),'TerminateJobObject':([H,D],B),'CloseHandle':([H],B),'WaitForSingleObject':([H,D],D),'CreateToolhelp32Snapshot':([D,D],H),'Thread32First':([H,ctypes.POINTER(THREADENTRY32)],B),'Thread32Next':([H,ctypes.POINTER(THREADENTRY32)],B),'OpenThread':([D,B,D],H),'ResumeThread':([H],D)}
 for name,(args,result) in signatures.items():
  f=getattr(k,name);f.argtypes=args;f.restype=result
 return k
def api_bool(k,name,*args):
 ctypes.set_last_error(0)
 if not getattr(k,name)(*args):raise ctypes.WinError(ctypes.get_last_error(),name)
def close_handle(k,h):
 if h is not None:api_bool(k,'CloseHandle',h)
def suspended_primary_thread(k,pid):
 ctypes.set_last_error(0);snapshot=k.CreateToolhelp32Snapshot(0x00000004,0) # TH32CS_SNAPTHREAD
 if snapshot in (None,ctypes.c_void_p(-1).value):raise ctypes.WinError(ctypes.get_last_error(),'CreateToolhelp32Snapshot')
 try:
  entry=THREADENTRY32();entry.dwSize=ctypes.sizeof(entry);found=[]
  ctypes.set_last_error(0)
  if not k.Thread32First(snapshot,ctypes.byref(entry)):raise ctypes.WinError(ctypes.get_last_error(),'Thread32First')
  while True:
   if entry.th32OwnerProcessID==pid:found.append(entry.th32ThreadID)
   entry.dwSize=ctypes.sizeof(entry);ctypes.set_last_error(0)
   if not k.Thread32Next(snapshot,ctypes.byref(entry)):
    error=ctypes.get_last_error()
    if error!=18:raise ctypes.WinError(error,'Thread32Next') # ERROR_NO_MORE_FILES
    break
  if len(found)!=1:raise RuntimeError('Suspended process must have exactly one initial thread: '+repr(found))
  ctypes.set_last_error(0);thread=k.OpenThread(0x0002,False,found[0]) # THREAD_SUSPEND_RESUME
  if not thread:raise ctypes.WinError(ctypes.get_last_error(),'OpenThread')
  return thread,found[0]
 finally:close_handle(k,snapshot)
def child(command,cwd,env,timeout,prefix):
 started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 kernel=windows_api();ctypes.set_last_error(0);job=kernel.CreateJobObjectW(None,None)
 if not job:raise ctypes.WinError(ctypes.get_last_error(),'CreateJobObjectW')
 p=None;thread=None;assigned=False;resumed=False
 try:
  # Popen closes its initial thread handle. While still suspended, obtain that
  # sole thread through Toolhelp; no cmd/cl user code can create descendants yet.
  p=subprocess.Popen(command,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=0x00000004|subprocess.CREATE_NO_WINDOW) # CREATE_SUSPENDED
  handle=ctypes.c_void_p(int(p._handle));times=[FT() for _ in range(4)]
  api_bool(kernel,'AssignProcessToJobObject',job,handle);assigned=True
  api_bool(kernel,'GetProcessTimes',handle,*map(ctypes.byref,times))
  birth=(times[0].high<<32)|times[0].low
  thread,threadId=suspended_primary_thread(kernel,p.pid)
  ctypes.set_last_error(0);previous=kernel.ResumeThread(thread)
  if previous==0xffffffff:raise ctypes.WinError(ctypes.get_last_error(),'ResumeThread')
  if previous!=1:raise RuntimeError('Unexpected initial suspend count: '+str(previous))
  resumed=True;close_handle(kernel,thread);thread=None;timed=False
  try:out,err=p.communicate(timeout=timeout)
  except subprocess.TimeoutExpired:
   timed=True;api_bool(kernel,'TerminateJobObject',job,1);out,err=p.communicate(timeout=15)
  ctypes.set_last_error(0);wait=kernel.WaitForSingleObject(handle,0)
  if wait==0xffffffff:raise ctypes.WinError(ctypes.get_last_error(),'WaitForSingleObject')
  if wait!=0:raise RuntimeError('Process handle not signaled after pipe EOF: '+str(wait))
  signaled=True;api_bool(kernel,'TerminateJobObject',job,0)
 except BaseException as failure:
  # Assignment failure leaves the primary thread suspended. Never resume it.
  if p is not None:
   if assigned:api_bool(kernel,'TerminateJobObject',job,1)
   else:p.kill() # Popen TerminateProcess checks its WinAPI result.
   p.communicate(timeout=15)
  js(prefix.with_suffix('.bootstrap-failure.json'),dict(command=command,pid=p.pid if p else None,createdSuspended=p is not None,jobAssignedBeforeResume=assigned,resumeSucceeded=resumed,error=str(failure),winerror=getattr(failure,'winerror',None)))
  raise
 finally:
  cleanup_errors=[]
  for owned in [thread,job]:
   try:close_handle(kernel,owned)
   except OSError as error:cleanup_errors.append(error)
  if p is not None and p.returncode is not None:
   try:p._handle.Close() # CPython Handle.Close invokes checked _winapi.CloseHandle.
   except OSError as error:cleanup_errors.append(error)
  if cleanup_errors:raise ExceptionGroup('WinAPI handle cleanup failed',cleanup_errors)
 prefix.with_suffix('.stdout').write_bytes(out);prefix.with_suffix('.stderr').write_bytes(err)
 evidence=dict(command=command,pid=p.pid,birthFileTime=birth,heldProcessHandleSignaled=signaled,createdSuspended=True,jobAssignedBeforeResume=assigned,initialThreadId=threadId,resumePreviousSuspendCount=previous,resumeSucceeded=resumed,startedUtc=started,endedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exitCode=p.returncode,timeout=timed,stdoutEof=True,stderrEof=True,stdoutPath=str(prefix.with_suffix('.stdout')),stderrPath=str(prefix.with_suffix('.stderr')),stdoutSha256=sha(out),stderrSha256=sha(err),TEMP=env['TEMP'],TMP=env['TMP'])
 js(prefix.with_suffix('.receipt.json'),evidence)
 return evidence,out,err
def main():
 a=argparse.ArgumentParser();a.add_argument('--execute',action='store_true');opts=a.parse_args()
 if not opts.execute:raise SystemExit('Preparation only. --execute is required, and must wait for parent scheduling authorization.')
 frozen=verified_inputs();plan=json.loads((R/'native-build-plan.json').read_bytes())
 assert sha(pathlib.Path(plan['compiler']).read_bytes())==plan['compilerSha256']
 assert sha(pathlib.Path(plan['vcvars']).read_bytes())==plan['vcvarsSha256']
 allpaths=[]
 for run in plan['runs']:
  out=R/run['run'];exe=pathlib.Path(run['executable'])
  assert not exe.exists() and not list((out/'obj').glob('*.obj')),'fresh compile required; no overwrite/delete permitted'
  env=dict(os.environ,TEMP=run['TEMP'],TMP=run['TMP'],PYTHONDONTWRITEBYTECODE='1')
  records=[]
  for command in run['commands']:
   record,stdout,stderr=child(['cmd.exe','/d','/c',str(R/command['wrapper'])],R,env,600,out/(command['stage']+'-process'))
   records.append(record)
   if record['exitCode'] or record['timeout'] or not record['heldProcessHandleSignaled']:
    js(pathlib.Path(run['compileReceipt']),dict(exitCode=record['exitCode'],timeout=record['timeout'],stdoutEof=True,stderrEof=True,preparedInputsSha256=frozen,commands=records))
    raise RuntimeError('compile failed: '+run['run']+'/'+command['stage'])
   assert verified_inputs()==frozen
  js(pathlib.Path(run['compileReceipt']),dict(exitCode=0,timeout=False,stdoutEof=True,stderrEof=True,preparedInputsSha256=frozen,compilerSha256=plan['compilerSha256'],commands=records,executableSha256=sha(exe.read_bytes())))
  receipt,stdout,stderr=child([str(exe)],R,env,120,out/'native')
  target=pathlib.Path(run['stdout']);target.write_bytes(stdout)
  receipt.update(executable=str(exe),executableSha256=sha(exe.read_bytes()),compileReceipt=run['compileReceipt'],preparedInputsSha256=frozen,casesSha256=sha((R/'cases.json').read_bytes()))
  js(target.with_suffix('.receipt.json'),receipt)
  assert receipt['exitCode']==0 and not receipt['timeout'] and receipt['heldProcessHandleSignaled'] and not stderr
  assert verified_inputs()==frozen
  allpaths.append(str(target))
 check=subprocess.run([sys.executable,'-E','-B','-X','utf8',str(R/'check-prepared.py'),'--native',*allpaths],cwd=R,env=env,capture_output=True,timeout=120)
 (R/'native-reader.stdout').write_bytes(check.stdout);(R/'native-reader.stderr').write_bytes(check.stderr)
 assert check.returncode==0,check.stderr.decode(errors='replace')
 print(check.stdout.decode(),end='')
if __name__=='__main__':main()
