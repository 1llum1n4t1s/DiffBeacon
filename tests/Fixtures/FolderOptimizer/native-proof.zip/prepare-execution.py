"""Write two immutable independent compile plans. Does not execute either plan."""
import hashlib,json,pathlib
R=pathlib.Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
compiler=pathlib.Path(r'C:\Program Files\Microsoft Visual Studio\18\Community\VC\Tools\MSVC\14.51.36231\bin\Hostx64\x64\cl.exe')
vcvars=pathlib.Path(r'C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat')
assert compiler.is_file() and vcvars.is_file()
sdk_env=json.loads((R/'sdk-environment.json').read_bytes())
assert pathlib.Path(r'C:\Program Files (x86)\Windows Kits\10\Include\10.0.28000.0\ucrt\ctype.h').is_file()
environment_lines=''.join('set "'+key+'='+sdk_env[key]+'"\n' for key in ['INCLUDE','LIB','PATH'])
historical=json.loads((R/'dependency-compile-reference.json').read_bytes())['objects']
cpp=[]
for o in historical:
 name=pathlib.PureWindowsPath(o['source']).name
 if name.endswith('.cpp'):
  p=R/'source/Externals/poco/Foundation/src'/name
  assert p.is_file() and sha(p.read_bytes())==o['sourceSha256'],name
  cpp.append(p)
pcre=R/'source/Externals/poco/dependencies/pcre2/src'
include=R/'source/Externals/poco/Foundation/include'
double_conversion=R/'source/Externals/poco/dependencies/v8_double_conversion/src'
assert (double_conversion/'double-conversion.h').is_file()
def q(x):return '"'+str(x)+'"'
plans=[]
for run in ['run1','run2']:
 out=R/run;out.mkdir(exist_ok=True)
 for sub in ['obj','temp']:(out/sub).mkdir(exist_ok=True)
 assert not list(out.glob('*.exe')) and not list((out/'obj').glob('*.obj'))
 common=['/nologo','/utf-8','/std:c++20','/EHsc','/MD','/O1','/Gy','/bigobj','/DPOCO_STATIC','/DPOCO_NO_AUTOMATIC_LIBS','/DPCRE2_STATIC','/DNOMINMAX','/DUNICODE','/D_UNICODE','/I'+str(include),'/I'+str(pcre),'/I'+str(double_conversion)]
 steps=[('pcre',['/nologo','/c','/O1','/MD','/DHAVE_CONFIG_H','/DPCRE2_STATIC','/I'+str(pcre),'/Fo'+str(out/'obj/pcre2.obj'),str(pcre/'pcre2.c')]),
        ('cpp',common+['/c','/Fo'+str(out/'obj')+'/']+[str(x) for x in cpp]+[str(R/'adapter.cpp')]),
        ('link',['/nologo','/MD','/Fe'+str(out/'reference.exe')]+[str(out/'obj'/x.with_suffix('.obj').name) for x in cpp]+[str(out/'obj/adapter.obj'),str(out/'obj/pcre2.obj'),'oleaut32.lib','advapi32.lib','user32.lib','/link','/OPT:REF'])]
 commands=[]
 for name,args in steps:
  rsp=out/(name+'.rsp');rsp.write_text('\n'.join(q(x) for x in args)+'\n',encoding='utf8')
  cmd=out/(name+'.cmd');cmd.write_text('@echo off\ncall '+q(vcvars)+' >nul\nif errorlevel 1 exit /b %errorlevel%\n'+environment_lines+q(compiler)+' @'+q(rsp)+'\nexit /b %errorlevel%\n',encoding='utf8')
  commands.append(dict(stage=name,wrapper=str(cmd.relative_to(R)),response=str(rsp.relative_to(R)),arguments=args,compiler=str(compiler),compilerSha256=sha(compiler.read_bytes()),vcvars=str(vcvars),vcvarsSha256=sha(vcvars.read_bytes())))
 plans.append(dict(run=run,commands=commands,executable=str(out/'reference.exe'),compileReceipt=str(out/'compile-receipt.json'),stdout=str(out/'native.ndjson'),TEMP=str(out/'temp'),TMP=str(out/'temp')))
plan=dict(nativeCompileExecuted=False,nativeChildExecuted=False,cppSourceCount=len(cpp)+1,pcreSource=str(pcre/'pcre2.c'),pocoObjectsReused=False,compiler=str(compiler),compilerSha256=sha(compiler.read_bytes()),vcvars=str(vcvars),vcvarsSha256=sha(vcvars.read_bytes()),runs=plans)
(R/'native-build-plan.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf8')
# Mandatory manifest covers every source asset and every prepared harness/plan/script.
excluded={'prepared-inputs.json','syntax-check.json','preparation-check.json','status.json','write-probe.txt'}
files=[p for p in R.rglob('*') if p.is_file() and p.name not in excluded and 'temp' not in p.relative_to(R).parts and 'inputs' not in p.relative_to(R).parts]
inputs={p.relative_to(R).as_posix():sha(p.read_bytes()) for p in sorted(files)}
(R/'prepared-inputs.json').write_text(json.dumps(dict(inputSha256=inputs,casesSha256=sha((R/'cases.json').read_bytes()),sourceManifestSha256=sha((R/'source-manifest.json').read_bytes()),runtimeInputs='list-versions.json and per-case path in cases.inc; mutable physical files excluded from compile closure',nativeCompileExecuted=False),indent=2)+'\n',encoding='utf8')
print(json.dumps(dict(preparedRuns=2,cppSourceCount=len(cpp)+1,mandatoryInputs=len(inputs),nativeCompileExecuted=False)))
