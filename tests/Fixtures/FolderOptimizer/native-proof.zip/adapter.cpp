// 検証専用adapter。原典bodyは無改変inc、追跡は派生classで行う。
#define NOMINMAX
#define POCO_STATIC
#define POCO_NO_AUTOMATIC_LIBS
#include <Windows.h>
#include <OleAuto.h>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <cctype>
#include <cstdint>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <limits>
#include <map>
#include <memory>
#include <optional>
#include <sstream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <type_traits>
#include <variant>
#include <vector>
#include <Poco/RegularExpression.h>
#include <Poco/Exception.h>
#include <Poco/Timestamp.h>
#include <Poco/LocalDateTime.h>
#include <Poco/Timezone.h>
#include <Poco/DateTimeFormat.h>
#include <Poco/DateTimeFormatter.h>
#include <Poco/DateTimeParser.h>
#include <Poco/String.h>
#include "source/Src/FilterEngine/FilterParser.h"
#include "source/Src/FilterEngine/FilterError.h"
[[noreturn]] void unsupported(){throw std::logic_error("UNSUPPORTED_ADAPTER_REACHED");}
// LIKE evaluation is outside this corpus. It must fail, never return plausible output.
namespace Poco {struct Glob{enum{GLOB_CASELESS=1};Glob(const std::string&,int){unsupported();}bool match(const std::string&)const{unsupported();}};}
using String=std::string;
std::wstring wide(const std::string& x){int n=MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,x.data(),int(x.size()),nullptr,0);if(!n&&!x.empty())throw std::runtime_error("UTF8 conversion");std::wstring s(n,0);if(n)MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,x.data(),int(x.size()),s.data(),n);return s;}
namespace ucr{
std::string toUTF8(const String& s){return s;}
String toTString(const std::string& s){return s;}
#include "utf8-lead.inc"
#include "utf8-length.inc"
}
namespace locality{
namespace native{using String=std::wstring;using Timestamp=Poco::Timestamp;
#include "locality-parse.inc"
}
bool ParseDateTime(const std::string& s,int64_t& n){return native::ParseDateTime(wide(s),n);}
}
// File-content API is outside this corpus; declarations support original compute
// type checking, and every invocation fails rather than returning stub semantics.
struct FileContentRef{std::string path;bool operator==(const FileContentRef&)const{unsupported();}bool Contains(const std::string&,bool=false)const{unsupported();}bool REContains(const Poco::RegularExpression&)const{unsupported();}};
#include "nodes.inc"
class DIFFITEM{};
struct Provider{
int GetLineCount()const{unsupported();}int GetColumnCount(int,int)const{unsupported();}
std::string GetLine(int,int)const{unsupported();}std::string GetColumn(int,int,int)const{unsupported();}
std::string GetColumns(int,int,const std::vector<int>&)const{unsupported();}
};
struct HostContext{int dirs;int GetCompareDirs()const{return dirs;}};
struct FilterExpression{
HostContext* ctxt;bool caseSensitive;const Poco::Timestamp* now;const Poco::Timestamp* today;
std::unique_ptr<ExprNode> rootNode;int errorCode=0;bool optimize=true;std::string errorMessage;
std::function<void(int,const std::string&)> logger;
};
struct FilterEvalContext{const FilterExpression* expr;const DIFFITEM* di=nullptr;const Provider* provider=nullptr;const void* sharedContext=nullptr;int lineIndex=-1;};
std::vector<std::string> visits,ioReads;
// Existing loader oracle's explicit UTF-8 reader boundary; real files are opened.
#include "utf8-loader-adapter.inc"
namespace ReplaceList{
#include "original-loaders.inc"
}
#include "operators.inc"
#include "parse-datetime.inc"
#include "literal-constructors.inc"
#include "column-helpers.inc"
#include "attribute-name.inc"
#include "scalar-lifting.inc"
#include "numeric-array-string.inc"
#include "replace-list-functions.inc"
#include "clock-calendar.inc"
#include "to-string-regexreplace.inc"
#include "if.inc"
#include "choose.inc"
#include "conversions.inc"
#include "string-regex-observers.inc"
#include "function-info.inc"
#include "selected-table.inc"
#include "function-lookup.inc"
#include "side-functions.inc"
void FunctionNode::SetPropFunc(int,int,bool){unsupported();}
#include "function-constructor.inc"
#include "function-optimize-evaluate.inc"
std::string hex(const std::string&s){static const char*d="0123456789abcdef";std::string o;for(unsigned char c:s){o+=d[c>>4];o+=d[c&15];}return o;}
std::string q(const std::string&s){std::string o="\"";for(unsigned char c:s){if(c=='"'||c=='\\'){o+='\\';o+=c;}else if(c<32){const char*d="0123456789abcdef";o+="\\u00";o+=d[c>>4];o+=d[c&15];}else o+=c;}return o+'"';}
std::string strings(const std::vector<std::string>&a){std::string s="[";for(auto&v:a){if(s.size()>1)s+=',';s+=q(v);}return s+"]";}
std::string value(const ValueType&v){
 if(std::holds_alternative<std::monostate>(v))return "{\"kind\":\"none\"}";
 if(auto p=std::get_if<bool>(&v))return std::string("{\"kind\":\"bool\",\"value\":")+(*p?"true":"false")+"}";
 if(auto p=std::get_if<int64_t>(&v))return "{\"kind\":\"integer\",\"decimal\":"+q(std::to_string(*p))+"}";
 if(auto p=std::get_if<double>(&v)){std::ostringstream o;o<<std::hexfloat<<*p;return "{\"kind\":\"double\",\"hexfloat\":"+q(o.str())+"}";}
 if(auto p=std::get_if<std::string>(&v))return "{\"kind\":\"string\",\"utf8Hex\":"+q(hex(*p))+"}";
 if(auto p=std::get_if<Poco::Timestamp>(&v))return "{\"kind\":\"timestamp\",\"epochMicroseconds\":"+q(std::to_string(p->epochMicroseconds()))+"}";
 if(std::holds_alternative<std::shared_ptr<Poco::RegularExpression>>(v))return "{\"kind\":\"opaque-native-regex\"}";
 if(auto p=std::get_if<std::shared_ptr<std::vector<ValueType2>>>(&v)){std::string s="{\"kind\":\"array\",\"items\":[";for(size_t i=0;i<(*p)->size();++i){if(i)s+=',';s+=value((**p)[i].value);}return s+"]}";}
 unsupported();
}
struct Identity{std::string id;explicit Identity(std::string i):id(std::move(i)){}virtual ~Identity()=default;};
template<class T>struct Track:T,Identity{
template<class...A>Track(std::string id,A&&...a):T(std::forward<A>(a)...),Identity(std::move(id)){}
ExprNode* Optimize()override{visits.push_back("O:"+this->id);return T::Optimize();}
ValueType Evaluate(const FilterEvalContext&c)const override{visits.push_back("E:"+this->id);return T::Evaluate(c);}
};
struct Probe:ExprNode,Identity{
ValueType v;std::string fault;
Probe(std::string id,ValueType x,std::string f=""):Identity(std::move(id)),v(std::move(x)),fault(std::move(f)){}
ExprNode* Optimize()override{visits.push_back("O:"+id);if(fault=="optimize")throw std::runtime_error("ADAPTER_OPTIMIZE_THROW");return this;}
ValueType Evaluate(const FilterEvalContext&)const override{visits.push_back("E:"+id);if(fault=="evaluate")throw std::runtime_error("ADAPTER_EVALUATE_THROW");return v;}
};
std::string ast(const ExprNode*n){
 if(!n)return "null";
 std::string s="{";auto*id=dynamic_cast<const Identity*>(n);s+="\"id\":"+(id?q(id->id):"null");
 #define LIT(T) if(auto*p=dynamic_cast<const T*>(n))return s+",\"class\":\"" #T "\",\"value\":"+value(p->value)+"}";
 LIT(BoolLiteral)LIT(DoubleLiteral)LIT(IntLiteral)LIT(StringLiteral)LIT(SizeLiteral)LIT(DurationLiteral)LIT(VersionLiteral)LIT(DateTimeLiteral)LIT(RegularExpressionLiteral)LIT(ArrayLiteral)
 #undef LIT
 if(dynamic_cast<const NoneLiteral*>(n))return s+",\"class\":\"NoneLiteral\"}";
 if(auto*p=dynamic_cast<const FunctionNode*>(n)){s+=",\"class\":\"FunctionNode\",\"name\":"+q(p->functionName)+",\"children\":[";if(p->args)for(size_t i=0;i<p->args->size();++i){if(i)s+=',';s+=ast((*p->args)[i]);}return s+"]}";}
 #define BINARY(T) if(auto*p=dynamic_cast<const T*>(n))return s+",\"class\":\"" #T "\",\"children\":["+ast(p->left)+","+ast(p->right)+"]}";
 BINARY(OrNode)BINARY(AndNode)
 #undef BINARY
 if(auto*p=dynamic_cast<const BinaryOpNode*>(n))return s+",\"class\":\"BinaryOpNode\",\"op\":"+std::to_string(p->op)+",\"children\":["+ast(p->left)+","+ast(p->right)+"]}";
 #define UNARY(T) if(auto*p=dynamic_cast<const T*>(n))return s+",\"class\":\"" #T "\",\"children\":["+ast(p->right)+"]}";
 UNARY(NotNode)UNARY(NegateNode)
 #undef UNARY
 if(auto*p=dynamic_cast<const Probe*>(n))return s+",\"class\":\"Probe\",\"value\":"+value(p->v)+",\"fault\":"+q(p->fault)+"}";
 unsupported();
}
struct Builder{
FilterExpression* e;
template<class T,class...A>ExprNode* lit(const char*id,A&&...a){return new Track<T>(id,std::forward<A>(a)...);}
ExprNode* function(const char*id,const char*name,std::initializer_list<ExprNode*> a){auto args=new std::vector<ExprNode*>(a);try{return new Track<FunctionNode>(id,e,name,args);}catch(...){for(auto*p:*args)delete p;delete args;throw;}}
ExprNode* binary(const char*id,int op,ExprNode*l,ExprNode*r){return new Track<BinaryOpNode>(id,e,l,op,r);}
ExprNode* probe(const char*id,ValueType v,const char*f=""){return new Probe(id,std::move(v),f);}
};
std::shared_ptr<std::vector<ValueType2>> values(std::initializer_list<ValueType> a){auto v=std::make_shared<std::vector<ValueType2>>();for(auto&x:a)v->push_back({x});return v;}
void writeFile(const std::string&p,const std::string&b){std::ofstream f(p,std::ios::binary|std::ios::trunc);f.write(b.data(),b.size());if(!f)throw std::runtime_error("fixture file write failed");}
void run(const char*id,int dirs,const char*mode,bool cs,std::function<ExprNode*(Builder&)>make,const char*listPath){
 HostContext host{dirs};Poco::Timestamp now(Poco::Timestamp::TimeVal(1700000000123456LL)),today(Poco::Timestamp::TimeVal(1699920000000000LL));
 FilterExpression e{&host,cs,&now,&today};e.optimize=std::string(mode)!="noopt";
 e.logger=[](int n,const std::string&s){visits.push_back("L:"+std::to_string(n)+":"+hex(s));};Builder b{&e};visits.clear();ioReads.clear();
 std::string before="null",after="null",phase="construct",error,value1="null",value2="null",runtimeError1,runtimeError2;std::vector<std::string> optimizeTrace,evaluate1,evaluate2,readsCompile,reads1,reads2;
 try{
 if(*listPath)writeFile(listPath,"a\tfirst\n");
 ExprNode*root=make(b);before=ast(root);visits.clear();ioReads.clear();phase="compile";
 FilterExpression*pCtx=&e;struct{ExprNode*node;}A{root};
 #include "parser-reduction-action.inc"
 optimizeTrace=visits;readsCompile=ioReads;after=ast(e.rootNode.get());phase=e.errorCode?"compile-rejected":"evaluate";
 if(!e.errorCode){FilterEvalContext c{&e};
 for(int iteration=0;iteration<2;++iteration){visits.clear();ioReads.clear();try{auto v=e.rootNode->Evaluate(c);(iteration?value2:value1)=value(v);}catch(const std::exception&x){(iteration?runtimeError2:runtimeError1)=x.what();}(iteration?evaluate2:evaluate1)=visits;(iteration?reads2:reads1)=ioReads;if(iteration==0&&*listPath)writeFile(listPath,"a\tsecond\n");}
 phase="complete";
 }
 }catch(const std::exception&x){error=x.what();}
 std::cout<<"{\"id\":"<<q(id)<<",\"phase\":"<<q(phase)<<",\"errorUtf8Hex\":"<<q(hex(error))<<",\"compileCode\":"<<e.errorCode<<",\"compileMessageUtf8Hex\":"<<q(hex(e.errorMessage))<<",\"before\":"<<before<<",\"after\":"<<after<<",\"optimizeTrace\":"<<strings(optimizeTrace)<<",\"evaluateTrace1\":"<<strings(evaluate1)<<",\"evaluateTrace2\":"<<strings(evaluate2)<<",\"value1\":"<<value1<<",\"value2\":"<<value2<<",\"runtimeError1Utf8Hex\":"<<q(hex(runtimeError1))<<",\"runtimeError2Utf8Hex\":"<<q(hex(runtimeError2))<<",\"readsCompile\":"<<strings(readsCompile)<<",\"reads1\":"<<strings(reads1)<<",\"reads2\":"<<strings(reads2)<<",\"context\":{\"dirs\":"<<dirs<<",\"providerNull\":true,\"sharedContextNull\":true,\"lineIndex\":-1}}\n";
}
int main(){
#include "cases.inc"
}
