# Whole-tree folder Optimize native capture preparation

Status: PREPARED, NOT COMPILED, NOT CAPTURED. No MSVC, native child, dotnet, application, E2E or full parser has been run in this preparation stage.

`source-manifest.json` fixes commit `6780924ba35f7f55af0f6f14dd302561175830a6`, content hashes, computed Git blob IDs, source containers, and every unmodified byte span. Six original Optimize overrides, the default identity method, TryFoldConstants, literal helpers/constructors, relevant original Evaluate bodies and selected original function-table rows are compiled by the prepared adapter. No tracing markers are inserted into original bodies. The 382 source/license assets are reused from existing fixed native fixture containers, including real Poco timestamp/calendar/string/regex and PCRE2 sources; no dependency is installed and no prior native object is reused.

`rule-inventory.json` has six overrides and 22 original top-level FunctionNode guards (three calendar functions share one guard). It preserves literal class identity separately from runtime ValueType. `cases.json` fixes 563 base scenarios × dirs 2/3 × default/opt/noopt × sensitive/insensitive = 6,756 AST cases. Default and opt invoke the same original Optimize reduction with its flag enabled. Directive/token/grammar acceptance is not claimed. `cases.inc` is independently reconstructed from JSON by the reader, including every nested argument, side name, mode, class and literal value.

The executable runs the original parser **reduction action** unchanged. Regex, InvalidArgument and DivisionByZero set the original error codes; another std::exception retains the original root. This is not the complete parser. Tracking subclasses call the original Optimize/Evaluate and keep original dynamic_cast behavior; newly folded literals have no tracking identity. Each output captures the complete input/residual AST class, literal typed value, child traversal, two runtime evaluation traces, compile status, errors, and provider-null/shared-null/line=-1 context. A fixed now/today timestamp is injected; OS clock updates are out of scope. The native reader requires exact two-run byte equality and actual process, compiler, input, executable, exit/EOF/timeout evidence.

The physical list files start as `a<TAB>first` and change to `a<TAB>second` between evaluations. The original LoadList, LoadRegexList and LoadListImpl functions execute through the explicitly disclosed UTF-8 file reader adapted from `LineTransformReplaceLists`; that reader opens real files and records attempts. Original UniMemFile, encoding inference, environment expansion and arbitrary path/encoding behavior remain unobserved. The existing loader oracle and this additional capture share original loader blob `c1fbe88f336d3445ede014268ea4727478dea81c`; this capture adds whole-tree Optimize lifetime/cache evidence, not a new loader compatibility claim. Original bodies are unmodified; I/O observation is confined to the adapter. Case scripts reset each file before compilation of its AST, so opt literal paths freeze the first version, while noopt and nonliteral paths reread the second version.

Fail-fast adapter APIs exist only for provider-present calls, SetPropFunc, file-content operations and LIKE evaluation. No corpus case calls them; the reader rejects the explicit unsupported marker. These paths are not evidence of compatibility. All Optimize branches that need regex, numeric, UTF-8 count, conversion, timestamp or list behavior use original implementations. Localized date fallback uses the original Windows OLE parser via a UTF-8/wide boundary. Native dependencies and C++ name/type/link correctness remain unverified until actual compilation. `check-prepared.py` performs Python syntax and C++ lexical delimiter checks only.

After the parent's UI timing stage is finished, use the fixed interpreter and this task root as TEMP/TMP:

```powershell
$root = 'D:\Codex\DiffBeacon\folder-optimizer-20261023-native01'
$env:TEMP = "$root\temp"
$env:TMP = $env:TEMP
$python = 'C:\Users\IMT\AppData\Roaming\uv\python\cpython-3.14-windows-x86_64-none\python.exe'
& $python -E -B -X utf8 "$root\check-prepared.py"
& $python -E -B -X utf8 "$root\execute-native.py" --execute
```

The execution script makes two fresh independent native compilations, captures two independent native children, and runs the independent reader. It refuses existing objects/executables; it never deletes or overwrites prior native outputs. A Windows job tracks subprocess descendants on timeout. Compile subprocesses have a 600-second limit per stage and native children a 120-second limit. A failed or partial capture is not a golden and must not be used as proof. No whole-tree optimizer golden exists yet.

Preparation review r1 fixes: the executor creates each process with CREATE_SUSPENDED, assigns it to the Job, obtains its sole initial thread through Toolhelp, and only then calls ResumeThread (previous count must equal 1). Assignment failure terminates the still-suspended process without resuming it. WinAPI signatures, failed return/error handling and owned-handle closure are explicit. Native receipts will record suspension, assignment-before-resume and initial-thread evidence; these WinAPI paths remain unexecuted until GO. The independent reader now derives the exact Optimize stop prefix from the frozen AST and original source rules, including adapter Optimize faults and original zero-division, Binary regex and ColumnRange compile failures. Empty, before-stop, skipped-child and after-stop mutations must all fail. Reader mutation checks use synthetic traces and are not native observations. The pre-review bytes and receipt are retained, with SHA/size verification, under `pre-review-r1/`.

Preparation artifacts are retained here for subsequent capture and review. Repository/fixed fixtures/previous native roots are untouched. No Git stage/commit/push or cleanup/deletion has been performed.
