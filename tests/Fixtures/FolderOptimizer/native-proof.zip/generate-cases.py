"""Freeze failure conditions and typed ASTs before any compile/capture."""
import copy, hashlib, itertools, json, pathlib
R=pathlib.Path(__file__).resolve().parent
def write(n,x):
    (R/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def lit(k,v=None):return dict(node=k,value=v)
def I(v=7):return lit('IntLiteral',v)
def D(v=1.5):return lit('DoubleLiteral',v)
def S(v='abc'):return lit('StringLiteral',v)
def B(v=True):return lit('BoolLiteral',v)
def T(v=1700000000123456):return lit('DateTimeLiteral',v)
def N():return lit('NoneLiteral')
def F(name,*a):return dict(node='FunctionNode',name=name,children=list(a))
def O(k,*a):return dict(node=k,children=list(a))
def X(op,l,r):return dict(node='BinaryOpNode',op=op,children=[l,r])
def P(v,fault=''):return dict(node='Probe',value=v,fault=fault)
def A(*v):return lit('ArrayLiteral',list(v))
base=[]
def add(label,tree,rule,expect=None,listio=False):base.append(dict(label=label,tree=tree,rule=rule,expect=expect or {},listio=listio))
def neg(n):return O('NegateNode',n)

# Each class identity, including excluded literal classes, is explicit in JSON.
primitive=[I(),D(),S(),B(),T()]
intlikes=[I(),lit('SizeLiteral','1KB'),lit('DurationLiteral','1ms'),lit('VersionLiteral','1.2.3.4')]
other=[N(),A(I()),A(A(I())),lit('RegularExpressionLiteral','a')]
for x in primitive+intlikes[1:]+other:
 add('default-identity-'+x['node'],x,'default')
 add('negate-'+x['node'],neg(x),'negate')
 add('not-'+x['node'],O('NotNode',x),'not')
for kind in ('OrNode','AndNode'):
 for l,r in itertools.product([B(False),B(),I(),N(),P(B())],repeat=2):
  add(kind+'-typed',O(kind,l,r),'or' if kind=='OrNode' else 'and')
comparisons=['EQ','NE','LT','LE','GT','GE']
arith=['PLUS','MINUS','STAR','SLASH','MOD']
for l,r in itertools.product(intlikes,repeat=2):
 for op in comparisons+arith:add('intlike-'+l['node']+'-'+r['node']+'-'+op,X(op,l,r),'binary-intlike')
for op in comparisons+arith[:-1]:add('double-'+op,X(op,D(),D(2.5)),'binary-double')
for op in comparisons+['PLUS']:add('string-'+op,X(op,S('aBc'),S('AbC')),'binary-string')
for op in comparisons+['PLUS','MINUS']:add('bool-'+op,X(op,B(),B(False)),'binary-bool')
for op in comparisons+['MINUS']:add('datetime-'+op,X(op,T(),T(1700000000000000)),'binary-datetime')
for r in intlikes:
 for op in ['PLUS','MINUS']:add('datetime-intlike-'+r['node']+'-'+op,X(op,T(),r),'binary-datetime-intlike')
for l,r in [(D(),I()),(I(),D()),(N(),I()),(I(),N()),(A(I()),I()),(S(),I())]:
 for op in ['EQ','PLUS','SLASH']:add('nonfold-'+l['node']+'-'+r['node']+'-'+op,X(op,l,r),'binary-nonfold',dict(afterClass='BinaryOpNode'))
for zero in [I(0),D(0.0)]:
 for op in ['SLASH']+(['MOD'] if zero['node']=='IntLiteral' else []):
  add('constant-zero-'+zero['node']+'-'+op,X(op,I() if zero['node']=='IntLiteral' else D(),zero),'compile-zero',dict(optCompileCode=12))
add('true-or-zero',O('OrNode',B(),X('SLASH',I(1),I(0))),'eager-shortcircuit',dict(optCompileCode=12,nooptValue=True))
add('false-and-zero',O('AndNode',B(False),X('SLASH',I(1),I(0))),'eager-shortcircuit',dict(optCompileCode=12,nooptValue=False))
add('if-unselected-zero',F('if',B(),S('chosen'),X('SLASH',I(1),I(0))),'function-eager',dict(optCompileCode=12))
badRange=F('columnrange',F('substr',S('0'),I(0)))
add('lineat-unreachable-range',F('lineat',badRange),'provider-eager-range',dict(optCompileCode=15,nooptKind='none'))
add('at-empty-array-range',F('at',F('array'),badRange),'function-eager-range',dict(optCompileCode=15))
add('if-unselected-range',F('if',B(),S('chosen'),badRange),'function-eager-range',dict(optCompileCode=15))
add('choose-unselected-range',F('choose',I(0),S('chosen'),badRange),'function-eager-range',dict(optCompileCode=15))
add('std-exception-root-retained',F('if',B(),S('chosen'),P(N(),'optimize')),'parser-std-root-retain',dict(optCompileCode=0,afterClass='FunctionNode'))
add('std-exception-halts-child-order',F('array',P(I()),P(I(),'optimize'),P(I())),'parser-std-children',dict(optCompileCode=0,afterClass='FunctionNode'))
for name in ['now','today']:
 add(name,F(name),'clock-'+name,dict(optAfterClass='DateTimeLiteral'))
for node in primitive+intlikes[1:]+[N(),P(I())]:add('abs-'+node['node'],F('abs',node),'function-abs')
for node in primitive+intlikes[1:]+other+[P(I()),neg(lit('SizeLiteral','1KB')),F('now'),F('abs',neg(lit('SizeLiteral','1KB')))]:
 add('array-'+node['node'],F('array',node),'function-array')
add('array-five-primitive',F('array',*primitive),'function-array',dict(optAfterClass='ArrayLiteral'))
add('array-size-not-folded',F('array',lit('SizeLiteral','1KB')),'array-provenance',dict(optAfterClass='FunctionNode'))
add('array-negated-size-folded',F('array',neg(lit('SizeLiteral','1KB'))),'array-provenance',dict(optAfterClass='ArrayLiteral'))
for node in primitive+[N(),A(I()),lit('RegularExpressionLiteral','a')]:
 for index in [-2,-1,0,1]:add('at-'+node['node']+'-'+str(index),F('at',A(node),I(index)),'function-at')
for index in [D(0),lit('SizeLiteral','1B'),P(I(0))]:add('at-non-int-index-'+index['node'],F('at',A(I()),index),'function-at-index')
for name in ['columnrange','leftcolumnrange','middlecolumnrange','rightcolumnrange']:
 for spec in ['1','!1,2-3,4-','0','1,','3-2']:
  for constant in [True,False]:add('range-'+name+'-'+spec+str(constant),F(name,S(spec) if constant else P(S(spec))),'function-columnrange')
 for wrong in [I(),N(),lit('SizeLiteral','1KB')]:add('range-'+name+'-nonstring-'+wrong['node'],F(name,wrong),'function-columnrange-type')
for name in ['strlen','substr','strcount','strfind']:
 args={'strlen':[S('aéz')],'substr':[S('abcdef'),I(1),I(3)],'strcount':[S('abab'),S('ab')],'strfind':[S('abab'),S('ab'),I(1)]}[name]
 add(name+'-literal',F(name,*args),'function-'+name)
 for i in range(len(args)):
  copied=copy.deepcopy(args);copied[i]=P(copied[i]);add(name+'-nonliteral-'+str(i),F(name,*copied),'function-'+name)
  copied=copy.deepcopy(args);copied[i]=lit('SizeLiteral','1B') if i else I();add(name+'-wrong-literal-'+str(i),F(name,*copied),'function-'+name)
for name in ['replace','regexreplace','regexcount','regexfind','regexextract']:
 args=[S('aba'),S('(a)')]+([S('X')] if name in ['replace','regexreplace'] else [])
 add(name+'-literal',F(name,*args),'function-'+name)
 add(name+'-invalid-pattern',F(name,S('aba'),S('['),*args[2:]),'regex-helper-invalid',dict(optCompileCode=0))
 for i in range(len(args)):
  copied=copy.deepcopy(args);copied[i]=P(copied[i]);add(name+'-nonliteral-'+str(i),F(name,*copied),'function-'+name)
 if name in ['regexfind','regexextract']:
  for extra in [I(1),I(99),D(1),P(I(1))]:add(name+'-optional-'+extra['node'],F(name,*args,extra),'function-'+name)
 if name=='regexfind':
  for extra in [I(1),I(99),D(1),P(I(1))]:add(name+'-group-'+extra['node'],F(name,*args,I(0),extra),'function-'+name)
for op in ['RECONTAINS','MATCHES']:
 for pattern in ['a','[']:
  add('binary-regex-'+op+pattern,X(op,S('aba'),S(pattern)),'binary-regex',dict(optCompileCode=8) if pattern=='[' else dict(optAfterClass='BinaryOpNode'))
for name in ['replacewithlist','regexreplacewithlist']:
 for pathKind in ['literal','probe']:
  path=S('$LIST');arg=path if pathKind=='literal' else P(path)
  add(name+'-'+pathKind+'-lifetime',F(name,S('a'),arg),'function-list-lifetime',dict(optCompileCode=0),listio=True)
for name in ['startofweek','startofmonth','startofyear']:
 for v in [T(),S('2024-03-12T04:05:06Z'),P(T())]:add(name+'-'+v['node'],F(name,v),'function-calendar')
for name in ['tonumber','toint','todouble','todatetime']:
 for v in ['123','1.25','1,234','1e2','bad','2024-03-12T04:05:06Z','']:
  add(name+'-string-'+v,F(name,S(v)),'function-'+name)
 for v in [I(),D(),P(S('123'))]:add(name+'-other-'+v['node'],F(name,v),'function-'+name)

def assign(n,counter):
 n=copy.deepcopy(n);n['id']='n'+str(next(counter)).zfill(4)
 if 'children'in n:n['children']=[assign(v,counter) for v in n['children']]
 # Array elements and Probe payloads are ValueType inputs, not AST children.
 return n
cases=[]
for entry in base:
 for dirs,mode,cs in itertools.product([2,3],['default','opt','noopt'],[False,True]):
  c=copy.deepcopy(entry);c.update(id='c'+str(len(cases)).zfill(5),dirs=dirs,mode=mode,caseSensitive=cs)
  c['tree']=assign(c['tree'],itertools.count());cases.append(c)
def quoted(x):return json.dumps(x,ensure_ascii=True)
def cppvalue(n):
 k=n['node'];v=n.get('value')
 if k=='NoneLiteral':return 'ValueType(std::monostate{})'
 if k=='IntLiteral':return 'ValueType(int64_t('+str(v)+'LL))'
 if k=='DoubleLiteral':return 'ValueType(double('+repr(v)+'))'
 if k=='BoolLiteral':return 'ValueType('+str(v).lower()+')'
 if k=='StringLiteral':return 'ValueType(std::string('+quoted(v)+'))'
 if k=='DateTimeLiteral':return 'ValueType(Poco::Timestamp(Poco::Timestamp::TimeVal('+str(v)+'LL)))'
 if k=='ArrayLiteral':return 'ValueType(values({'+','.join(cppvalue(x) for x in v)+'}))'
 if k=='RegularExpressionLiteral':return 'ValueType(std::make_shared<Poco::RegularExpression>('+quoted(v)+',getRegexFlags(false)))'
 raise ValueError(n)
def expr(n,path):
 k=n['node'];i=quoted(n['id']);ch=[expr(v,path) for v in n.get('children',[])]
 if k=='Probe':return 'b.probe('+i+','+cppvalue(replace_path(n['value'],path))+','+quoted(n['fault'])+')'
 if k=='FunctionNode':return 'b.function('+i+','+quoted(n['name'])+',{'+','.join(ch)+'})'
 if k=='BinaryOpNode':return 'b.binary('+i+',TK_'+n['op']+','+','.join(ch)+')'
 if k in ['NotNode','NegateNode','OrNode','AndNode']:return 'b.lit<'+k+'>('+i+','+','.join(ch)+')'
 v=replace_path(n,path).get('value');args=''
 if k=='IntLiteral':args='int64_t('+str(v)+'LL)'
 elif k=='DoubleLiteral':args='double('+repr(v)+')'
 elif k=='BoolLiteral':args=str(v).lower()
 elif k=='DateTimeLiteral':args='Poco::Timestamp(Poco::Timestamp::TimeVal('+str(v)+'LL))'
 elif k=='ArrayLiteral':args='values({'+','.join(cppvalue(x) for x in v)+'})'
 elif k!='NoneLiteral':args='std::string('+quoted(v)+')'
 return 'b.lit<'+k+'>('+i+(','+args if args else '')+')'
def replace_path(n,path):
 n=copy.deepcopy(n)
 if n.get('value')=='$LIST':n['value']=path
 return n
def render(c):
 path='inputs/'+c['id']+'.tsv' if c['listio'] else ''
 return 'run('+','.join([quoted(c['id']),str(c['dirs']),quoted(c['mode']),str(c['caseSensitive']).lower(),'[](Builder& b){return '+expr(c['tree'],path)+';}',quoted(path)])+');'
write('cases.json',cases)
(R/'cases.inc').write_text('\n'.join(map(render,cases))+'\n',encoding='utf8')
(R/'inputs').mkdir(exist_ok=True)
for c in cases:
 if c['listio']:(R/'inputs'/(c['id']+'.tsv')).write_bytes(b'a\tfirst\n')
write('failure-matrix.json',dict(fixedBeforeCompile=True,baseScenarioCount=len(base),caseCount=len(cases),axes=dict(dirs=[2,3],mode=['default','opt','noopt'],caseSensitive=[False,True]),sourceRules=sorted(set(c['rule'] for c in cases)),mandatoryLabels=['lineat-unreachable-range','at-empty-array-range','true-or-zero','if-unselected-range','array-size-not-folded','array-negated-size-folded','std-exception-root-retained'],requiredEvidence=['before/after AST class and typed value','all-child Optimize visit order','runtime reevaluation trace twice','compile code distinct from runtime errors','literal list read during Optimize; probe/noopt runtime read; file changed between evaluations','two fresh independent compiler and executable processes, actual exit EOF timeout evidence'],forbiddenClaims=['noopt success as opt evidence','full parser executed','original UniMemFile/encoding detector/env expansion','LIKE runtime compatibility','provider-present compatibility','Now/Today OS clock update'],loaderConnection='same original source blob and UTF-8 adapter boundary as LineTransformReplaceLists; additional observation isolates Optimize lifetime'))
print(json.dumps(dict(baseScenarioCount=len(base),caseCount=len(cases),compileExecuted=False)))
