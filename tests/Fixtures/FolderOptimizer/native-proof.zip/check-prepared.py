"""Independent reader: hashes/spans, JSON-to-C++ reconstruction, schema and evidence."""
import argparse, ast as pyast, hashlib, json, pathlib, re, sys
R=pathlib.Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda n:json.loads((R/n).read_bytes())
def quoted(x):return json.dumps(x,ensure_ascii=True)
def val(n,path):
 k=n['node'];v=n.get('value');v=path if v=='$LIST' else v
 if k=='NoneLiteral':return 'ValueType(std::monostate{})'
 if k=='IntLiteral':return 'ValueType(int64_t(%sLL))'%v
 if k=='DoubleLiteral':return 'ValueType(double(%s))'%repr(v)
 if k=='BoolLiteral':return 'ValueType(%s)'%str(v).lower()
 if k=='StringLiteral':return 'ValueType(std::string(%s))'%quoted(v)
 if k=='DateTimeLiteral':return 'ValueType(Poco::Timestamp(Poco::Timestamp::TimeVal(%sLL)))'%v
 if k=='ArrayLiteral':return 'ValueType(values({%s}))'%','.join(val(x,path) for x in v)
 if k=='RegularExpressionLiteral':return 'ValueType(std::make_shared<Poco::RegularExpression>(%s,getRegexFlags(false)))'%quoted(v)
 raise AssertionError(k)
def node(n,path):
 kind=n['node'];ident=quoted(n['id']);children=','.join(node(c,path) for c in n.get('children',[]))
 if kind=='Probe':return 'b.probe(%s,%s,%s)'%(ident,val(n['value'],path),quoted(n['fault']))
 if kind=='FunctionNode':return 'b.function(%s,%s,{%s})'%(ident,quoted(n['name']),children)
 if kind=='BinaryOpNode':return 'b.binary(%s,TK_%s,%s)'%(ident,n['op'],children)
 if kind in ('OrNode','AndNode','NotNode','NegateNode'):return 'b.lit<%s>(%s,%s)'%(kind,ident,children)
 v=n.get('value');v=path if v=='$LIST' else v
 if kind=='NoneLiteral':tail=''
 elif kind=='IntLiteral':tail='int64_t(%sLL)'%v
 elif kind=='DoubleLiteral':tail='double(%s)'%repr(v)
 elif kind=='BoolLiteral':tail=str(v).lower()
 elif kind=='DateTimeLiteral':tail='Poco::Timestamp(Poco::Timestamp::TimeVal(%sLL))'%v
 elif kind=='ArrayLiteral':tail='values({%s})'%','.join(val(x,path) for x in v)
 else:tail='std::string(%s)'%quoted(v)
 return 'b.lit<%s>(%s%s)'%(kind,ident,','+tail if tail else '')
def reconstruct(c):
 path='inputs/%s.tsv'%c['id'] if c['listio'] else ''
 return 'run(%s,%s,%s,%s,[](Builder& b){return %s;},%s);'%(quoted(c['id']),c['dirs'],quoted(c['mode']),str(c['caseSensitive']).lower(),node(c['tree'],path),quoted(path))
def mask_cpp(s):
 # Lexical balance only, never described as a C++ compilation or type check.
 pattern=r'//[^\n]*|/\*[\s\S]*?\*/|"(?:\\[\s\S]|[^"\\])*"|\'(?:\\[\s\S]|[^\'\\])*\''
 return re.sub(pattern,lambda m:'\n'*m.group().count('\n')+' '*(len(m.group())-m.group().count('\n')),s)
def source_checks():
 m=load('source-manifest.json')
 for f in m['files']:
  b=(R/f['file']).read_bytes();assert sha(b)==f['sha256'],f['file'];assert len(b)==f['size']
  assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==f['blob']
 for s in m['extractions']:
  whole=(R/s['path']).read_bytes();part=whole[s['startByte']:s['endByte']]
  assert part==(R/s['file']).read_bytes() and sha(part)==s['sha256'],s['file']
 cp=(R/'source/Src/FilterEngine/FilterExpressionNodes.cpp').read_text(encoding='utf8')
 actual=re.findall(r'^ExprNode\* (\w+)::Optimize\(\)',cp,re.M)
 assert actual==['OrNode','AndNode','NotNode','BinaryOpNode','NegateNode','FunctionNode']
 inv=load('rule-inventory.json');assert actual==inv['overrides']
 body=cp[cp.index('ExprNode* FunctionNode::Optimize()'):cp.index('ValueType FunctionNode::Evaluate')]
 guards=[x for x in body.splitlines() if x.startswith('\tif (functionName') or x.startswith('\tif ((functionName')]
 assert guards==[g['text'] for g in inv['functionTopLevelGuards']]
 assert len(guards)==inv['functionTopLevelGuardCount']==22
 for p in list(R.glob('*.inc'))+[R/'adapter.cpp']:
  # Row and #include wrappers are structurally checked after include expansion below.
  if p.name.startswith('table-row-') or p.name=='selected-table.inc':continue
  masked=mask_cpp(p.read_text(encoding='utf8'));stack=[]
  for ch in masked:
   if ch in '({[':stack.append(ch)
   elif ch in ')}]':assert stack and stack.pop()==dict(zip(')}]','({['))[ch],p.name
  assert not stack,(p.name,stack)
 # All local .inc includes must exist, recursively, before a compile is allowed.
 seen=set()
 def includes(p):
  p=p.resolve()
  if p in seen:return
  seen.add(p)
  for n in re.findall(r'^\s*#include "([^"]+)"',p.read_text(encoding='utf8'),re.M):
   q=R/n
   assert q.is_file(),(p.name,n)
   if q.suffix=='.inc':includes(q)
 includes(R/'adapter.cpp')
 return len(seen)
def prepared_checks(frozen=True):
 count=source_checks();cases=load('cases.json');fm=load('failure-matrix.json')
 assert len(cases)==fm['caseCount'];assert len(cases)==fm['baseScenarioCount']*12
 assert len({c['id'] for c in cases})==len(cases)
 assert (R/'cases.inc').read_text(encoding='utf8')=='\n'.join(reconstruct(c) for c in cases)+'\n'
 for label in fm['mandatoryLabels']:assert any(c['label']==label for c in cases),label
 assert len([c for c in cases if c['listio']])==48
 assert len({(c['dirs'],c['mode'],c['caseSensitive']) for c in cases})==12
 for p in R.glob('*.py'):pyast.parse(p.read_text(encoding='utf8'),filename=str(p))
 stop_mutations=stop_reader_mutations(cases)
 for case in cases:
  if case['mode']!='noopt' and 'optCompileCode' in case['expect']:
   assert expected_optimize_stop(case)['code']==case['expect']['optCompileCode'],case['id']
 if frozen:
  frozen_inputs=load('prepared-inputs.json')
  for f,h in frozen_inputs['inputSha256'].items():assert sha((R/f).read_bytes())==h,f
 return dict(passed=True,caseCount=len(cases),baseScenarioCount=fm['baseScenarioCount'],localIncludes=count,pythonSyntax='passed',cppLexicalBalance='passed; not C++ compilation',stopTraceMutationChecks=stop_mutations,nativeCompileExecuted=False,nativeChildExecuted=False)
def ids(n):
 return [n['id']]+[i for c in n.get('children',[]) for i in ids(c)]
class OptimizeStop(Exception):
 def __init__(self,node,code,source):self.node=node;self.code=code;self.source=source
def valid_column_ranges(text):
 # Source ParseColumnNumber/ParseColumnRanges: positive Int32, ordered bounds,
 # optional exclusion, open upper bound, no empty/trailing comma components.
 parts=text.split(',')
 for part in parts:
  m=re.fullmatch(r'\s*!?\s*([0-9]+)\s*(?:-\s*([0-9]*)\s*)?',part)
  if not m:return False
  start=int(m[1]);end=int(m[2]) if m[2] else None
  if not 1<=start<=2147483647:return False
  if end is not None and not start<=end<=2147483647:return False
 return True
def expected_optimize_stop(case):
 # This is a stop-position classifier for the frozen AST corpus, not a native
 # value oracle. Only Substr's literal propagation is needed by a throwing parent.
 # All classification conditions come from unchanged operators.inc and
 # function-optimize-evaluate.inc/side-functions.inc, not observed native traces.
 if case['mode']=='noopt':return dict(trace=[],code=0,stopNode=None,source=None)
 trace=[]
 def visit(n):
  trace.append(n['id']);kind=n['node']
  if kind=='Probe' and n['fault']=='optimize':raise OptimizeStop(n['id'],0,'adapter.cpp:Probe::Optimize')
  children=[visit(c) for c in n.get('children',[])]
  if kind=='BinaryOpNode':
   l,r=children;intlike={'IntLiteral','SizeLiteral','DurationLiteral','VersionLiteral'}
   intpair=l['node'] in intlike and r['node'] in intlike
   doublepair=l['node']==r['node']=='DoubleLiteral'
   # Every zero denominator in this frozen corpus is a direct Int/Double literal.
   if n['op'] in ['SLASH','MOD'] and (intpair or (doublepair and n['op']=='SLASH')) and r.get('value')==0:
    raise OptimizeStop(n['id'],12,'FilterExpressionNodes.cpp:TryFoldConstants')
   if n['op'] in ['RECONTAINS','MATCHES'] and r['node']=='StringLiteral' and r['value']=='[':
    # The fixed malformed pattern is an unterminated character class. This
    # constructor propagates; OptimizeRegexArg catches the same error instead.
    raise OptimizeStop(n['id'],8,'FilterExpressionNodes.cpp:BinaryOpNode::Optimize/RegularExpressionLiteral')
  if kind=='FunctionNode':
   name=n['name']
   if name in ['columnrange','leftcolumnrange','middlecolumnrange','rightcolumnrange'] and len(children)==1 and children[0]['node']=='StringLiteral' and not valid_column_ranges(children[0]['value']):
    raise OptimizeStop(n['id'],15,'FilterExpressionNodes.cpp:FunctionNode::Optimize/ParseColumnRanges')
   if name=='substr' and len(children) in (2,3) and children[0]['node']=='StringLiteral' and children[1]['node']=='IntLiteral' and (len(children)==2 or children[2]['node']=='IntLiteral'):
    raw=children[0]['value'].encode('utf8');start=children[1]['value'];start=start+len(raw) if start<0 else start
    if start<0 or start>=len(raw):out=b''
    elif len(children)==2:out=raw[start:]
    else:
     length=children[2]['value'];length=length if length>=0 else len(raw)-start+length
     out=raw[start:start+max(0,length)]
    # Corpus substr-to-ColumnRange input is ASCII; byte offsets remain explicit.
    return dict(node='StringLiteral',value=out.decode('utf8',errors='surrogateescape'))
  return n
 try:visit(case['tree'])
 except OptimizeStop as stop:return dict(trace=trace,code=stop.code,stopNode=stop.node,source=stop.source)
 return dict(trace=trace,code=0,stopNode=None,source=None)
def check_optimize_trace(case,observed,compile_code):
 expected=expected_optimize_stop(case)
 assert observed==expected['trace'],(case['id'],expected,observed)
 assert compile_code==expected['code'],(case['id'],expected,compile_code)
 return expected
def stop_reader_mutations(cases):
 selected=[c for c in cases if c['mode']!='noopt' and expected_optimize_stop(c)['stopNode'] is not None]
 rejected=0
 for case in selected:
  expected=expected_optimize_stop(case);trace=expected['trace'];allids=ids(case['tree'])
  # Empty, stop-before, skipped earlier child, invented visit, and stop-after.
  mutations=[[],trace[:-1],trace[1:],trace+['invalid-node']]
  mutations.extend(trace[:i]+trace[i+1:] for i in range(len(trace)))
  if len(trace)<len(allids):mutations.append(trace+[allids[len(trace)]])
  for mutated in mutations:
   assert mutated!=trace
   try:check_optimize_trace(case,mutated,expected['code'])
   except AssertionError:rejected+=1
   else:raise AssertionError(('invalid stop trace accepted',case['id'],mutated))
  check_optimize_trace(case,trace,expected['code'])
 sample=next(c for c in cases if c['id']=='c03975')
 assert expected_optimize_stop(sample)['trace']==['n0000','n0001','n0002']
 return dict(stopCases=len(selected),rejectedTraceMutations=rejected,source='independent AST/source stop classifier; synthetic traces only, no native observation')
def structure(n,actual,path):
 assert actual['class']==n['node'] and actual['id']==n['id']
 if n['node']=='FunctionNode':assert actual['name']==n['name']
 if n['node']=='BinaryOpNode':
  tokenHeader=(R/'source/Src/FilterEngine/FilterParser.h').read_text(encoding='utf8')
  tokens=dict(re.findall(r'#define TK_(\w+)\s+(\d+)',tokenHeader))
  assert actual['op']==int(tokens[n['op']])
 if 'children'in n:
  assert len(actual['children'])==len(n['children'])
  for c,a in zip(n['children'],actual['children']):structure(c,a,path)
 if n['node']=='StringLiteral':assert actual['value']==dict(kind='string',utf8Hex=(path if n['value']=='$LIST' else n['value']).encode().hex())
 if n['node']=='BoolLiteral':assert actual['value']==dict(kind='bool',value=n['value'])
 if n['node']=='IntLiteral':assert actual['value']==dict(kind='integer',decimal=str(n['value']))
 if n['node']=='DateTimeLiteral':assert actual['value']==dict(kind='timestamp',epochMicroseconds=str(n['value']))
 if n['node']=='DoubleLiteral':assert actual['value']['kind']=='double' and float.fromhex(actual['value']['hexfloat'])==n['value']
 if n['node']=='Probe':
  assert actual['fault']==n['fault'];raw_value(n['value'],actual['value'],path)
 if n['node']=='ArrayLiteral':raw_value(n,actual['value'],path)
def raw_value(n,a,path):
 k=n['node'];v=n.get('value')
 if k=='ArrayLiteral':
  assert a['kind']=='array' and len(a['items'])==len(v)
  for source,actual in zip(v,a['items']):raw_value(source,actual,path)
 elif k=='NoneLiteral':assert a==dict(kind='none')
 elif k=='BoolLiteral':assert a==dict(kind='bool',value=v)
 elif k=='IntLiteral':assert a==dict(kind='integer',decimal=str(v))
 elif k=='DateTimeLiteral':assert a==dict(kind='timestamp',epochMicroseconds=str(v))
 elif k=='DoubleLiteral':assert a['kind']=='double' and float.fromhex(a['hexfloat'])==v
 elif k=='StringLiteral':assert a==dict(kind='string',utf8Hex=(path if v=='$LIST' else v).encode().hex())
 elif k=='RegularExpressionLiteral':assert a==dict(kind='opaque-native-regex')
 else:raise AssertionError(k)
def native_checks(paths):
 assert len(paths)==2,'two independently built executables required'
 a,b=[p.read_bytes() for p in paths];assert a==b,'two native stdout byte streams differ'
 rows=[json.loads(x) for x in a.splitlines()];cases=load('cases.json')
 assert len(rows)==len(cases)
 for c,r in zip(cases,rows):
  assert r['id']==c['id'];assert r['phase'] in ['complete','compile-rejected']
  assert not r['errorUtf8Hex'];assert r['context']==dict(dirs=c['dirs'],providerNull=True,sharedContextNull=True,lineIndex=-1)
  path='inputs/%s.tsv'%c['id'] if c['listio'] else ''
  structure(c['tree'],r['before'],path)
  allids=set(ids(c['tree']))
  for field in ['optimizeTrace','evaluateTrace1','evaluateTrace2']:
   for event in r[field]:
    assert event.startswith(('O:','E:','L:'))
    if not event.startswith('L:'):assert event[2:] in allids
  for field in ['errorUtf8Hex','compileMessageUtf8Hex','runtimeError1Utf8Hex','runtimeError2Utf8Hex']:
   assert 'UNSUPPORTED_ADAPTER_REACHED'.encode().hex() not in r[field]
  ex=c['expect'];opt=c['mode']!='noopt'
  check_optimize_trace(c,[x[2:] for x in r['optimizeTrace'] if x.startswith('O:')],r['compileCode'])
  if 'optCompileCode'in ex and opt:assert r['compileCode']==ex['optCompileCode'],c['id']
  k=ex.get('optAfterClass') if opt else None
  if not k:k=ex.get('afterClass')
  if k:assert r['after']['class']==k,c['id']
  if not opt:
   assert not r['optimizeTrace'] and r['compileCode']==0
   if 'nooptValue'in ex:assert r['value1']==dict(kind='bool',value=ex['nooptValue'])
   if 'nooptKind'in ex:assert r['value1']['kind']==ex['nooptKind']
  if r['compileCode']:
   assert r['phase']=='compile-rejected' and r['value1'] is None and not r['evaluateTrace1']
  if c['listio']:
   literal=c['tree']['children'][1]['node']=='StringLiteral';cached=literal and opt
   assert r['readsCompile']==([path] if cached else [])
   assert r['reads1']==([] if cached else [path]) and r['reads2']==([] if cached else [path])
   assert r['value1']==dict(kind='string',utf8Hex=b'first'.hex())
   assert r['value2']==dict(kind='string',utf8Hex=(b'first' if cached else b'second').hex())
  if c['rule']=='function-columnrange' and c['tree']['children'][0]['node']=='StringLiteral' and c['tree']['children'][0]['value'] in ['1','!1,2-3,4-']:
   childId=c['tree']['children'][0]['id'];prefix=c['tree']['name']!='columnrange'
   evaluations=0 if opt else 1 if prefix else c['dirs']
   assert r['evaluateTrace1'].count('E:'+childId)==evaluations,c['id']
 for path in paths:
  receipt=json.loads(path.with_suffix('.receipt.json').read_bytes())
  plans=load('native-build-plan.json')
  plan=next(p for p in plans['runs'] if p['executable']==receipt['executable'])
  assert receipt['command']==[plan['executable']] and receipt['compileReceipt']==plan['compileReceipt']
  assert sha(pathlib.Path(plans['compiler']).read_bytes())==plans['compilerSha256']
  assert receipt['exitCode']==0 and receipt['timeout'] is False
  assert receipt['stdoutEof'] and receipt['stderrEof'] and receipt['heldProcessHandleSignaled']
  assert receipt['pid']>0 and receipt['birthFileTime']>0
  assert receipt['createdSuspended'] and receipt['jobAssignedBeforeResume'] and receipt['resumeSucceeded']
  assert receipt['initialThreadId']>0 and receipt['resumePreviousSuspendCount']==1
  assert receipt['stdoutSha256']==sha(path.read_bytes())
  assert receipt['stdoutSha256']==sha(pathlib.Path(receipt['stdoutPath']).read_bytes())
  assert receipt['stderrSha256']==sha(pathlib.Path(receipt['stderrPath']).read_bytes())
  assert receipt['stderrSha256']==sha(b'')
  assert receipt['preparedInputsSha256']==sha((R/'prepared-inputs.json').read_bytes())
  assert receipt['executableSha256']==sha(pathlib.Path(receipt['executable']).read_bytes())
  assert receipt['casesSha256']==sha((R/'cases.json').read_bytes())
  compile_receipt=json.loads(pathlib.Path(receipt['compileReceipt']).read_bytes())
  assert compile_receipt['exitCode']==0 and not compile_receipt['timeout']
  assert compile_receipt['preparedInputsSha256']==receipt['preparedInputsSha256']
  assert compile_receipt['stdoutEof'] and compile_receipt['stderrEof']
  assert compile_receipt['executableSha256']==receipt['executableSha256']
  assert compile_receipt['compilerSha256']==plans['compilerSha256']
  assert len(compile_receipt['commands'])==len(plan['commands'])
  assert all(x['exitCode']==0 and not x['timeout'] and x['stdoutEof'] and x['stderrEof'] for x in compile_receipt['commands'])
  for command,planned in zip(compile_receipt['commands'],plan['commands']):
   assert command['command']==['cmd.exe','/d','/c',str(R/planned['wrapper'])]
   assert command['pid']>0 and command['birthFileTime']>0 and command['heldProcessHandleSignaled']
   assert command['createdSuspended'] and command['jobAssignedBeforeResume'] and command['resumeSucceeded']
   assert command['initialThreadId']>0 and command['resumePreviousSuspendCount']==1
   assert sha(pathlib.Path(command['stdoutPath']).read_bytes())==command['stdoutSha256']
   assert sha(pathlib.Path(command['stderrPath']).read_bytes())==command['stderrSha256']
 assert paths[0].with_suffix('.receipt.json')!=paths[1].with_suffix('.receipt.json')
 first=json.loads(paths[0].with_suffix('.receipt.json').read_bytes());second=json.loads(paths[1].with_suffix('.receipt.json').read_bytes())
 assert (first['pid'],first['birthFileTime'])!=(second['pid'],second['birthFileTime']) and first['compileReceipt']!=second['compileReceipt'] and first['executable']!=second['executable']
 return dict(passed=True,nativeRowsPerRun=len(rows),independentCompiles=2,independentChildren=2,fullParserExecuted=False)
def main():
 p=argparse.ArgumentParser();p.add_argument('--unfrozen',action='store_true');p.add_argument('--native',type=pathlib.Path,nargs=2);a=p.parse_args()
 result=prepared_checks(not a.unfrozen)
 if a.native:result=native_checks(a.native)
 print(json.dumps(result))
if __name__=='__main__':main()
