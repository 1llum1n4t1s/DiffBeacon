"""Finite-schema rejection probes; synthetic mutations are not native evidence."""
import copy,collections
def check(rows,cases,validate,typed_value):
 byid={c['id']:(c,r) for c,r in zip(cases,rows)};counts=collections.Counter();labels=set()
 def reject(label,c,r):
  assert label not in labels;labels.add(label)
  try:validate(r,c)
  except AssertionError:counts[label.split(':')[0]]+=1
  else:raise AssertionError(('finite schema accepted mutation',label))
 def changed(label,base,field,value):
  c,r=base;mutant=copy.deepcopy(r);mutant[field]=value;reject(label,c,mutant)
 base=byid['c00000'];rejected=byid['c03840']
 originals=[('review-six:complete-phase',base,'phase','compile-rejected'),('review-six:eval2-optimize',base,'evaluateTrace2',['O:n0000']),('review-six:value2-kind',base,'value2',dict(kind='invented')),('review-six:after-class',base,'after',dict(id='n0000',**{'class':'invented'})),('review-six:reject-value2',rejected,'value2',dict(kind='integer',decimal='1')),('review-six:reject-eval2',rejected,'evaluateTrace2',['E:n0000'])]
 for label,pair,field,value in originals:changed(label,pair,field,value)
 c,r=base
 for field in r:
  mutant=copy.deepcopy(r);del mutant[field];reject('row-missing:'+field,c,mutant)
  changed('row-type:'+field,base,field,None)
 mutant=copy.deepcopy(r);mutant['invented']=None;reject('row-extra:unknown',c,mutant)
 for field,value in [('compileCode',False),('compileCode',0.0),('compileCode',9),('phase','evaluate'),('errorUtf8Hex','78'),('compileMessageUtf8Hex','78')]:
  changed('row-finite:'+field+repr(value),base,field,value)
 for field in r['context']:
  mutant=copy.deepcopy(r);del mutant['context'][field];reject('context-missing:'+field,c,mutant)
  mutant=copy.deepcopy(r);mutant['context'][field]=0 if field.endswith('Null') else True;reject('context-type:'+field,c,mutant)
 mutant=copy.deepcopy(r);mutant['context']['unknown']=True;reject('context-extra:unknown',c,mutant)
 for field in ['optimizeTrace','evaluateTrace1','evaluateTrace2']:
  for event in [True,'X:n0000','E:n9999','L:wrong:00','L:0:0','L:0:GG','L:2147483648:00']:
   changed('trace:'+field+repr(event),base,field,[event])
 for field in ['evaluateTrace1','evaluateTrace2']:
  changed('trace-eval-opt:'+field,base,field,['O:n0000'])
 for field in ['readsCompile','reads1','reads2']:
  for value in [[True],['unknown'],['inputs/c99999.tsv']]:changed('reads:'+field+repr(value),base,field,value)
 for field in ['errorUtf8Hex','compileMessageUtf8Hex','runtimeError1Utf8Hex','runtimeError2Utf8Hex']:
  for value in [False,0,'0','GG']:
   changed('hex:'+field+repr(value),base,field,value)
 for index in (1,2):
  changed('success-xor:empty-'+str(index),base,'value'+str(index),None)
  changed('success-xor:both-'+str(index),base,'runtimeError'+str(index)+'Utf8Hex','78')
  changed('reject-state:value-'+str(index),rejected,'value'+str(index),dict(kind='none'))
  changed('reject-state:trace-'+str(index),rejected,'evaluateTrace'+str(index),['E:n0000'])
  changed('reject-state:error-'+str(index),rejected,'runtimeError'+str(index)+'Utf8Hex','78')
 changed('reject-state:phase',rejected,'phase','complete')
 changed('reject-state:message',rejected,'compileMessageUtf8Hex','')
 for field in ['readsCompile','reads1','reads2']:changed('reject-state:'+field,rejected,field,['inputs/c03840.tsv'])
 values=[dict(kind='none'),dict(kind='bool',value=True),dict(kind='integer',decimal='-9223372036854775808'),dict(kind='double',hexfloat='-0x1.8p+0'),dict(kind='string',utf8Hex='00ff'),dict(kind='timestamp',epochMicroseconds='1700000000123456'),dict(kind='opaque-native-regex'),dict(kind='array',items=[dict(kind='none'),dict(kind='bool',value=False)])]
 for value in values:
  typed_value(value)
  for field in value:
   mutant=copy.deepcopy(value);del mutant[field];changed('value-missing:'+value['kind']+'-'+field,base,'value2',mutant)
  mutant=copy.deepcopy(value);mutant['unknown']=0;changed('value-extra:'+value['kind'],base,'value2',mutant)
 for i,value in enumerate([dict(kind='future'),dict(kind=True),dict(kind='bool',value=1),dict(kind='bool',value=1.0),dict(kind='integer',decimal=True),dict(kind='integer',decimal=7),dict(kind='integer',decimal='01'),dict(kind='integer',decimal='9223372036854775808'),dict(kind='double',hexfloat=1.0),dict(kind='double',hexfloat=True),dict(kind='double',hexfloat='nan'),dict(kind='double',hexfloat='inf'),dict(kind='double',hexfloat='0x1p+99999'),dict(kind='timestamp',epochMicroseconds=False),dict(kind='timestamp',epochMicroseconds=1),dict(kind='timestamp',epochMicroseconds='-0'),dict(kind='string',utf8Hex='0'),dict(kind='string',utf8Hex='FF'),dict(kind='array',items={}),dict(kind='array',items=[dict(kind='invented')]),dict(kind='array',items=[dict(kind='bool',value=0)])]):
  changed('value-type:'+str(i),base,'value2',value)
 # Walk producer ASTs so every actual class gets recursive field/id checks.
 def nodes(n,path):
  if n is None:return
  yield n,path
  for i,child in enumerate(n.get('children',[])):yield from nodes(child,path+['children',i])
 samples={}
 for c,r in zip(cases,rows):
  for field in ['before','after']:
   for n,path in nodes(r[field],[field]):samples.setdefault(n['class'],(c,r,path,n))
 def ast_change(label,sample,mutate):
  c,r,path,n=sample;row=copy.deepcopy(r);target=row
  for part in path:target=target[part]
  mutate(target);reject(label,c,row)
 for kind,sample in samples.items():
  for field in sample[3]:ast_change('ast-missing:'+kind+'-'+field,sample,lambda n,f=field:n.pop(f))
  ast_change('ast-extra:'+kind,sample,lambda n:n.update(unknown=True))
  ast_change('ast-id:'+kind,sample,lambda n:n.update(id=True))
  if 'value'in sample[3]:ast_change('ast-value:'+kind,sample,lambda n:n.update(value=dict(kind='invented')))
 for kind in ['BinaryOpNode','OrNode','AndNode','NotNode','NegateNode','FunctionNode']:
  sample=samples[kind]
  ast_change('ast-children-type:'+kind,sample,lambda n:n.update(children={}))
  ast_change('ast-arity:'+kind,sample,lambda n:n.update(children=[]))
  ast_change('ast-recursive:'+kind,sample,lambda n:n['children'].__setitem__(0,dict(id='n0000',**{'class':'invented'})))
 ast_change('ast-op:bool',samples['BinaryOpNode'],lambda n:n.update(op=True))
 ast_change('ast-op:float',samples['BinaryOpNode'],lambda n:n.update(op=30.0))
 ast_change('ast-op:invented',samples['BinaryOpNode'],lambda n:n.update(op=999))
 ast_change('ast-function:unknown',samples['FunctionNode'],lambda n:n.update(name='invented'))
 ast_change('ast-probe:unknown-fault',samples['Probe'],lambda n:n.update(fault='invented'))
 ast_change('ast-literal:kind-mismatch',samples['IntLiteral'],lambda n:n.update(value=dict(kind='bool',value=True)))
 return dict(rejectedMutations=len(labels),originalSixRejected=True,categories=dict(sorted(counts.items())),astClasses=len(samples),typedValueKinds=len(values),nativeSchemaRows=len(rows),scope='finite producer schema; synthetic mutations only')
