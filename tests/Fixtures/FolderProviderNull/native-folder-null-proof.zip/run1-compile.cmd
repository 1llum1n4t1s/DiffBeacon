@echo off
call "D:\Codex\DiffBeacon\literal-list-20261023-prep01\native-boundary-probe-01\sdk-env.cmd" >nul
if errorlevel 1 exit /b %errorlevel%
"C:\Program Files\Microsoft Visual Studio\18\Community\VC\Tools\MSVC\14.51.36231\bin\Hostx64\x64\cl.exe" @run1-compile.rsp
exit /b %errorlevel%
