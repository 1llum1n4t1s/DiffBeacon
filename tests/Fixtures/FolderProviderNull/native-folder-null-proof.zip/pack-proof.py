import pathlib,json,hashlib,zipfile,binascii
R=pathlib.Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest();cases=json.loads((R/'cases.json').read_bytes());projection=[]
values=dict(integer='1',bool='true',string="'source'",none='None',array='Array()',double='1.5')
for c in cases:
 v=values.get(c['mode']);projection.append(dict(nativeCaseId=c['id'],canonicalFunction=c['function'],expression=None if v is None else c['function']+'('+','.join([v]*c['arity'])+')',executed=False,nativeFullAstObserved=False,nativeContextTriadObserved=True,limitation='controlled throw AST has no asserted public equivalent' if v is None else 'static public notation only; parser/constructor/Optimize/runtime public equivalence unexecuted'))
(R/'public-projection.json').write_text(json.dumps(projection,indent=2)+'\n',encoding='utf8')
files=[p for p in R.iterdir() if p.is_file() and p.suffix not in ['.exe','.obj','.zip'] and p.name not in ['proof-receipt.json','write-check.txt']];index={p.name:dict(size=p.stat().st_size,sha256=sha(p.read_bytes()),crc32=binascii.crc32(p.read_bytes())&0xffffffff) for p in files}
with zipfile.ZipFile(R/'native-folder-null-proof.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files:z.write(p,p.name)
 z.writestr('entry-index.json',json.dumps(index,indent=2)+'\n')
with zipfile.ZipFile(R/'native-folder-null-proof.zip') as z:
 assert z.testzip() is None and set(z.namelist())==set(index)|{'entry-index.json'}
 for n,m in index.items():
  b=z.read(n);assert len(b)==m['size'] and sha(b)==m['sha256'] and z.getinfo(n).CRC==m['crc32']
p=R/'native-folder-null-proof.zip';(R/'proof-receipt.json').write_text(json.dumps(dict(size=p.stat().st_size,sha256=sha(p.read_bytes()),indexedEntries=len(index),allEntryShaSizeCrcVerified=True,excludedReproducible=['two native exe/obj; original source ZIP reused by SHA']),indent=2)+'\n',encoding='utf8');print((R/'proof-receipt.json').read_text(encoding='utf8'))