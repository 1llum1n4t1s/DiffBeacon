// 検証専用接続。inc は固定Git原本bytesの無改変抽出。parserは実行しない。
#define NOMINMAX
#define POCO_OS_FAMILY_WINDOWS
#include <Windows.h>
#include <algorithm>
#include <bit>
#include <cmath>
#include <cstdint>
#include <ctime>
#include <functional>
#include <iomanip>
#include <iostream>
#include <map>
#include <memory>
#include <optional>
#include <sstream>
#include <stdexcept>
#include <string>
#include <variant>
#include <vector>
#define Foundation_API
namespace Poco {
using Int64=int64_t;using UInt32=uint32_t;
class Timespan;
#include "timestamp-class.inc"
#include "timestamp-opeq.inc"
#include "timestamp-opne.inc"
#include "timestamp-opgt.inc"
#include "timestamp-opge.inc"
#include "timestamp-oplt.inc"
#include "timestamp-ople.inc"
#include "timestamp-epoch.inc"
#include "timestamp-default.inc"
#include "timestamp-value.inc"
#include "timestamp-copy.inc"
#include "timestamp-dtor.inc"
#include "timestamp-assign.inc"
#include "timestamp-update.inc"
#include "ascii-class.inc"
#include "ascii-properties.inc"
#include "ascii-isascii.inc"
#include "ascii-hasproperties.inc"
#include "ascii-isupper.inc"
#include "ascii-lower.inc"
#include "ascii-table.inc"
#include "icompare.inc"
struct Exception:std::runtime_error{using std::runtime_error::runtime_error;};
struct RegularExpressionException:Exception{using Exception::Exception;std::string message()const{return what();}};
// typed Timestamp のキー整形は未表現境界。実行しないので代替formatterをgoldenにしない。
struct LocalDateTime{explicit LocalDateTime(Timestamp){throw std::runtime_error("UNSUPPORTED Timestamp formatting reached");}};
struct DateTimeFormatter{static std::string format(LocalDateTime,const char*){throw std::runtime_error("UNSUPPORTED Timestamp formatting reached");}};
struct RegularExpression{};
}
using String=std::string;
namespace ucr{std::string toUTF8(const String& x){return x;}String toTString(const std::string& x){return x;}}
struct FileContentRef{std::string path;};
struct DIFFITEM{};
struct ValueType2;
using ValueType=std::variant<std::monostate,bool,double,int64_t,Poco::Timestamp,std::shared_ptr<Poco::RegularExpression>,std::string,std::shared_ptr<FileContentRef>,std::shared_ptr<std::vector<ValueType2>>>;
struct ValueType2{ValueType value;};
struct FilterExpression;
struct FilterSharedContext;
struct ExprNode;
#include "provider-interface.inc"
#include "context.inc"
#include "statistics-result.inc"
using Range=std::pair<int,int>;
using InsideKey=std::pair<ExprNode*,ExprNode*>;
#include "range-info.inc"
#include "shared-context.inc"
#include "ExprNode.inc"
#include "filter-error-code.inc"
struct FilterExpression{
 bool caseSensitive=true;
 FilterErrorCode errorCode=FILTER_ERROR_NO_ERROR;int errorPosition=-1;
 std::string errorMessage;
 ExprNode* rootNode=nullptr;
 inline static std::function<void(int,const std::string&)> logger;
 std::string TransformLine(const FilterEvalContext&);
};
#include "BoolLiteral.inc"
#include "NoneLiteral.inc"
#include "DoubleLiteral.inc"
#include "IntLiteral.inc"
#include "StringLiteral.inc"
#include "DateTimeLiteral.inc"
#include "ArrayLiteral.inc"
#include "eval-bool.inc"
#include "statistics-process.inc"
#include "statistics-cache.inc"
#include "average.inc"
#include "sum.inc"
#include "maximum.inc"
#include "minimum.inc"
#include "string.inc"
#include "convert-string.inc"
#include "transform-line.inc"
// このhost型は原Vector providerの保管先だけ。encoding/table parserは検証対象外。
struct FileTextEncoding{};
struct TableProps{char quote='"',delimiter=',';bool istable=false;};
#include "vector-provider.inc"
#include "apply-caller.inc"

#include "extract-ranges.inc"
#include "distances.inc"
#include "match-ranges.inc"
#include "matchcount.inc"
#include "matchnumber.inc"
#include "matchdistance-ex.inc"
#include "matchdistance.inc"
#include "matchdistance-before.inc"
#include "matchdistance-after.inc"
#include "matchcontext.inc"
#include "matchblocknumber.inc"
#include "matchblockcount.inc"
#include "matchblocksize.inc"
#include "matchblockoffset.inc"
#include "inside-ranges.inc"
#include "inside.inc"

using Function=ValueType(*)(const FilterEvalContext&,std::vector<ExprNode*>*);
// Host closure binding only; the source constructor/Optimize are deliberately not substituted.
struct FunctionNode:ExprNode{std::vector<ExprNode*>* args;std::function<ValueType(const FilterEvalContext&,std::vector<ExprNode*>*)> func;FunctionNode(Function f,std::vector<ExprNode*>* a):args(a),func(f){}ValueType Evaluate(const FilterEvalContext&)const override;};
#include "function-evaluate.inc"
std::vector<int> trace,optimized;
struct Probe:ExprNode{int index;std::string mode;Probe(int i,std::string m):index(i),mode(m){}ExprNode* Optimize()override{optimized.push_back(index);throw std::runtime_error("adapter-optimize-probe");}ValueType Evaluate(const FilterEvalContext&)const override{trace.push_back(index);if(mode=="throw-all"||mode=="throw-"+std::to_string(index))throw std::runtime_error("adapter-throw-probe");if(mode=="integer")return int64_t(1);if(mode=="bool")return true;if(mode=="string")return std::string("source");if(mode=="array")return std::make_shared<std::vector<ValueType2>>();if(mode=="double")return 1.5;return std::monostate{};}};
void run(const char*id,Function fn,int arity,const char*mode){FilterExpression e;DIFFITEM di;FilterEvalContext c{&e,&di};std::vector<ExprNode*> args;for(int i=0;i<arity;++i)args.push_back(new Probe(i,mode));trace.clear();optimized.clear();std::string error;bool none=false;try{FunctionNode f(fn,&args);auto v=f.Evaluate(c);none=std::holds_alternative<std::monostate>(v);}catch(const std::exception&ex){error=ex.what();}std::cout<<"{\"id\":\""<<id<<"\",\"phase\":\"nativeFunction+originalEvaluate\",\"context\":{\"providerNull\":"<<(c.provider==nullptr?"true":"false")<<",\"sharedContextNull\":"<<(c.sharedContext==nullptr?"true":"false")<<",\"lineIndex\":"<<c.lineIndex<<"},\"value\":{\"kind\":\""<<(none?"none":"unexpected")<<"\"},\"trace\":[";for(size_t i=0;i<trace.size();++i){if(i)std::cout<<",";std::cout<<trace[i];}std::cout<<"],\"optimizeTrace\":[";for(size_t i=0;i<optimized.size();++i){if(i)std::cout<<",";std::cout<<optimized[i];}std::cout<<"],\"error\":\""<<error<<"\"}\n";for(auto*p:args)delete p;}
int main(){
#include "cases.inc"
}
