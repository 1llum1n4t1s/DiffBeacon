import sys
sys.dont_write_bytecode=True
import pathlib,json,hashlib,zipfile,re,importlib.util,subprocess,os,datetime,time,ctypes,binascii
R=pathlib.Path(__file__).resolve().parent;REPO=pathlib.Path(r'D:\Dev\DiffBeacon');F=REPO/'tests/Fixtures';sha=lambda b:hashlib.sha256(b).hexdigest();write=lambda p,b:p.write_bytes(b if isinstance(b,bytes) else b.encode('utf8'))
B=F/'LineTransformAggregates';sm=json.loads((B/'source-manifest.json').read_bytes());archive=F/'LineTransformReplace/reference-source.zip';assert sha(archive.read_bytes())==sm['reusedArchiveSha256'];data={}
with zipfile.ZipFile(archive) as z:
 for s in sm['sources']:
  p=s['path'];b=z.read('original/'+p) if s['origin']=='sibling-fixed-reference-zip' else (B/'additional-original'/p).read_bytes();assert len(b)==s['size'] and sha(b)==s['sha256'] and hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==s['blob'];data[p]=b
source=data['Src/FilterEngine/FilterExpressionNodes.cpp'];assert sha(source)=='a2fcca950bd5e5cfa48f3ff43e4436ae0f5fd55eff9661da1d5a979cc9051135'
spec=importlib.util.spec_from_file_location('cap',B/'capture.py');cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
spans=[];files={};oldproofs=[]
for n in ['LineTransformAggregates','LineTransformMatchMetrics','LineTransformMatches','LineTransformMatchInside']:
 base=F/n;prov=json.loads((base/'provenance.json').read_bytes());assert prov['commit']==sm['commit'];oldproofs.append(dict(path=n+'/native-proof.zip',sha256=sha((base/'native-proof.zip').read_bytes()),provenanceSha256=sha((base/'provenance.json').read_bytes())))
 with zipfile.ZipFile(base/'native-proof.zip') as z:
  assert z.testzip() is None
  for s in prov['extractions']:
   if not s['file']:continue
   p=s['path'];body=data[p][s['startByte']:s['endByte']];assert sha(body)==s['sha256'];compiled=body+(b'\n' if s.get('outerLf',False) else b'');assert z.read('run1/'+s['file'])==compiled
   if s['file'] in files:assert files[s['file']]==compiled
   else:files[s['file']]=compiled;spans.append(s)
for n,b in files.items():write(R/n,b)
def extract(marker,name):
 a,z=cap.block(source,marker);b=source[a:z];write(R/name,b+b'\n');s=dict(file=name,path='Src/FilterEngine/FilterExpressionNodes.cpp',startByte=a,endByte=z,startLine=source[:a].count(b'\n')+1,endLine=source[:z].count(b'\n')+1,sha256=sha(b),outerLf=True);spans.append(s);return s
extract('ValueType FunctionNode::Evaluate(','function-evaluate.inc')
ctor=extract('FunctionNode::FunctionNode(','constructor-source-only.inc');opt=extract('ExprNode* FunctionNode::Optimize()','optimize-source-only.inc')
regs={m.group(1):(m.group(2),int(m.group(3)),int(m.group(4)),m.start(),m.end()) for m in re.finditer(rb'\{"([a-z]+)", ([A-Za-z0-9]+), (\d+), (\d+)\}',source)}
canonical=['Average','Maximum','Minimum','Sum','MatchCount','MatchNumber','MatchDistance','MatchDistanceBefore','MatchDistanceAfter','MatchContext','MatchInside','MatchBlockCount','MatchBlockNumber','MatchBlockOffset','MatchBlockSize']
# 実登録の公開名はnumber/offset/size。表示名も登録から確定する。
wanted=['average','maximum','minimum','sum','matchcount','matchnumber','matchdistance','matchdistancebefore','matchdistanceafter','matchcontext','matchinside','matchblockcount','matchblocknumber','matchblockoffset','matchblocksize']
# 原典登録を確認し、実在する登録名だけを用いる。
for k in ['matchblocknumber','matchblockoffset','matchblocksize']:
 if k.encode() not in regs:
  alias={'matchblocknumber':'number','matchblockoffset':'offset','matchblocksize':'size'}[k];wanted[wanted.index(k)]=alias
functions=[]
for name in wanted:
 fn,lo,hi,a,z=regs[name.encode()];functions.append(dict(name=name,function=fn.decode(),minArgs=lo,maxArgs=hi,registration=dict(startByte=a,endByte=z,startLine=source[:a].count(b'\n')+1,sha256=sha(source[a:z]))))
 assert lo>=1 and hi in [1,2,3]
write(R/'functions.json',json.dumps(functions,indent=2)+'\n')
write(R/'provenance.json',json.dumps(dict(commit=sm['commit'],sourceManifest=sm,sourceArchiveSha256=sha(archive.read_bytes()),sourceCppSha256=sha(source),reusedProofs=oldproofs,extractions=spans,constructorAndOptimizeExecuted=False,originalEvaluateExecuted=True),indent=2)+'\n')
# caller evidence is immutable source-only, not a desktop/provider integration execution.
callers=[]
for path,needle in [('Src/FileFilter.cpp',b'filter->Evaluate(di)'),('Src/FolderCmp.cpp',b'm_pCtxt->m_pAdditionalCompareExpression->Evaluate(di)')]:
 raw=(REPO/path).read_bytes();norm=raw.replace(b'\r\n',b'\n');i=norm.index(needle);line=norm[:i].count(b'\n')+1;callers.append(dict(path=path,normalizedSha256=sha(norm),line=line,expression=needle.decode(),executed=False))
write(R/'caller-source-evidence.json',json.dumps(dict(callers=callers,contextSourceSha256=sha(data['Src/FilterEngine/FilterExpression.h']),nativeContextInitializer='FilterEvalContext{this,&di}',provider=None,sharedContext=None,lineIndex=-1,actualFolderCallerExecuted=False),indent=2)+'\n')
cases=[];lines=[];modes=['throw-all','integer','bool','string','none','array','double']
for f in functions:
 for arity in sorted({f['minArgs'],f['maxArgs']}):
  for mode in modes+['throw-'+str(i) for i in range(arity)]:
   id=f['name']+'-n'+str(arity)+'-'+mode;cases.append(dict(id=id,function=f['name'],nativeFunction=f['function'],arity=arity,mode=mode,phase='nativeFunction+originalEvaluate',context=dict(provider=None,sharedContext=None,lineIndex=-1),expectedKind='none',expectedTrace=[],publicProjectionExecuted=False))
   lines.append('run("'+id+'",'+f['function']+','+str(arity)+',"'+mode+'");')
assert len(cases)==159
failure=dict(functions=15,nativeCases=len(cases),nativePhase='original function body + original FunctionNode::Evaluate with adapter-bound closure; direct AST',failureMatrix=[dict(phase='evaluate',condition='provider=null/sharedContext=null/lineIndex=-1; valid min/max arity; typed/throw probes',expected='None and no argument Evaluate or Optimize',nativeExecuted=True),dict(phase='construct',condition='arity below minimum / above maximum',expected='original InvalidArgumentCountError before Evaluate',nativeExecuted=False,reason='full native constructor has out-of-scope special-family dispatch dependencies; source span retained only'),dict(phase='optimize',condition='child Optimize throws before parent body',expected='failure precedes runtime null-provider guard',nativeExecuted=False,reason='full native Optimize has out-of-scope numeric/date/column dependencies; source span retained only')],excluded=['LineAt/Column six families','nativeFunction direct invalid arity UB','full parser/full constructor/full Optimize/real folder caller'],adapterLimitations=['DIFFITEM host placeholder; no item field access occurs before provider guard','FilterExpression host from existing aggregate adapter','closure bound by host; full constructor not executed','native context/provider/shared-context definitions unchanged','controlled typed/throw AST nodes are adapter','public expression projection remains unexecuted'])
write(R/'failure-matrix.json',json.dumps(failure,indent=2)+'\n');write(R/'cases.json',json.dumps(cases,indent=2)+'\n');write(R/'cases.inc','\n'.join(lines)+'\n')
prefix=(B/'adapter.cpp').read_text(encoding='utf8').split('std::string bytes(')[0]
extra='\n'.join('#include "'+n+'"' for n in ['extract-ranges.inc','distances.inc','match-ranges.inc','matchcount.inc','matchnumber.inc','matchdistance-ex.inc','matchdistance.inc','matchdistance-before.inc','matchdistance-after.inc','matchcontext.inc','matchblocknumber.inc','matchblockcount.inc','matchblocksize.inc','matchblockoffset.inc','inside-ranges.inc','inside.inc'])
runner=r'''
using Function=ValueType(*)(const FilterEvalContext&,std::vector<ExprNode*>*);
// Host closure binding only; the source constructor/Optimize are deliberately not substituted.
struct FunctionNode:ExprNode{std::vector<ExprNode*>* args;std::function<ValueType(const FilterEvalContext&,std::vector<ExprNode*>*)> func;FunctionNode(Function f,std::vector<ExprNode*>* a):args(a),func(f){}ValueType Evaluate(const FilterEvalContext&)const override;};
#include "function-evaluate.inc"
std::vector<int> trace,optimized;
struct Probe:ExprNode{int index;std::string mode;Probe(int i,std::string m):index(i),mode(m){}ExprNode* Optimize()override{optimized.push_back(index);throw std::runtime_error("adapter-optimize-probe");}ValueType Evaluate(const FilterEvalContext&)const override{trace.push_back(index);if(mode=="throw-all"||mode=="throw-"+std::to_string(index))throw std::runtime_error("adapter-throw-probe");if(mode=="integer")return int64_t(1);if(mode=="bool")return true;if(mode=="string")return std::string("source");if(mode=="array")return std::make_shared<std::vector<ValueType2>>();if(mode=="double")return 1.5;return std::monostate{};}};
void run(const char*id,Function fn,int arity,const char*mode){FilterExpression e;DIFFITEM di;FilterEvalContext c{&e,&di};std::vector<ExprNode*> args;for(int i=0;i<arity;++i)args.push_back(new Probe(i,mode));trace.clear();optimized.clear();std::string error;bool none=false;try{FunctionNode f(fn,&args);auto v=f.Evaluate(c);none=std::holds_alternative<std::monostate>(v);}catch(const std::exception&ex){error=ex.what();}std::cout<<"{\"id\":\""<<id<<"\",\"phase\":\"nativeFunction+originalEvaluate\",\"context\":{\"providerNull\":"<<(c.provider==nullptr?"true":"false")<<",\"sharedContextNull\":"<<(c.sharedContext==nullptr?"true":"false")<<",\"lineIndex\":"<<c.lineIndex<<"},\"value\":{\"kind\":\""<<(none?"none":"unexpected")<<"\"},\"trace\":[";for(size_t i=0;i<trace.size();++i){if(i)std::cout<<",";std::cout<<trace[i];}std::cout<<"],\"optimizeTrace\":[";for(size_t i=0;i<optimized.size();++i){if(i)std::cout<<",";std::cout<<optimized[i];}std::cout<<"],\"error\":\""<<error<<"\"}\n";for(auto*p:args)delete p;}
int main(){
#include "cases.inc"
}
'''
write(R/'adapter.cpp',prefix+extra+'\n'+runner)
compiler=pathlib.Path(r'C:\Program Files\Microsoft Visual Studio\18\Community\VC\Tools\MSVC\14.51.36231\bin\Hostx64\x64\cl.exe');sdk=pathlib.Path(r'D:\Codex\DiffBeacon\literal-list-20261023-prep01\native-boundary-probe-01\sdk-env.cmd');write(R/'sdk-env-used.cmd',sdk.read_bytes());(R/'compiler-temp').mkdir();env=dict(os.environ,TEMP=str(R/'compiler-temp'),TMP=str(R/'compiler-temp'))
class FT(ctypes.Structure):_fields_=[('low',ctypes.c_uint32),('high',ctypes.c_uint32)]
outputs=[]
for run in ['run1','run2']:
 args=['/nologo','/utf-8','/std:c++20','/EHsc','/O2','/Fe:'+str(R/(run+'.exe')),'/Fo:'+str(R/(run+'.obj')),str(R/'adapter.cpp')];write(R/(run+'-compile.rsp'),'\n'.join('"'+x+'"' for x in args));write(R/(run+'-compile.cmd'),'@echo off\ncall "'+str(sdk)+'" >nul\nif errorlevel 1 exit /b %errorlevel%\n"'+str(compiler)+'" @'+run+'-compile.rsp\nexit /b %errorlevel%\n')
 t=time.monotonic();cp=subprocess.run(['cmd','/c',str(R/(run+'-compile.cmd'))],cwd=R,env=env,capture_output=True,timeout=120);write(R/(run+'-compile.stdout'),cp.stdout);write(R/(run+'-compile.stderr'),cp.stderr);write(R/(run+'-compile-receipt.json'),json.dumps(dict(exitCode=cp.returncode,timeout=False,stdoutEof=True,stderrEof=True,elapsedSeconds=time.monotonic()-t,compilerSha256=sha(compiler.read_bytes()),arguments=args,TEMP=env['TEMP'],TMP=env['TMP'],inputSha256={p.name:sha(p.read_bytes()) for p in R.iterdir() if p.suffix in ['.inc','.cpp','.rsp']}),indent=2)+'\n');assert cp.returncode==0,'compile failed: '+run
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic();proc=subprocess.Popen([str(R/(run+'.exe'))],cwd=R,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);times=[FT() for _ in range(4)];handle=ctypes.c_void_p(int(proc._handle));assert ctypes.windll.kernel32.GetProcessTimes(handle,*[ctypes.byref(t) for t in times]);birth=(times[0].high<<32)|times[0].low;timed=False
 try:out,err=proc.communicate(timeout=30)
 except subprocess.TimeoutExpired:timed=True;proc.kill();out,err=proc.communicate(timeout=10)
 signaled=ctypes.windll.kernel32.WaitForSingleObject(handle,0)==0;write(R/(run+'-golden.ndjson'),out);write(R/(run+'-reference.stderr'),err)
 receipt=dict(pid=proc.pid,birthFileTime=birth,heldProcessHandleSignaled=signaled,startedUtc=start,endedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsedSeconds=time.monotonic()-t,exitCode=proc.returncode,timeout=timed,stdoutEof=True,stderrEof=True,stdoutSha256=sha(out),stderrSha256=sha(err),casesSha256=sha((R/'cases.json').read_bytes()),executableSha256=sha((R/(run+'.exe')).read_bytes()));write(R/(run+'-receipt.json'),json.dumps(receipt,indent=2)+'\n');assert proc.returncode==0 and signaled and not timed and not err
 rows=[json.loads(l) for l in out.splitlines()];assert len(rows)==len(cases) and [g['id'] for g in rows]==[c['id'] for c in cases]
 for g in rows:assert g['context']==dict(providerNull=True,sharedContextNull=True,lineIndex=-1) and g['value']==dict(kind='none') and g['trace']==[] and g['optimizeTrace']==[] and not g['error']
 outputs.append(out);print(json.dumps(dict(run=run,caseCount=len(rows),**receipt)),flush=True)
assert outputs[0]==outputs[1]
write(R/'comparison.json',json.dumps(dict(passed=True,functions=15,cases=159,independentCompiles=2,independentChildren=2,allStdoutBytesMatch=True,everyArgumentUnevaluated=True,allValuesNone=True,contextTriad=dict(provider=None,sharedContext=None,lineIndex=-1),nativeConstructorExecuted=False,nativeOptimizeExecuted=False,originalEvaluateExecuted=True,productExecuted=False),indent=2)+'\n');print((R/'comparison.json').read_text(),flush=True)