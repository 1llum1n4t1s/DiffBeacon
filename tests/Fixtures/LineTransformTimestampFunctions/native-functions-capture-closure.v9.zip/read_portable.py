"""Portable read-only proof of retained source/raw/candidate; never launches a process."""
import pathlib,json,hashlib,zipfile
S=pathlib.Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(pathlib.Path(p).read_text(encoding='utf-8'))
m=load(S/'closure-manifest.json')
for x in m['files']:assert (S/x['path']).stat().st_size==x['size'] and sha(S/x['path'])==x['sha256']
with zipfile.ZipFile(S/'reference-source.zip') as z:
    assert len(z.infolist())==394 and z.testzip() is None
    nodes=z.read('source/Src/FilterEngine/FilterExpressionNodes.cpp');assert hashlib.sha256(nodes).hexdigest()=='a2fcca950bd5e5cfa48f3ff43e4436ae0f5fd55eff9661da1d5a979cc9051135'
    spans={'toLocalDateTime':(1684,1691),'applyToScalarOrArray':(1693,1704),'ToDateStrFunc':(2145,2155),'ToDateTimeFunc':(2642,2660)}
    for f in (S/'original-pieces').glob('*.inc'):
        if f.stem in spans:lo,hi=spans[f.stem];expected=b''.join(nodes.splitlines(keepends=True)[lo-1:hi])
        else:expected=z.read('original-pieces/'+f.name)
        assert f.read_bytes()==expected
    assert (S/'timestamp_original.hpp').read_bytes()==z.read('adapter/timestamp_original.hpp')
caseplan=load(S/'execution-case-plan.v5.json')['cases'];result=load(S/'execution-result.v9.json');captures=[]
for receipt in result['receipts']:
    assert receipt==load(S/'proof'/(receipt['id']+'.receipt.json'))
    assert receipt['osExitCode']==0 and receipt['birthValidatedOnHeldHandleAfterExit'] and receipt['handleHeldThroughOsExitAndBothEof'] and receipt['jobAssignedBeforeResume']
    for channel in ('stdout','stderr'):assert receipt[channel]['eof'] and sha(S/'proof'/pathlib.Path(receipt[channel]['path']).name)==receipt[channel]['sha256']
    if receipt['id'].startswith('native-run-'):
        rows=[json.loads(line) for line in (S/'proof'/(receipt['id']+'.stdout.raw')).read_text(encoding='utf-8').splitlines()];assert len(rows)==121
        for row,case in zip(rows,caseplan):assert row['id']==case['id'] and row['bodyDidRun']==case['bodyPlanned'] and row['processId']==receipt['pid'] and int(row['processBirthFileTimeDecimal'])==receipt['birthFileTime']
        assert sum(r['bodyDidRun'] for r in rows)==111;captures.append(rows)
exclude={'processId','processBirthFileTimeDecimal','clockBeforeEpochMicrosecondsInt64Decimal','clockAfterEpochMicrosecondsInt64Decimal'}
stable=lambda rows:[{k:v for k,v in r.items() if k not in exclude} for r in rows];assert stable(captures[0])==stable(captures[1])
candidate=load(S/'native-golden-candidate.v9.json');assert len(candidate['entries'])==111 and len(candidate['excludedNoGolden'])==10
assert not candidate['coverageGap']['ToDateTimeNonSyntaxExceptionNativeObserved']
assert all(r['result'] is None for r in captures[0] if not r['bodyDidRun'])
print(json.dumps({'status':'portable-capture-closure-pass','fixedSourceEntries':394,'rawRuns':2,'rowsEach':121,'bodyEach':111,'noGoldenExcludes':10,'twoRunStable':True,'newNativeRun':0,'ToDateTimeNonSyntaxNativeObserved':False}))
