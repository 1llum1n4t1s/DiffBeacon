// SPDX-License-Identifier: GPL-2.0-or-later
// 検証専用PREP。原典bodyのみを呼び、parser/AST/Optimizeは呼ばない。
#include "timestamp_original.hpp"
#include "toLocalDateTime.inc"
#include "applyToScalarOrArray.inc"
#include "ToDateStrFunc.inc"
#include "ToDateTimeFunc.inc"
#include <iostream>
#include <sstream>
#include <typeinfo>
#include <limits>
#include <functional>

static std::string Hex(const std::string& s) {
    static const char alphabet[]="0123456789abcdef";
    std::string out; for(unsigned char c:s){out+=alphabet[c>>4];out+=alphabet[c&15];}return out;
}
static std::string Q(const std::string& s) {
    std::string out="\"";for(unsigned char c:s){if(c=='"'||c=='\\')out+='\\';if(c<32)throw std::invalid_argument("raw control in JSON envelope");out+=char(c);}return out+'"';
}
static std::string DecodeHex(const char* h) {
    std::string s(h),out;if(s.size()%2||s.size()>512)throw std::invalid_argument("case hex length");
    auto digit=[](char c)->int {if(c>='0'&&c<='9')return c-'0';if(c>='a'&&c<='f')return c-'a'+10;throw std::invalid_argument("case hex digit");};
    for(std::size_t i=0;i<s.size();i+=2)out+=char((digit(s[i])<<4)|digit(s[i+1]));return out;
}
static ValueType MakeArray(std::initializer_list<ValueType> items) {
    auto a=std::make_shared<std::vector<ValueType2>>();for(const auto& v:items)a->push_back(ValueType2{v});return a;
}
struct AdapterArgNode final:ExprNode {
    ValueType originalValue;explicit AdapterArgNode(ValueType value):originalValue(std::move(value)){}
    ValueType Evaluate(const FilterEvalContext&) const override{return originalValue;}
};
static bool UtcArithmeticSafe(std::int64_t t) {
    // 原典では _ts*10 + highBias + lowBias。各演算をoverflowせず判定する。
    constexpr std::int64_t low=std::numeric_limits<std::int64_t>::min()/10;
    constexpr std::int64_t high=(std::numeric_limits<std::int64_t>::max()-122192928000000000LL)/10;
    return t>=low&&t<=high;
}
static std::string RawValue(const ValueType& v,bool serialize) {
    std::ostringstream o;o<<"{\"variantIndex\":"<<v.index();
    if(std::holds_alternative<std::monostate>(v))o<<",\"kind\":\"none\"";
    else if(auto b=std::get_if<bool>(&v))o<<",\"kind\":\"bool\",\"value\":"<<(*b?"true":"false");
    else if(auto d=std::get_if<double>(&v))o<<",\"kind\":\"double\",\"value\":"<<*d;
    else if(auto i=std::get_if<std::int64_t>(&v))o<<",\"kind\":\"int64\",\"valueDecimal\":"<<Q(std::to_string(*i));
    else if(auto s=std::get_if<std::string>(&v))o<<",\"kind\":\"string\",\"utf8Hex\":"<<Q(Hex(*s));
    else if(auto t=std::get_if<Poco::Timestamp>(&v)) {
        const auto epoch=t->epochMicroseconds();o<<",\"kind\":\"timestamp\",\"epochSignedInt64Decimal\":"<<Q(std::to_string(epoch));
        const bool safe=UtcArithmeticSafe(epoch);o<<",\"serializerResultSemantics\":\"original arm may catch Poco exception and return what bytes; distinct from function-body exception\"";o<<",\"serializerRequested\":"<<(serialize?"true":"false")<<",\"serializerDidRun\":"<<(serialize&&safe?"true":"false");
        if(!serialize||!safe)o<<",\"serializedUtf8Hex\":null,\"serializationStatus\":"<<Q(serialize?"not-run-unsafe-original-utcTime":"not-requested-storage-only");
        else {try{const auto text=SerializeTimestampArmOnly(v);o<<",\"serializedUtf8Hex\":"<<Q(Hex(text))<<",\"serializationStatus\":\"original-timestamp-arm-returned\"";}
            catch(const Poco::Exception& e){o<<",\"serializedUtf8Hex\":null,\"serializationStatus\":\"exception\",\"serializerExceptionTypeHex\":"<<Q(Hex(typeid(e).name()))<<",\"serializerExceptionNameHex\":"<<Q(Hex(e.name()))<<",\"serializerExceptionMessageHex\":"<<Q(Hex(e.displayText()));}
            catch(const std::exception& e){o<<",\"serializedUtf8Hex\":null,\"serializationStatus\":\"exception\",\"serializerExceptionTypeHex\":"<<Q(Hex(typeid(e).name()))<<",\"serializerExceptionMessageHex\":"<<Q(Hex(e.what()));}}
    }
    else if(auto a=std::get_if<std::shared_ptr<std::vector<ValueType2>>>(&v)){
        o<<",\"kind\":\"array\",\"nullPointer\":"<<(*a?"false":"true")<<",\"items\":";
        if(!*a)o<<"null";else {o<<'[';bool first=true;for(const auto& item:**a){if(!first)o<<',';first=false;o<<RawValue(item.value,serialize);}o<<']';}
    } else throw std::logic_error("adapter protocol excludes other original variant alternatives");
    return o.str()+"}";
}
struct Case {const char* id;bool isDateTime;bool bodyPlanned;bool noArgs;std::function<ValueType()> value;};
static const Case cases[]={
#include "cases.inc"
};
static std::uint64_t Birth() {
    FILETIME b{},e{},k{},u{};if(!GetProcessTimes(GetCurrentProcess(),&b,&e,&k,&u))throw std::runtime_error("birth capture failure");return (std::uint64_t(b.dwHighDateTime)<<32)|b.dwLowDateTime;
}
int main(int argc,char**) {
    if(argc!=1)return 64;
    try {
        wchar_t loc[LOCALE_NAME_MAX_LENGTH]{};if(!GetUserDefaultLocaleName(loc,LOCALE_NAME_MAX_LENGTH))throw std::runtime_error("locale capture failure");
        TIME_ZONE_INFORMATION zone{};auto state=GetTimeZoneInformation(&zone);if(state==TIME_ZONE_ID_INVALID)throw std::runtime_error("zone capture failure");
        const auto pid=GetCurrentProcessId();const auto birth=Birth();
        for(const auto& c:cases){
            FilterEvalContext context{};if(context.expr||context.di||context.provider||context.sharedContext||context.lineIndex!=-1)throw std::logic_error("context defaults");
            if(!GetUserDefaultLocaleName(loc,LOCALE_NAME_MAX_LENGTH))throw std::runtime_error("locale capture failure");
            state=GetTimeZoneInformation(&zone);if(state==TIME_ZONE_ID_INVALID)throw std::runtime_error("zone capture failure");
            const DWORD lcid=GetUserDefaultLCID();
            if(lcid!=1041 || ucr::toUTF8(String(loc))!="ja-JP" || state!=0 || zone.Bias!=-540 || zone.StandardBias!=0 || zone.DaylightBias!=-60 || Hex(ucr::toUTF8(String(zone.StandardName)))!="e69db1e4baac2028e6a899e6ba96e6998229")throw std::runtime_error("natural fixed host profile mismatch before original body");
            auto before=Poco::Timestamp().epochMicroseconds();auto tzd=Poco::Timezone::tzd();
            if(tzd!=32400)throw std::runtime_error("natural fixed Tzd mismatch before original body");
            ValueType input=c.value();AdapterArgNode argument(input);std::vector<ExprNode*> args;if(!c.noArgs)args.push_back(&argument);
            std::string raw="null",status="not-run-static-guard",type="null",name="null",message="null";
            if(c.bodyPlanned){try{auto value=c.isDateTime?ToDateTimeFunc(context,&args):ToDateStrFunc(context,&args);raw=RawValue(value,true);status="ok";}
                catch(const Poco::Exception& e){status="exception";type=Q(Hex(typeid(e).name()));name=Q(Hex(e.name()));message=Q(Hex(e.displayText()));}
                catch(const std::exception& e){status="exception";type=Q(Hex(typeid(e).name()));message=Q(Hex(e.what()));}}
            auto after=Poco::Timestamp().epochMicroseconds();
            std::cout<<"{\"id\":"<<Q(c.id)<<",\"function\":"<<Q(c.isDateTime?"todatetime":"todatestr")<<",\"sourceCommit\":\"6780924ba35f7f55af0f6f14dd302561175830a6\",\"originalNodesSha256\":\"a2fcca950bd5e5cfa48f3ff43e4436ae0f5fd55eff9661da1d5a979cc9051135\",\"scope\":\"original-function-body-calls-only\",\"bodyDidRun\":"<<(c.bodyPlanned?"true":"false")<<",\"status\":"<<Q(status)<<",\"input\":"<<RawValue(input,false)<<",\"result\":"<<raw<<",\"exceptionTypeNameHex\":"<<type<<",\"exceptionNameHex\":"<<name<<",\"exceptionMessageHex\":"<<message
                <<",\"contextLineIndex\":"<<context.lineIndex<<",\"contextPointersNull\":true,\"processId\":"<<pid<<",\"processBirthFileTimeDecimal\":"<<Q(std::to_string(birth))<<",\"userLcid\":"<<lcid<<",\"userLocaleUtf8Hex\":"<<Q(Hex(ucr::toUTF8(String(loc))))<<",\"timezoneState\":"<<state<<",\"timezoneStandardNameUtf8Hex\":"<<Q(Hex(ucr::toUTF8(String(zone.StandardName))))<<",\"timezoneBiasMinutes\":"<<zone.Bias<<",\"timezoneStandardBiasMinutes\":"<<zone.StandardBias<<",\"timezoneDaylightBiasMinutes\":"<<zone.DaylightBias<<",\"pocoTimezoneTzdSeconds\":"<<tzd<<",\"clockBeforeEpochMicrosecondsInt64Decimal\":"<<Q(std::to_string(before))<<",\"clockAfterEpochMicrosecondsInt64Decimal\":"<<Q(std::to_string(after))<<"}\n";
            if(!std::cout)return 74;
        }std::cout.flush();return std::cout?0:74;
    }catch(const std::exception& e){std::cerr<<"adapter envelope failure: "<<e.what()<<'\n';return 70;}
}
