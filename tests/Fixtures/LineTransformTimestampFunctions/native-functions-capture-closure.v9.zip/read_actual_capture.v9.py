"""Read-only qualification of the already completed capture; new candidate/statistics only."""
import pathlib,json,hashlib,collections,zipfile,datetime
S=pathlib.Path(__file__).resolve().parent
K=pathlib.Path(r'C:\Users\IMT\AppData\Local\Codex\TaskArtifacts\DiffBeacon\timestamp-functions-prep-20261012-204724-7421b669\executor-v5')
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(pathlib.Path(p).read_text(encoding='utf-8'))
def new(n,v):
    with (S/n).open('x',encoding='utf-8') as f:f.write(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
authority=load(S/'execution-authority.v9.json');plan=load(S/'native-execution-plan.v9.json');cases=load(S/plan['casePlan'])['cases'];manifest=load(S/plan['sourceManifest'])
assert sha(S/'parent-exact-execution-go.v9.json')=='52b26607f291af9e3c449d9661e9fa2ec5325eed71da15e2db662f52364012c1'
go=load(S/'parent-exact-execution-go.v9.json');assert go['approved'] and go['authoritySha256']==sha(S/'execution-authority.v9.json') and go['planSha256']==sha(S/'native-execution-plan.v9.json')
for n,h in authority['pins'].items():assert sha(S/n)==h,('authority input drift',n)
for item in manifest['files']+manifest['objects']+manifest['libraries']:
    assert pathlib.Path(item['path']).stat().st_size==item['size'] and sha(item['path'])==item['sha256'],item['path']
for item in manifest['toolPins'].values():assert sha(item['path'])==item['sha256']
with zipfile.ZipFile(manifest['referenceSourceZip']) as z:
    nodes=z.read('source/Src/FilterEngine/FilterExpressionNodes.cpp');assert hashlib.sha256(nodes).hexdigest()=='a2fcca950bd5e5cfa48f3ff43e4436ae0f5fd55eff9661da1d5a979cc9051135'
    for name,start,end in [('toLocalDateTime',1684,1691),('applyToScalarOrArray',1693,1704),('ToDateStrFunc',2145,2155),('ToDateTimeFunc',2642,2660)]:assert (S/'original-pieces'/(name+'.inc')).read_bytes()==b''.join(nodes.splitlines(keepends=True)[start-1:end])
outer=load(K/'parent-execute-v9-result.json');launch=load(K/'parent-execute-v9-launch.json')
assert outer['pid']==launch['pid'] and outer['birthUtc']==launch['birthUtc'] and outer['exitCode']==0 and outer['terminal'] and outer['heldUntilExit'] and outer['stdoutComplete'] and outer['stderrComplete'] and not outer['timedOut']
assert launch['scriptSha256'].lower()==authority['wrapperSha256'] and sha(S/'run_native_held.v9.py')==authority['wrapperSha256']
result=load(S/'execution-result.v9.json');assert result['status']=='complete-raw-two-function-capture' and (result['compileCount'],result['linkCount'],result['nativeRunCount'],result['caseCount'])==(1,1,2,121)
commands=plan['compileCommands']+[plan['linkCommand']]+plan['nativeRunCommands'];receipts=result['receipts'];assert len(receipts)==len(commands)==4
runrows=[];proof=[]
for receipt,command in zip(receipts,commands):
    assert receipt==load(S/'proof'/(receipt['id']+'.receipt.json')) and receipt['id']==command['id'] and receipt['command']==command['command']
    for flag in ('childCreated','birthCaptured','qualification','birthValidatedOnHeldHandleAfterExit','handleHeldThroughOsExitAndBothEof','jobAssigned','jobAssignedBeforeResume','createdSuspended'):assert receipt[flag] is True,(receipt['id'],flag)
    assert receipt['osExitCode']==0 and receipt['waitForSingleObjectResult']==0 and receipt['osExitFileTime']>=receipt['birthFileTime']>0 and receipt['stopReason'] is None and not receipt['drainErrors'] and not receipt['terminationRequested']
    assert receipt['pythonExitCode'] is None and receipt['executionApi']=='CreateProcessW/GetExitCodeProcess'
    assert receipt['sourcePreflightSha256']==sha(S/plan['sourceManifest']) and receipt['bytesAdditional']<plan['byteBudget']
    for channel in ('stdout','stderr'):
        stream=receipt[channel];assert stream['eof'] and pathlib.Path(stream['path']).stat().st_size==stream['size'] and sha(stream['path'])==stream['sha256']
    for output in receipt.get('outputs',[]):assert pathlib.Path(output['path']).stat().st_size==output['size'] and sha(output['path'])==output['sha256']
    proof.append({'id':receipt['id'],'pid':receipt['pid'],'birthFileTime':receipt['birthFileTime'],'osExitFileTime':receipt['osExitFileTime'],'actualExit0':True,'birthMatched':True,'jobBeforeResume':True,'bothEOF':True,'stdoutSha256':receipt['stdout']['sha256'],'stdoutBytes':receipt['stdout']['size'],'bytesAdditional':receipt['bytesAdditional']})
    if command['kind']=='native':
        rows=[json.loads(line) for line in pathlib.Path(receipt['stdout']['path']).read_text(encoding='utf-8').splitlines()];assert len(rows)==121
        for row,case in zip(rows,cases):
            assert row['id']==case['id'] and row['function']==case['function'] and row['bodyDidRun']==case['bodyPlanned']
            assert row['processId']==receipt['pid'] and int(row['processBirthFileTimeDecimal'])==receipt['birthFileTime']
            assert row['sourceCommit']==manifest['sourceCommit'] and row['originalNodesSha256']==hashlib.sha256(nodes).hexdigest()
            assert (row['userLcid'],row['userLocaleUtf8Hex'],row['timezoneState'],row['timezoneBiasMinutes'],row['timezoneStandardBiasMinutes'],row['timezoneDaylightBiasMinutes'],row['pocoTimezoneTzdSeconds'])==(1041,'6a612d4a50',0,-540,0,-60,32400)
            assert row['timezoneStandardNameUtf8Hex']=='e69db1e4baac2028e6a899e6ba96e6998229' and row['contextLineIndex']==-1 and row['contextPointersNull']
            if not case['bodyPlanned']:assert row['status']=='not-run-static-guard' and row['result'] is None and row['exceptionTypeNameHex'] is None
        assert sum(row['bodyDidRun'] for row in rows)==111 and sum(not row['bodyDidRun'] for row in rows)==10
        runrows.append(rows)
exclude=set(plan['stableCompareExclusions']);stable=lambda rows:[{k:v for k,v in row.items() if k not in exclude} for row in rows]
assert stable(runrows[0])==stable(runrows[1]) and result['sameSemanticAndProfile'] is True
rows=runrows[0];byid={r['id']:r for r in rows}
def typed(v):
    if v is None:return None
    kind=v['kind'];out={'kind':kind,'variantIndex':v['variantIndex']}
    if kind=='timestamp':out['epochSignedInt64Decimal']=v['epochSignedInt64Decimal']
    elif kind=='string':out['utf8Hex']=v['utf8Hex']
    elif kind=='array':out['items']=[typed(x) for x in v['items']]
    return out
def scalar_values(v):
    if v is None:return
    if v['kind']=='array':
        for item in v['items']:yield from scalar_values(item)
    else:yield v
serial_observations=[]
for row in rows:
    for value in scalar_values(row['result']):
        if value['kind']=='timestamp':
            serial_observations.append({'id':row['id'],'epochSignedInt64Decimal':value['epochSignedInt64Decimal'],'serializerDidRun':value['serializerDidRun'],'status':value['serializationStatus'],'rawTimestampArmReturnHex':value['serializedUtf8Hex'],'notFormattedDateSuccessClaim':True})
            if not value['serializerDidRun']:assert value['serializedUtf8Hex'] is None
for fn in ('todatetime','todatestr'):
    for suffix in ('none','bool','int','float'):assert typed(byid[fn+'-'+suffix]['result'])=={'kind':'none','variantIndex':0}
    assert byid[fn+'-dynamic-nul']['bodyDidRun'] is False
    assert byid[fn+'-array-null-pointer']['bodyDidRun'] is False
assert byid['todatetime-unrecognized']['result']['kind']=='none' and byid['todatestr-unrecognized']['status']=='exception'
assert byid['todatetime-no-args']['result']['kind']=='none' and byid['todatestr-no-args']['bodyDidRun'] is False
assert [x['kind'] for x in byid['todatetime-array-mixed']['result']['items']]==['timestamp','none','none','none','none','none']
assert [x['kind'] for x in byid['todatestr-array-mixed']['result']['items']]==['string','none','none','none','string','none']
assert [x['kind'] for x in byid['todatetime-array-invalid-middle']['result']['items']]==['timestamp','none','timestamp']
assert byid['todatestr-array-invalid-middle']['status']=='exception' and byid['todatestr-array-invalid-middle']['result'] is None
counts={fn:{'rows':sum(r['function']==fn for r in rows),'bodyDidRun':sum(r['function']==fn and r['bodyDidRun'] for r in rows),'status':dict(collections.Counter(r['status'] for r in rows if r['function']==fn)),'resultKinds':dict(collections.Counter(r['result']['kind'] for r in rows if r['function']==fn and r['result'] is not None))} for fn in ('todatetime','todatestr')}
exceptions=[{'id':r['id'],'function':r['function'],'typeNameHex':r['exceptionTypeNameHex'],'nameHex':r['exceptionNameHex'],'messageHex':r['exceptionMessageHex'],'typeDisplay':bytes.fromhex(r['exceptionTypeNameHex']).decode('utf-8','replace'),'nameDisplay':bytes.fromhex(r['exceptionNameHex']).decode('utf-8','replace') if r['exceptionNameHex'] is not None else None,'messageDisplay':bytes.fromhex(r['exceptionMessageHex']).decode('utf-8','replace')} for r in rows if r['status']=='exception']
exception_types=dict(collections.Counter(x['typeDisplay'] for x in exceptions))
gap={'ToDateTimeNonSyntaxExceptionNativeObserved':False,'reason':'all59 ToDateTime body candidates returned normally. UTC normalization candidate returned none, not InvalidArgument; propagation remains source-derived only. No extra Native run authorized/performed.','UTCcandidateActual':{fn:typed(byid[fn+'-utc-after-normalization-exception-candidate']['result']) or {'status':'exception','typeNameHex':byid[fn+'-utc-after-normalization-exception-candidate']['exceptionTypeNameHex']} for fn in ('todatetime','todatestr')}}
entries=[];runrefs=[{'path':r['stdout']['path'],'sha256':r['stdout']['sha256']} for r in receipts if r['id'].startswith('native-run-')]
for line,(row,case) in enumerate(zip(rows,cases),1):
    if not row['bodyDidRun']:continue
    entries.append({'id':row['id'],'function':row['function'],'inputDescriptor':case['argument'],'status':row['status'],'typedResult':typed(row['result']),'bodyException':{'typeNameHex':row['exceptionTypeNameHex'],'nameHex':row['exceptionNameHex'],'messageHex':row['exceptionMessageHex']} if row['status']=='exception' else None,'rawReferences':[{'run':i+1,'sha256':runrefs[i]['sha256'],'line':line} for i in range(2)],'TimestampDisplayGoldenGenerated':False})
assert len(entries)==111
new('native-golden-candidate.v9.json',{'schemaVersion':1,'status':'MINIMAL_BODY_RESULT_CANDIDATE_NOT_PRODUCT_ADOPTED','sourceCommit':manifest['sourceCommit'],'nodesSha256':hashlib.sha256(nodes).hexdigest(),'sameProfileOnly':True,'profile':{'LCID':1041,'locale':'ja-JP','timezone':'Tokyo','Tzd':32400},'scope':plan['scope'],'candidateCount':111,'entries':entries,'excludedNoGolden':[r['id'] for r in rows if not r['bodyDidRun']],'serializerDisplayObservationsSeparated':True,'unsafeLocaleEpochStorageIsNotFormattedStringGolden':True,'NativeParserASTOptimizeQualified':False,'coverageGap':gap})
new('native-capture-statistics.v9.json',{'rowsPerRun':121,'bodyCallsPerRun':111,'excludedPerRun':10,'functions':counts,'exceptionTypes':exception_types,'exceptions':exceptions,'TimestampSerializerObservations':serial_observations,'serializerStatusCounts':dict(collections.Counter(x['status'] for x in serial_observations)),'coverageGap':gap,'noNewNativeExecutedByThisReader':True})
new('native-capture-qualified.v9.json',{'status':'ACTUAL_CAPTURE_READER_QUALIFIED','outerProcess':outer,'goSha256':sha(S/'parent-exact-execution-go.v9.json'),'authoritySha256':sha(S/'execution-authority.v9.json'),'sourceManifestSha256':sha(S/plan['sourceManifest']),'actualCounts':{'compile':1,'link':1,'nativeRuns':2,'rowsEach':121,'bodyEach':111,'excludedEach':10},'processProof':proof,'stableRowsEqual':True,'ignoredOnly':list(plan['stableCompareExclusions']),'functions':counts,'exceptionTypes':exception_types,'candidateSha256':sha(S/'native-golden-candidate.v9.json'),'statisticsSha256':sha(S/'native-capture-statistics.v9.json'),'coverageGap':gap,'NativeReexecution':False,'productAdopted':False,'NativeParserASTOptimizeQualified':False,'timeUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
print(json.dumps({'status':'actual-capture-reader-qualified','functions':counts,'exceptionTypes':exception_types,'candidateEntries':111,'skippedNoGolden':10,'twoRunEqual':True,'newNativeRun':0,'ToDateTimeNonSyntaxObserved':False}))
