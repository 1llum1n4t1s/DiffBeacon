import pathlib
R=pathlib.Path(__file__).resolve().parent
original=(R.parent/'capture-casefold.py').read_text(encoding='utf8')
a=original.index("sourcehex='f0909080'");z=original.index('compiler=pathlib.Path(',a)
cases=r'''
INPUT=pathlib.Path(r'D:\Codex\DiffBeacon\supplementary-casefold-20261023-candidate01')
evidence=(INPUT/'fixed-ucd-evidence.json').read_bytes();directraw=(INPUT/'proposed-direct-cases.json').read_bytes();e=json.loads(evidence);pairs=e['pairs'];cases=json.loads(directraw)
assert len(pairs)==e['directions']==564 and len(cases)==1128
assert sha(data['Externals/poco/dependencies/pcre2/src/pcre2_ucd.c'])==e['nativeLfSourceSha256']=='6ebdc9043dcb13832189a45818f767afe9c4d6df078fb37db6d55d80126dce92'
assert e['sourceSha256']=='0fcaf2440147c666a747b3fa3b108012ac30db84cc554d852dfb76b98893716b'
assert len({p['scalar'] for p in pairs})==564
mapping={p['scalar']:p for p in pairs}
for p in pairs:
 assert chr(p['scalar']).encode().hex()==p['scalarUtf8Hex'] and chr(p['other']).encode().hex()==p['otherUtf8Hex'] and mapping[p['other']]['other']==p['scalar']
write(R/'fixed-ucd-evidence.json',evidence);write(R/'proposed-direct-cases.json',directraw)
node=lambda h:'new StringLiteral(bytes({'+','.join(str(x) for x in bytes.fromhex(h))+'}))'
lines=[]
for c in cases:
 scalar=int(c['id'].rsplit('-u',1)[1],16);p=mapping[scalar]
 assert c['needleUtf8Hex']==p['scalarUtf8Hex'] and c['sourceUtf8Hex']==p['otherUtf8Hex'] and c['function']=='Replace' and c['fileUtf8Hex'] is None
 assert c['expectedUtf8HexFromFixedUcd']==(c['sourceUtf8Hex'] if c['caseSensitive'] else '58')
 nodes=','.join(node(c[k]) for k in ['sourceUtf8Hex','needleUtf8Hex','replacementUtf8Hex'])
 lines.append('run("'+c['id']+'",false,'+str(c['caseSensitive']).lower()+',"",false,{'+nodes+'},true);')
forward=[p for p in pairs if p['scalar']<p['other']];assert len(forward)==282
for direction in ['low-needle','high-needle']:
 needlekey,sourcekey=('scalarUtf8Hex','otherUtf8Hex') if direction=='low-needle' else ('otherUtf8Hex','scalarUtf8Hex')
 raw=b''.join(bytes.fromhex(p[needlekey])+b'\tX\n' for p in forward);source=b''.join(bytes.fromhex(p[sourcekey]) for p in forward);path=direction+'.tsv';write(R/path,raw)
 for cs in [False,True]:
  id='replacewithlist-'+direction+('-cs' if cs else '-ci')
  c=dict(id=id,function='ReplaceWithList',caseSensitive=cs,sourceUtf8Hex=source.hex(),listPath=path,fileUtf8Hex=raw.hex(),expectedUtf8HexFromFixedUcd=source.hex() if cs else ('58'*282));cases.append(c)
  lines.append('run("'+id+'",false,'+str(cs).lower()+',"'+path+'",false,{'+node(source.hex())+',new StringLiteral("'+path+'")},false);')
assert len(cases)==1132
write(R/'cases.json',json.dumps(cases,indent=2)+'\n');write(R/'cases.inc','\n'.join(lines)+'\n')
'''
original=original[:a]+cases+original[z:]
a=original.index('start=datetime.datetime')
ending=r'''
class FT(ctypes.Structure):_fields_=[('low',ctypes.c_uint32),('high',ctypes.c_uint32)]
outputs=[];receipts=[]
for run in ['run1','run2']:
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic();proc=subprocess.Popen([str(R/'reference.exe')],cwd=R,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 times=[FT() for _ in range(4)];handle=ctypes.c_void_p(int(proc._handle));assert ctypes.windll.kernel32.GetProcessTimes(handle,*[ctypes.byref(t) for t in times]);birth=(times[0].high<<32)|times[0].low;timed=False
 try:out,err=proc.communicate(timeout=60)
 except subprocess.TimeoutExpired:timed=True;proc.kill();out,err=proc.communicate(timeout=10)
 signaled=ctypes.windll.kernel32.WaitForSingleObject(handle,0)==0
 write(R/(run+'-golden.ndjson'),out);write(R/(run+'-reference.stderr'),err)
 receipt=dict(pid=proc.pid,birthFileTime=birth,heldProcessHandleSignaled=signaled,startedUtc=start,endedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsedSeconds=time.monotonic()-t,exitCode=proc.returncode,timeout=timed,stdoutEof=True,stderrEof=True,stdoutSha256=sha(out),stderrSha256=sha(err),casesSha256=sha((R/'cases.json').read_bytes()),executableSha256=sha((R/'reference.exe').read_bytes()))
 write(R/(run+'-receipt.json'),json.dumps(receipt,indent=2)+'\n');assert proc.returncode==0 and signaled and not timed and not err
 rows=[json.loads(l) for l in out.splitlines()];assert [v['id'] for v in rows]==[c['id'] for c in cases]
 for c,g in zip(cases,rows,strict=True):
  assert not g['errorUtf8Hex'] and not g['loaderLogs'] and not g['functionLogs']
  assert g['value']==dict(kind='string',utf8Hex=c['expectedUtf8HexFromFixedUcd']) and g['serializedUtf8Hex']==c['expectedUtf8HexFromFixedUcd'],c['id']
 outputs.append(out);receipts.append(receipt);print(json.dumps(dict(run=run,**receipt)),flush=True)
assert outputs[0]==outputs[1] and (receipts[0]['pid'],receipts[0]['birthFileTime'])!=(receipts[1]['pid'],receipts[1]['birthFileTime'])
summary=dict(nativeObservedRowsPerChild=1132,directNativeRows=1128,directDirections=564,listNativeRows=4,listBatches=2,listRulesPerBatch=282,independentChildren=2,nativeStdoutAllBytesMatch=True,noThrowEveryRow=True,nativeObservedMatchesFixedTablePredictions=True,fixedTableEvidenceKind=e['evidenceKind'],nativeGoldenSha256=sha(outputs[0]),nativeUcdSourceSha256=e['nativeLfSourceSha256'],fixedTableEvidenceSha256=sha(evidence),directInputSha256=sha(directraw),productExecuted=False,pcreObjectReused=True)
write(R/'observation-summary.json',json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
'''
original=original[:a]+ending
(R/'capture-batch.py').write_text(original,encoding='utf8')