import pathlib,json,hashlib,zipfile,binascii
r=pathlib.Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest()
files=[p for p in r.iterdir() if p.is_file() and p.suffix not in ['.obj','.exe','.zip'] and p.name not in ['proof-receipt.json','write-check.txt']]
index={p.name:dict(size=p.stat().st_size,sha256=sha(p.read_bytes()),crc32=binascii.crc32(p.read_bytes())&0xffffffff) for p in files}
with zipfile.ZipFile(r/'native-casefold-proof.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files:z.write(p,p.name)
 z.writestr('entry-index.json',json.dumps(index,indent=2)+'\n')
with zipfile.ZipFile(r/'native-casefold-proof.zip') as z:
 assert z.testzip() is None and set(z.namelist())==set(index)|{'entry-index.json'}
 for n,m in index.items():
  b=z.read(n);assert sha(b)==m['sha256'] and len(b)==m['size'] and z.getinfo(n).CRC==m['crc32']
p=r/'native-casefold-proof.zip';(r/'proof-receipt.json').write_text(json.dumps(dict(size=p.stat().st_size,sha256=sha(p.read_bytes()),indexedEntries=len(index),allEntryShaSizeCrcVerified=True,excludedReproducible=['reference.exe','adapter.obj','reused PCRE2 source/obj (source SHA and actual object SHA in provenance)']),indent=2)+'\n',encoding='utf8')
print((r/'proof-receipt.json').read_text(encoding='utf8'))