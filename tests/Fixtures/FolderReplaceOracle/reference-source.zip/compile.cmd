@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b %errorlevel%
cl @compile-c.rsp
if errorlevel 1 exit /b %errorlevel%
cl @compile-cpp.rsp
exit /b %errorlevel%
