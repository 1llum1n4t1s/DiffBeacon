using System.Text;
using System.Text.Json;
using DiffBeacon.Core;
var input=JsonDocument.Parse(File.ReadAllBytes(args[0])).RootElement.GetProperty("cases");
foreach(var item in input.EnumerateArray())
{
    var context=item.GetProperty("context");
    if(context.GetProperty("sourceLineCount").GetInt32()!=1 || context.GetProperty("rowIndex").GetInt32()!=0 || context.GetProperty("outerEol").GetInt32()!=0 || context.GetProperty("tableMode").GetBoolean())throw new ArgumentException("unexpected fixed context");
    var originalHex=context.GetProperty("sourceLineHex").GetString()!;
    var source=new UTF8Encoding(false,true).GetString(Convert.FromHexString(originalHex));
    var status="unsupported";var phase="unrepresentable";var error="Fixed plan has no exact public expression";var type="UnrepresentableAdapterType";var key=source;
    var expression=item.GetProperty("expression");
    if(expression.ValueKind==JsonValueKind.String)
    {
        status="ok";phase="compile";error="";type="";
        try
        {
            var plan=LineTransformPlan.Compile([new LineTransformRule(expression.GetString()!,TablePaneMask.Left)],new LineTransformBudget());
            phase="evaluate";key=plan.Transform([source],TablePaneMask.Left,false)[0];phase="";
        }
        catch(Exception e)when(e is ArgumentException or InvalidOperationException or ArithmeticException or OperationCanceledException)
        {status="error";error=e.Message;type=e.GetType().Name;}
    }
    Console.WriteLine(JsonSerializer.Serialize(new {id=item.GetProperty("id").GetString(),classification=item.GetProperty("oracleMatchedOrBoundary").GetString(),status,errorPhase=phase,error,exceptionType=type,originalHex,keyHex=Convert.ToHexString(Encoding.UTF8.GetBytes(key)).ToLowerInvariant(),sourceLineCount=1,rowIndex=0,expression=expression.ValueKind==JsonValueKind.String?expression.GetString():null}));
}
