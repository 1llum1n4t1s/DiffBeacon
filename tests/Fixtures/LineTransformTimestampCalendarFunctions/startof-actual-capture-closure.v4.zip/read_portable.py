"""保存したPREPのpin/構造/件数を移植可能に読む。Nativeを実行しない。"""
import pathlib,json,hashlib,collections,importlib.util,argparse,zipfile
S=pathlib.Path(__file__).resolve().parent
def load(p):return json.loads(pathlib.Path(p).read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def inspect(source_zip=None):
    a=load(S/'execution-authority.json')
    for n,h in a['pins'].items():assert sha(S/n)==h,n
    p=load(S/'native-execution-plan.json');c=load(S/'failure-case-plan.json');m=load(S/'source-preflight-manifest.json')
    assert len(c['cases'])==c['caseCount']==126 and sum(x['bodyPlanned'] for x in c['cases'])==108
    assert all(x['expected'] is None and x['newGolden'] is False for x in c['cases'])
    assert collections.Counter(x['function'] for x in c['cases'])==dict.fromkeys(('startofweek','startofmonth','startofyear'),42)
    assert load(S/'go.schema.json')['properties']['scope']['const']==p['scope']
    assert p['executedCommands']==0 and p['maxCommands']=={'compile':1,'link':1,'nativeRun':2}
    assert p['minimumFreeBytes']==10737418240 and p['byteBudget']==67108864
    text=(S/'native_executor.py').read_text(encoding='utf-8');assert 'ctypes.get_last_error()==109:eof=True;break' in text
    assert '==189' not in text and '==188' not in text
    spec=importlib.util.spec_from_file_location('shape',S/'prove_structure.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    assert mod.prove(S/'native_executor.py')==load(S/'ast-parentage-proof.json')
    for span in m['newOriginalSpans']:assert sha(S/'original-pieces'/(span['name']+'.inc'))==span['sha256']
    if source_zip:
        assert sha(source_zip)==m['referenceSourceZipSha256']
        with zipfile.ZipFile(source_zip) as z:
            lines=z.read('source/Src/FilterEngine/FilterExpressionNodes.cpp').splitlines(keepends=True)
            for x in m['newOriginalSpans']:assert b''.join(lines[x['startLine']-1:x['endLine']])==(S/'original-pieces'/(x['name']+'.inc')).read_bytes()
    return {'status':'portable-prep-pin-and-structure-pass','pins':len(a['pins']),'cases':126,'bodyCandidates':108,'excluded':18,'originalZipBytesChecked':bool(source_zip),'externalToolObjectLibraryCurrentBytesChecked':False,'NativeExecuted':False,'crossOsExecutionMeasured':False}
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--source-zip');args=ap.parse_args();print(json.dumps(inspect(args.source_zip)))
