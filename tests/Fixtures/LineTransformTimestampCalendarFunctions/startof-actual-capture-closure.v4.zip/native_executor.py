"""Frozen three-startof capture executor. Read-only preflight unless exact parent GO exists."""
import argparse, pathlib, json, hashlib, os, time, shutil, subprocess, threading, datetime, re, stat
S=pathlib.Path(__file__).resolve().parent
def load(p):return json.loads(pathlib.Path(p).read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def write_new(p,v):
    with pathlib.Path(p).open('x',encoding='utf-8') as f:f.write(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def preflight():
    authority=load(S/'execution-authority.json')
    for n,h in authority['pins'].items():assert sha(S/n)==h,('authority pin',n)
    p=load(S/'native-execution-plan.json');m=load(S/p['sourceManifest']);c=load(S/p['casePlan']);env=load(S/p['environmentFile'])['values']
    assert p['stage']==str(S) and pathlib.Path(p['work']).resolve()==S
    assert len(c['cases'])==p['maxRawCaptureRecordsPerRun'] and sum(x['bodyPlanned'] for x in c['cases'])==p['maxOriginalBodyCallsPerRun']
    assert len(p['compileCommands'])==1 and len(p['nativeRunCommands'])==2 and p['maxCommands']=={'compile':1,'link':1,'nativeRun':2}
    assert p['executedCommands']==0 and not p['originalRecompileAllowed'] and p['linkObjectCount']==36
    assert '/utf-8' in p['compileCommands'][0]['command'] and '/MD' in p['compileCommands'][0]['command']
    assert p['compileCommands'][0]['source'].endswith('timestamp_startof.cpp')
    assert not any(k.upper() in ('CL','_CL_','LINK','_LINK_') for k in env)
    for x in m['files']+m['objects']+m['libraries']:
        f=pathlib.Path(x['path']);assert f.resolve()==f and f.stat().st_size==x['size'] and sha(f)==x['sha256'],str(f)
    for x in m['toolPins'].values():assert sha(x['path'])==x['sha256']
    objs=[x['path'] for x in m['objects'] if x['includedInNewLink']];assert len(objs)==len(set(objs))==35
    linked=[x for x in p['linkCommand']['command'] if x.endswith('.obj')];assert len(linked)==len(set(linked))==36
    assert set(objs).issubset(linked) and not any('timestamp-native-adapter.obj' in x for x in linked)
    assert sha(m['referenceSourceZip'])==m['referenceSourceZipSha256']
    for root in [S,pathlib.Path(p['ownedWorkRoot']),pathlib.Path(p['ownedKeepRoot'])]:
        assert root.resolve()==root and all(a.lower()!='artifacts' for a in root.parts)
        assert not root.is_relative_to(pathlib.Path(r'C:\Users\IMT\dev\DiffBeacon')) and not root.is_relative_to(pathlib.Path(r'C:\Users\IMT\.codex'))
        for ancestor in [root,*root.parents]:
            if ancestor.exists():assert not (ancestor.stat(follow_symlinks=False).st_file_attributes&0x400),str(ancestor)
    return authority,p,m,c,env
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--execute-parent-go',action='store_true');args=ap.parse_args()
    authority,p,m,c,env=preflight()
    if not args.execute_parent_go:
        assert not (S/'output').exists() and not (S/'proof').exists() and not (S/'execution-started.json').exists()
        print(json.dumps({'status':'readonly-preflight-pass','cases':len(c['cases']),'bodyCandidates':sum(x['bodyPlanned'] for x in c['cases']),'excluded':sum(not x['bodyPlanned'] for x in c['cases']),'NativeCommandsExecuted':0}));return
    go=load(S/p['requiredGoFileName']);expected={'approved':True,'authoritySha256':sha(S/'execution-authority.json'),'planSha256':sha(S/'native-execution-plan.json'),'supervisorSha256':sha(__file__),'wrapperSha256':sha(S/'run_native_held.py'),'casePlanSha256':sha(S/p['casePlan']),'sourceManifestSha256':sha(S/p['sourceManifest']),'scope':p['scope'],'maxCommands':p['maxCommands']}
    assert go==expected,'exact new parent GO mismatch'
    assert shutil.disk_usage(S).free>=p['minimumFreeBytes'],'three-startof capture requires parent-reviewed reserve'
    assert not (S/'execution-started.json').exists() and not (S/'output').exists() and not (S/'proof').exists(),'no automatic retry'
    write_new(S/'execution-started.json',{'startedUtc':utc(),'pid':os.getpid(),'authoritySha256':sha(S/'execution-authority.json'),'parentGo':go,'noRetry':True})
    (S/'output').mkdir();(S/'proof').mkdir();overall=time.monotonic()+p['overallTimeoutSeconds']
    roots=[pathlib.Path(p['ownedWorkRoot']),pathlib.Path(p['ownedKeepRoot'])]
    def bytes_owned():
        total=0
        for root in roots:
            for file in root.rglob('*'):
                try:
                    info=file.stat()
                except FileNotFoundError:
                    # 消失した今回のowned一時物だけ容量0。固定input pin失敗は別のstrict経路。
                    continue
                if stat.S_ISREG(info.st_mode):total+=info.st_size
        return total
    baseline=bytes_owned();receipts=[]
    # Win32 APIs below are initialized only after exact GO and Native reserve check.
    import ctypes
    from ctypes import wintypes as t
    k=ctypes.WinDLL('kernel32',use_last_error=True)
    class SA(ctypes.Structure):_fields_=[('nLength',t.DWORD),('descriptor',ctypes.c_void_p),('inherit',t.BOOL)]
    class SI(ctypes.Structure):_fields_=[('cb',t.DWORD),('reserved',t.LPWSTR),('desktop',t.LPWSTR),('title',t.LPWSTR),('x',t.DWORD),('y',t.DWORD),('xs',t.DWORD),('ys',t.DWORD),('xc',t.DWORD),('yc',t.DWORD),('fill',t.DWORD),('flags',t.DWORD),('show',t.WORD),('reserved2',t.WORD),('reservedPtr',ctypes.POINTER(ctypes.c_byte)),('stdin',t.HANDLE),('stdout',t.HANDLE),('stderr',t.HANDLE)]
    class PI(ctypes.Structure):_fields_=[('process',t.HANDLE),('thread',t.HANDLE),('pid',t.DWORD),('tid',t.DWORD)]
    class SYSTEMTIME(ctypes.Structure):_fields_=[(n,t.WORD) for n in ('year','month','dayOfWeek','day','hour','minute','second','millisecond')]
    class TIMEZONE(ctypes.Structure):_fields_=[('bias',t.LONG),('standardName',t.WCHAR*32),('standardDate',SYSTEMTIME),('standardBias',t.LONG),('daylightName',t.WCHAR*32),('daylightDate',SYSTEMTIME),('daylightBias',t.LONG)]
    class BASIC(ctypes.Structure):_fields_=[('processTime',ctypes.c_longlong),('jobTime',ctypes.c_longlong),('flags',t.DWORD),('minWS',ctypes.c_size_t),('maxWS',ctypes.c_size_t),('active',t.DWORD),('affinity',ctypes.c_size_t),('priority',t.DWORD),('scheduling',t.DWORD)]
    class IO(ctypes.Structure):_fields_=[(n,ctypes.c_ulonglong) for n in ['readOps','writeOps','otherOps','readBytes','writeBytes','otherBytes']]
    class EXT(ctypes.Structure):_fields_=[('basic',BASIC),('io',IO),('processMemory',ctypes.c_size_t),('jobMemory',ctypes.c_size_t),('peakProcess',ctypes.c_size_t),('peakJob',ctypes.c_size_t)]
    specs=[('CreatePipe',[ctypes.POINTER(t.HANDLE),ctypes.POINTER(t.HANDLE),ctypes.POINTER(SA),t.DWORD],t.BOOL),('SetHandleInformation',[t.HANDLE,t.DWORD,t.DWORD],t.BOOL),('CreateFileW',[t.LPCWSTR,t.DWORD,t.DWORD,ctypes.POINTER(SA),t.DWORD,t.DWORD,t.HANDLE],t.HANDLE),('CreateProcessW',[t.LPCWSTR,t.LPWSTR,ctypes.c_void_p,ctypes.c_void_p,t.BOOL,t.DWORD,ctypes.c_void_p,t.LPCWSTR,ctypes.POINTER(SI),ctypes.POINTER(PI)],t.BOOL),('GetProcessId',[t.HANDLE],t.DWORD),('GetProcessTimes',[t.HANDLE,*([ctypes.POINTER(t.FILETIME)]*4)],t.BOOL),('GetExitCodeProcess',[t.HANDLE,ctypes.POINTER(t.DWORD)],t.BOOL),('WaitForSingleObject',[t.HANDLE,t.DWORD],t.DWORD),('ResumeThread',[t.HANDLE],t.DWORD),('ReadFile',[t.HANDLE,ctypes.c_void_p,t.DWORD,ctypes.POINTER(t.DWORD),ctypes.c_void_p],t.BOOL),('CreateJobObjectW',[ctypes.c_void_p,t.LPCWSTR],t.HANDLE),('SetInformationJobObject',[t.HANDLE,ctypes.c_int,ctypes.c_void_p,t.DWORD],t.BOOL),('AssignProcessToJobObject',[t.HANDLE,t.HANDLE],t.BOOL),('TerminateJobObject',[t.HANDLE,t.UINT],t.BOOL),('TerminateProcess',[t.HANDLE,t.UINT],t.BOOL),('CloseHandle',[t.HANDLE],t.BOOL)]
    for n,a,r in specs:getattr(k,n).argtypes=a;getattr(k,n).restype=r
    k.GetTimeZoneInformation.argtypes=[ctypes.POINTER(TIMEZONE)];k.GetTimeZoneInformation.restype=t.DWORD
    k.GetUserDefaultLCID.argtypes=[];k.GetUserDefaultLCID.restype=t.DWORD
    k.GetUserDefaultLocaleName.argtypes=[t.LPWSTR,ctypes.c_int];k.GetUserDefaultLocaleName.restype=ctypes.c_int
    def host_before_image_startup():
        zone=TIMEZONE();state=k.GetTimeZoneInformation(ctypes.byref(zone));loc=ctypes.create_unicode_buffer(85)
        assert state!=0xffffffff and k.GetUserDefaultLocaleName(loc,len(loc))>0
        assert (k.GetUserDefaultLCID(),loc.value,state,zone.bias,zone.standardBias,zone.daylightBias,zone.standardName.encode('utf-8').hex())==(1041,'ja-JP',0,-540,0,-60,'e69db1e4baac2028e6a899e6ba96e6998229'),'natural fixed host profile before Native image startup'
    def times(h):
        v=[t.FILETIME() for _ in range(4)]
        if not k.GetProcessTimes(h,*[ctypes.byref(x) for x in v]):raise OSError(ctypes.get_last_error(),'GetProcessTimes')
        return [(x.dwHighDateTime<<32)|x.dwLowDateTime for x in v]
    def run(item):
        preflight();assert time.monotonic()<overall and shutil.disk_usage(S).free>=p['minimumFreeBytes']
        if item['kind']=='native':host_before_image_startup()
        assert bytes_owned()-baseline<p['byteBudget'];handles=[];pi=PI();assigned=False;resumed=False;job=None;born=None;receipt=None
        channels={};errors=[];too_large=threading.Event();counter=[0];lock=threading.Lock();threads=[];stop=None;terminated=False;launch=utc();child_created=False;pipes=[];nul=None
        def drain(key,h):
            path=S/'proof'/(item['id']+'.'+key+'.raw');digest=hashlib.sha256();size=0;eof=False
            try:
                with path.open('xb') as f:
                    buf=ctypes.create_string_buffer(65536);n=t.DWORD()
                    while True:
                        ok=k.ReadFile(h,buf,len(buf),ctypes.byref(n),None)
                        if not ok:
                            if ctypes.get_last_error()==109:eof=True;break
                            raise OSError(ctypes.get_last_error(),'ReadFile')
                        if n.value==0:eof=True;break
                        b=buf.raw[:n.value]
                        with lock:
                            if counter[0]+len(b)>p['nativeCombinedStreamCap'] or bytes_owned()-baseline+len(b)>p['byteBudget']:too_large.set();raise RuntimeError('owned byte cap before stream write')
                            f.write(b);f.flush();counter[0]+=len(b);size+=len(b);digest.update(b)
            except Exception as e:errors.append(str(e));too_large.set()
            channels[key]={'path':str(path),'sha256':digest.hexdigest(),'size':size,'eof':eof,'eofUtc':utc() if eof else None}
        def close_parent_writes():
            for _,_,wr in pipes:
                if wr in handles:k.CloseHandle(wr);handles.remove(wr)
            if nul in handles:k.CloseHandle(nul);handles.remove(nul)
        def start_drains():
            if threads:return
            for key,rd,_ in pipes:
                th=threading.Thread(target=drain,args=(key,rd),daemon=True);threads.append(th);th.start()
        try:
            job=k.CreateJobObjectW(None,None);assert job;handles.append(job);limits=EXT();limits.basic.flags=0x2000;assert k.SetInformationJobObject(job,9,ctypes.byref(limits),ctypes.sizeof(limits))
            sa=SA(ctypes.sizeof(SA),None,True);pipes=[]
            for key in ('stdout','stderr'):
                rd=t.HANDLE();wr=t.HANDLE();assert k.CreatePipe(ctypes.byref(rd),ctypes.byref(wr),ctypes.byref(sa),0);handles.extend([rd.value,wr.value]);assert k.SetHandleInformation(rd,1,0);pipes.append((key,rd.value,wr.value))
            nul=k.CreateFileW('NUL',0x80000000,3,ctypes.byref(sa),3,0,None);assert nul not in (None,ctypes.c_void_p(-1).value);handles.append(nul)
            si=SI();si.cb=ctypes.sizeof(SI);si.flags=0x100;si.stdin=nul;si.stdout=pipes[0][2];si.stderr=pipes[1][2]
            block=ctypes.create_unicode_buffer('\0'.join(key+'='+value for key,value in sorted(env.items()))+'\0\0');line=ctypes.create_unicode_buffer(subprocess.list2cmdline(item['command']))
            if not k.CreateProcessW(item['command'][0],line,None,None,True,0x08000404,block,str(S/'output'),ctypes.byref(si),ctypes.byref(pi)):raise OSError(ctypes.get_last_error(),'CreateProcessW suspended')
            child_created=True;handles.extend([pi.process,pi.thread])
            # Fresh private job registration precedes the birth query and any Resume.
            assigned=bool(k.AssignProcessToJobObject(job,pi.process))
            if not assigned:raise OSError(ctypes.get_last_error(),'AssignProcessToJobObject before Resume')
            born=times(pi.process);assert born[0]>0 and k.GetProcessId(pi.process)==pi.pid
            assert k.ResumeThread(pi.thread)==1;resumed=True
            close_parent_writes()
            start_drains()
            deadline=min(overall,time.monotonic()+item['timeoutSeconds']);stop_deadline=None
            while k.WaitForSingleObject(pi.process,50)!=0:
                if stop is None and (time.monotonic()>=deadline or too_large.is_set() or bytes_owned()-baseline>=p['byteBudget'] or shutil.disk_usage(S).free<p['minimumFreeBytes']):stop='deadline-byte-or-free-reserve'
                if stop is not None and stop_deadline is None:
                    assert times(pi.process)[0]==born[0] and k.GetProcessId(pi.process)==pi.pid
                    terminated=bool(k.TerminateJobObject(job,124)) if assigned else bool(k.TerminateProcess(pi.process,125));stop_deadline=time.monotonic()+15
                if stop_deadline is not None and time.monotonic()>=stop_deadline:break
            drain_deadline=min(overall+15,time.monotonic()+15)
            for th in threads:th.join(timeout=max(0,drain_deadline-time.monotonic()))
            if any(th.is_alive() for th in threads):
                stop=stop or 'both-EOF-timeout';assert times(pi.process)[0]==born[0];k.TerminateJobObject(job,126)
            after=times(pi.process);ec=t.DWORD();assert k.GetExitCodeProcess(pi.process,ctypes.byref(ec));wait=k.WaitForSingleObject(pi.process,0)
            receipt={'childCreated':True,'birthCaptured':True,'qualification':stop is None and wait==0 and ec.value==0 and after[1]>0 and born[0]==after[0] and assigned and resumed and not errors and all(channels.get(x,{}).get('eof') for x in ('stdout','stderr')),'id':item['id'],'command':item['command'],'pid':pi.pid,'birthFileTime':born[0],'heldProcessHandle':pi.process,'osExitFileTime':after[1],'birthValidatedOnHeldHandleAfterExit':born[0]==after[0],'handleHeldThroughOsExitAndBothEof':wait==0 and all(channels.get(x,{}).get('eof') for x in ('stdout','stderr')),'osExitCode':ec.value,'pythonExitCode':None,'waitForSingleObjectResult':wait,'jobAssigned':assigned,'jobAssignedBeforeResume':assigned and resumed,'createdSuspended':True,'stopReason':stop,'terminationRequested':terminated,'stdout':channels.get('stdout',{'eof':False}),'stderr':channels.get('stderr',{'eof':False}),'drainErrors':errors,'launchUtc':launch,'completedUtc':utc(),'bytesAdditional':bytes_owned()-baseline,'sourcePreflightSha256':sha(S/p['sourceManifest']),'outputs':[{'path':f,'size':pathlib.Path(f).stat().st_size,'sha256':sha(f)} for f in item.get('outputs',[]) if pathlib.Path(f).is_file()]}
            # Direct Win32 child has no Python Popen returncode; never invent one from OS exit.
            receipt['executionApi']='CreateProcessW/GetExitCodeProcess'
            write_new(S/'proof'/(item['id']+'.receipt.json'),receipt);receipts.append(receipt)
            assert stop is None and wait==0 and ec.value==0 and after[1]>0 and assigned and resumed and born[0]==after[0] and not errors and all(channels.get(x,{}).get('eof') for x in ('stdout','stderr')),'actual OS exit/birth/both EOF incomplete'
            assert all(pathlib.Path(f).is_file() for f in item.get('outputs',[])) and bytes_owned()-baseline<p['byteBudget']
            preflight();return receipt
        except Exception as failure:
            if receipt is None:
                cleanup_errors=[];waited=None;exit_code=None;after=None
                if child_created:
                    # Parent-authorized failure cleanup: only the fresh CreateProcess handle/private job.
                    # No PID reopen, shared job, Resume, birth invention or policy-retry fallback.
                    close_parent_writes();start_drains()
                    if assigned:terminated=bool(k.TerminateJobObject(job,127))
                    else:terminated=bool(k.TerminateProcess(pi.process,127))
                    if not terminated:cleanup_errors.append({'api':'own fresh termination','winError':ctypes.get_last_error()})
                    cleanup_deadline=time.monotonic()+15;waited=k.WaitForSingleObject(pi.process,15000)
                    ec=t.DWORD()
                    if k.GetExitCodeProcess(pi.process,ctypes.byref(ec)):exit_code=ec.value
                    else:cleanup_errors.append({'api':'GetExitCodeProcess','winError':ctypes.get_last_error()})
                    try:after=times(pi.process)
                    except Exception as e:cleanup_errors.append({'api':'GetProcessTimes after failure','error':repr(e)})
                    eof_deadline=cleanup_deadline
                    for th in threads:th.join(timeout=max(0,eof_deadline-time.monotonic()))
                    failure_receipt={'id':item['id'],'command':item['command'],'childCreated':True,'birthCaptured':born is not None,'qualification':False,'pid':pi.pid,'birthFileTime':born[0] if born else None,'heldProcessHandle':pi.process,'osExitFileTime':after[1] if after else None,'birthValidatedOnHeldHandleAfterExit':bool(born and after and born[0]==after[0]),'handleHeldThroughOsExitAndBothEof':waited==0 and all(channels.get(x,{}).get('eof') for x in ('stdout','stderr')),'osExitCode':exit_code,'pythonExitCode':None,'waitForSingleObjectResult':waited,'jobAssigned':assigned,'jobAssignedBeforeResume':assigned and resumed,'createdSuspended':True,'resumePerformed':resumed,'stopReason':'created-child-failure-before-qualification','exception':repr(failure),'actualWinError':getattr(failure,'errno',None),'terminationRequested':terminated,'cleanupErrors':cleanup_errors,'stdout':channels.get('stdout',{'eof':False}),'stderr':channels.get('stderr',{'eof':False}),'success':False,'executionApi':'CreateProcessW/GetExitCodeProcess'}
                else:failure_receipt={'id':item['id'],'command':item['command'],'childCreated':False,'birthCaptured':False,'qualification':False,'pid':None,'birthFileTime':None,'stopReason':'no-child-created','exception':repr(failure),'actualWinError':getattr(failure,'errno',None),'success':False}
                write_new(S/'proof'/(item['id']+'.receipt.json'),failure_receipt);receipts.append(failure_receipt)
            raise
        finally:
            if child_created and k.WaitForSingleObject(pi.process,0)!=0:
                # This is the exact fresh held handle, never reopened by PID; failure permission is explicit.
                if assigned:k.TerminateJobObject(job,127)
                else:k.TerminateProcess(pi.process,127)
            for h in reversed(handles):k.CloseHandle(h)
    def raw(value):
        assert isinstance(value,dict);i=value['variantIndex'];kind=value['kind'];assert {0:'none',1:'bool',2:'double',3:'int64',4:'timestamp',6:'string',8:'array'}[i]==kind
        if kind=='timestamp':
            n=int(value['epochSignedInt64Decimal']);assert -(1<<63)<=n<1<<63
            safe=-(1<<63)<=n*10<1<<63 and -(1<<63)<=n*10+122192928000000000<1<<63
            if not safe:assert value['serializerDidRun'] is False and value['serializedUtf8Hex'] is None
        if kind=='string':assert re.fullmatch(r'(?:[0-9a-f]{2})*',value['utf8Hex'])
        if kind=='array' and not value['nullPointer']:
            for e in value['items']:raw(e)
    def capture(receipt):
        def same_input(v,a):
            kind=a['kind'];kind='none' if kind=='no-args' else 'array' if kind=='null-array' else kind
            assert v['kind']==kind
            if kind=='string':assert v['utf8Hex']==a['utf8Hex']
            if kind=='timestamp':assert v['epochSignedInt64Decimal']==a['epochSignedInt64Decimal'] and v['serializerDidRun'] is False
            if kind=='bool':assert v['value']==a['value']
            if kind=='int64':assert v['valueDecimal']==a['value']
            if kind=='double':assert v['value']==a['value']
            if kind=='array':
                if a['kind']=='null-array':assert v['nullPointer'] is True and v['items'] is None
                else:
                    assert v['nullPointer'] is False and len(v['items'])==len(a['items'])
                    for x,y in zip(v['items'],a['items']):same_input(x,y)
        stream=pathlib.Path(receipt['stdout']['path']);assert stream.stat().st_size<=p['nativeCombinedStreamCap'];rows=[json.loads(line) for line in stream.read_text(encoding='utf-8').splitlines()];assert len(rows)==p['maxRawCaptureRecordsPerRun']
        for row,case in zip(rows,c['cases']):
            assert row['id']==case['id'] and row['function']==case['function'] and row['bodyDidRun']==case['bodyPlanned']
            assert row['sourceCommit']==p['sourceCommit'] and row['originalNodesSha256']=='a2fcca950bd5e5cfa48f3ff43e4436ae0f5fd55eff9661da1d5a979cc9051135'
            assert row['processId']==receipt['pid'] and int(row['processBirthFileTimeDecimal'])==receipt['birthFileTime'],'child own WinGetProcessTimes differs from held parent handle'
            assert (row['userLcid'],row['userLocaleUtf8Hex'],row['timezoneState'],row['timezoneBiasMinutes'],row['timezoneStandardBiasMinutes'],row['timezoneDaylightBiasMinutes'],row['pocoTimezoneTzdSeconds'])==(1041,'6a612d4a50',0,-540,0,-60,32400)
            assert row['timezoneStandardNameUtf8Hex']=='e69db1e4baac2028e6a899e6ba96e6998229' and row['contextLineIndex']==-1 and row['contextPointersNull'] is True
            raw(row['input']);same_input(row['input'],case['argument'])
            if not case['bodyPlanned']:assert row['status']=='not-run-static-guard' and row['result'] is None
            elif row['status']=='ok':
                raw(row['result']);assert row['result']['kind'] in ('none','timestamp','array')
                if case['argument']['kind'] in ('none','bool','int64','double','no-args'):assert row['result']['variantIndex']==0
            else:assert row['status']=='exception' and row['result'] is None and row['exceptionTypeNameHex'] and row['exceptionMessageHex'] is not None
        return rows
    try:
        for item in p['compileCommands']:run(item)
        newobj=pathlib.Path(p['compileCommands'][0]['outputs'][0]);objsha=sha(newobj);run(p['linkCommand']);assert sha(newobj)==objsha
        exe=pathlib.Path(p['linkCommand']['outputs'][0]);exesha=sha(exe);captures=[]
        for item in p['nativeRunCommands']:
            assert sha(exe)==exesha and sha(newobj)==objsha;receipt=run(item);captures.append(capture(receipt));assert sha(exe)==exesha
        normalized=[[{k:v for k,v in row.items() if k not in p['stableCompareExclusions']} for row in rows] for rows in captures];assert normalized[0]==normalized[1],'two-run semantic/profile mismatch'
        write_new(S/'execution-result.json',{'status':'complete-raw-three-startof-capture','receipts':receipts,'exeSha256':exesha,'compileCount':1,'linkCount':1,'nativeRunCount':2,'caseCount':p['maxRawCaptureRecordsPerRun'],'bodyCandidatesPerRun':p['maxOriginalBodyCallsPerRun'],'skippedPerRun':p['maxRawCaptureRecordsPerRun']-p['maxOriginalBodyCallsPerRun'],'sameSemanticAndProfile':True,'goldenGenerated':False,'parserAstOptimizeQualified':False})
    except Exception as e:
        write_new(S/'execution-result.json',{'status':'stopped-no-retry','error':str(e),'receipts':receipts,'goldenGenerated':False,'parserAstOptimizeQualified':False});raise
if __name__=='__main__':main()
