"""実採取raw・原典・最小goldenを保持。compiler/link/body/削除なし。"""
import pathlib,json,hashlib,shutil,zipfile,runpy
S=pathlib.Path(__file__).resolve().parent;C=S/'capture-closure-v4'
def load(p):return json.loads(pathlib.Path(p).read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def new(p,v):
    with p.open('x',encoding='utf-8') as f:f.write(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
p=load(S/'native-execution-plan.json');m=load(S/p['sourceManifest']);a=load(S/'execution-authority.json');K=pathlib.Path(p['ownedKeepRoot'])
assert K.resolve()==K and all(x.lower()!='artifacts' for x in C.parts) and not C.exists()
C.mkdir()
names=set(a['pins'])|{'execution-authority.json',p['requiredGoFileName'],'execution-result.json','execution-started.json','native-golden-candidate.v4.json','native-capture-statistics.v4.json','native-capture-qualified.v4.json','read_actual_capture.v4.py','read_capture_portable.v4.py','retain_actual_capture.v4.py'}
for name in sorted(names):
    f=C/name;f.parent.mkdir(exist_ok=True);shutil.copyfile(S/name,f)
shutil.copyfile(m['referenceSourceZip'],C/'reference-source.zip')
(C/'proof').mkdir()
for r in load(S/'execution-result.json')['receipts']:
    for name in (r['id']+'.receipt.json',r['id']+'.stdout.raw',r['id']+'.stderr.raw'):shutil.copyfile(S/'proof'/name,C/'proof'/name)
(C/'outer').mkdir()
for suffix in ('launch.json','result.json','stdout.raw','stderr.raw'):shutil.copyfile(K/('parent-execute-v4-'+suffix) if suffix.endswith('.json') else K/('parent-execute-v4.'+suffix),C/'outer'/('parent-execute-v4-'+suffix) if suffix.endswith('.json') else C/'outer'/('parent-execute-v4.'+suffix))
files=sorted(f for f in C.rglob('*') if f.is_file())
new(C/'closure-manifest.json',{'files':[{'path':str(f.relative_to(C)).replace('\\','/'),'size':f.stat().st_size,'sha256':sha(f)} for f in files],'retentionReason':'fixed original source/actualraw/typed108golden/restart-independent read evidence; no binaryobject/exe/tool copies','retireWhen':'parent replaces/retires via common recycle helper; no deletion performed','NativeReexecution':False,'v3FailureGoKeptOutsideClosure':True})
runpy.run_path(str(C/'read_capture_portable.v4.py'),run_name='__main__')
archive=K/'startof-actual-capture-closure.v4.zip';files=sorted(f for f in C.rglob('*') if f.is_file())
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for f in files:z.write(f,str(f.relative_to(C)).replace('\\','/'))
with zipfile.ZipFile(archive) as z:
    assert len(z.infolist())==len(files)
    for f in files:
        b=z.read(str(f.relative_to(C)).replace('\\','/'));assert len(b)==f.stat().st_size and hashlib.sha256(b).hexdigest()==sha(f)
new(K/'actual-capture-delivery.v4.json',{'archive':str(archive),'archiveSha256':sha(archive),'archiveBytes':archive.stat().st_size,'entries':len(files),'fullEntryShaSizeVerified':True,'goldenCandidate':str(S/'native-golden-candidate.v4.json'),'goldenSha256':sha(S/'native-golden-candidate.v4.json'),'statistics':str(S/'native-capture-statistics.v4.json'),'qualification':str(S/'native-capture-qualified.v4.json'),'qualificationSha256':sha(S/'native-capture-qualified.v4.json'),'portableReader':str(C/'read_capture_portable.v4.py'),'NativeAdditionalRuns':0,'productNotAdopted':True,'naturalTokyoOnly':True,'retireWhen':'parent supersedes/retire via common recycle helper'})
print(json.dumps({'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'entries':len(files),'golden108Sha256':sha(S/'native-golden-candidate.v4.json'),'additionalNative':0}))
