"""Read-only AST parentage/control-scope proof; not a unit test or runtime executor."""
import ast,pathlib,json
def prove(path):
    path=pathlib.Path(path);text=path.read_text(encoding='utf-8');tree=ast.parse(text,str(path))
    parents={child:node for node in ast.walk(tree) for child in ast.iter_child_nodes(node)}
    main=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
    run=next(n for n in main.body if isinstance(n,ast.FunctionDef) and n.name=='run')
    drain=next(n for n in ast.walk(main) if isinstance(n,ast.FunctionDef) and n.name=='drain')
    assert parents[drain] is run,'drain must be direct child of main/run'
    helper_names={n.name for n in run.body if isinstance(n,ast.FunctionDef)}
    assert {'drain','close_parent_writes','start_drains'}<=helper_names
    phase_try=next(n for n in run.body if isinstance(n,ast.Try))
    assert parents[phase_try] is run and phase_try.finalbody,'process maintry/finally must be direct run statements'
    def own_scope(node):
        yield node
        for child in ast.iter_child_nodes(node):
            if isinstance(child,(ast.FunctionDef,ast.AsyncFunctionDef,ast.Lambda)):continue
            yield from own_scope(child)
    scope_nodes=[n for statement in run.body if not isinstance(statement,ast.FunctionDef) for n in own_scope(statement)]
    calls=[n for n in scope_nodes if isinstance(n,ast.Call)]
    attrs={n.func.attr for n in calls if isinstance(n.func,ast.Attribute)}
    required={'CreateProcessW','AssignProcessToJobObject','ResumeThread','GetExitCodeProcess','WaitForSingleObject','TerminateJobObject','TerminateProcess','CloseHandle'}
    assert required<=attrs,('run own scope missing',required-attrs)
    ordered={name:min(n.lineno for n in calls if isinstance(n.func,ast.Attribute) and n.func.attr==name) for name in ('CreateProcessW','AssignProcessToJobObject','ResumeThread')}
    birth_lines=[n.lineno for n in calls if isinstance(n.func,ast.Name) and n.func.id=='times']
    assert ordered['CreateProcessW']<ordered['AssignProcessToJobObject']<min(birth_lines)<ordered['ResumeThread']
    dict_keys={n.value for node in scope_nodes if isinstance(node,ast.Dict) for n in node.keys if isinstance(n,ast.Constant) and isinstance(n.value,str)}
    assert {'handleHeldThroughOsExitAndBothEof','childCreated','birthCaptured','qualification','osExitCode','stdout','stderr','birthFileTime'}<=dict_keys
    assert any(isinstance(n,ast.Return) and isinstance(n.value,ast.Name) and n.value.id=='receipt' for n in scope_nodes),'run must return a process receipt'
    assert not any(isinstance(n,ast.Return) for n in phase_try.finalbody),'finally must not suppress failure'
    final_calls=[n.func.attr for node in phase_try.finalbody for n in own_scope(node) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute)]
    assert {'WaitForSingleObject','TerminateJobObject','TerminateProcess','CloseHandle'}<=set(final_calls)
    drain_calls={n.func.attr for n in ast.walk(drain) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute)}
    assert 'ReadFile' in drain_calls
    def indent(line):return len(line)-len(line.lstrip(' '))
    lines=text.splitlines();assert indent(lines[run.lineno-1])==4 and indent(lines[drain.lineno-1])==8 and indent(lines[phase_try.lineno-1])==8
    return {'status':'AST-parentage-and-own-run-scope-pass','run':{'line':run.lineno,'endLine':run.end_lineno,'parent':'main'},'drain':{'line':drain.lineno,'endLine':drain.end_lineno,'parent':'main/run'},'maintry':{'line':phase_try.lineno,'endLine':phase_try.end_lineno,'parent':'main/run','finallyStatements':len(phase_try.finalbody)},'runOwnScopeAPIs':sorted(attrs),'freshCreateJobBirthResumeLines':{**ordered,'birth':min(birth_lines)},'realSourceIndent':{'run':4,'drain':8,'maintry':8},'NativeExecuted':False,'dynamicFailureInjectionMeasured':False}
if __name__=='__main__':print(json.dumps(prove(pathlib.Path(__file__).with_name('native_executor.py'))))
