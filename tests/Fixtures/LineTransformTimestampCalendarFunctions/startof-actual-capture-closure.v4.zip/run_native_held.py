"""No implicit execution. Exact GO is validated by the dedicated supervisor."""
import pathlib,sys,runpy,json,hashlib
S=pathlib.Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def main():
    assert sys.argv[1:] in ([],['--execute-parent-go'])
    a=json.loads((S/'execution-authority.json').read_text(encoding='utf-8'));assert sha(S/'native_executor.py')==a['pins']['native_executor.py'];assert sha(__file__)==a['pins']['run_native_held.py']
    py=a['python'];assert sha(py['path'])==py['sha256'];assert pathlib.Path(sys.executable).resolve()==pathlib.Path(py['path'])
    # Same Python process: no unowned second supervisor PID or subprocess timeout kill.
    sys.argv=[str(S/'native_executor.py')]+sys.argv[1:]
    runpy.run_path(str(S/'native_executor.py'),run_name='__main__')
if __name__=='__main__':main()
