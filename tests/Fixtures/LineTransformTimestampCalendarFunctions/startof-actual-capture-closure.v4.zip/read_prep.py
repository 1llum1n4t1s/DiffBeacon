"""原典・PREPの読み取り検証。Native/compiler/link/bodyを起動しない。"""
import pathlib,json,hashlib,ast,zipfile,struct,difflib,importlib.util,collections
S=pathlib.Path(__file__).resolve().parent
def load(p):return json.loads(pathlib.Path(p).read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def module(n):
    spec=importlib.util.spec_from_file_location(n,S/(n+'.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def inspect():
    authority,p,m,c,env=module('native_executor').preflight()
    assert c['caseCount']==p['maxRawCaptureRecordsPerRun']==126
    assert c['safeBodyCandidates']==p['maxOriginalBodyCallsPerRun']==108 and c['excludedBodies']==18
    assert len({x['id'] for x in c['cases']})==126
    assert collections.Counter(x['function'] for x in c['cases'])==dict.fromkeys(('startofweek','startofmonth','startofyear'),42)
    assert collections.Counter(x['function'] for x in c['cases'] if x['bodyPlanned'])==dict.fromkeys(('startofweek','startofmonth','startofyear'),36)
    exclusion_suffixes={'array-null','no-args','dynamic-nul','raw-int64-min','raw-int64-max','locale-unsafe1900'}
    def argument(a,called):
        k=a['kind']
        if k=='string':
            b=bytes.fromhex(a['utf8Hex']);assert not called or b'\0' not in b
        if k=='timestamp':
            n=int(a['epochSignedInt64Decimal']);assert -(1<<63)<=n<(1<<63)
            if called:assert -1000000<=n<=946684800000000
        if k in ('null-array','no-args'):assert not called
        if k=='array':
            for v in a['items']:argument(v,called)
    for x in c['cases']:
        assert x['functionIndex']==('startofweek','startofmonth','startofyear').index(x['function'])
        assert x['expected'] is None and x['newGolden'] is False
        argument(x['argument'],x['bodyPlanned'])
        suffix=x['id'].removeprefix(x['function']+'-')
        assert x['bodyPlanned']==(suffix not in exclusion_suffixes)
    cpp=(S/'timestamp_startof.cpp').read_text(encoding='utf-8')
    assert 'if(c.bodyPlanned){try{auto value=c.functionIndex==0?StartOfWeekFunc' in cpp
    assert 'raw=RawValue(value,true)' in cpp and 'RawValue(input,false)' in cpp
    assert 'ToDateTimeFunc(' not in cpp and 'ToDateStrFunc(' not in cpp
    assert 'RawValue' in cpp and 'UtcArithmeticSafe' in cpp
    rows=(S/'cases.inc').read_text(encoding='utf-8').splitlines();assert len(rows)==126
    for x,row in zip(c['cases'],rows):
        prefix='    {"'+x['id']+'", '+str(x['functionIndex'])+', '+str(x['bodyPlanned']).lower()+', '+str(x['argument']['kind']=='no-args').lower()+', '
        assert row.startswith(prefix)
    original=pathlib.Path(authority['measuredSupervisorReference']['path']);old=original.read_text(encoding='utf-8');new=(S/'native_executor.py').read_text(encoding='utf-8')
    assert sha(original)==authority['measuredSupervisorReference']['sha256']
    region=lambda text:text[text.index('    import ctypes'):text.index('    def raw')]
    assert region(old)==region(new),'API/receipt region must equal measured v9'
    assert 'ctypes.get_last_error()==109:eof=True;break' in new
    assert '==189' not in new and '==188' not in new
    shape=module('prove_structure').prove(S/'native_executor.py')
    assert shape==load(S/'ast-parentage-proof.json')
    tree=ast.parse(new);counter=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='bytes_owned')
    attrs=[n.func.attr for n in ast.walk(counter) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute)]
    assert attrs.count('stat')==1 and 'is_file' not in attrs
    assert [h.type.id for n in ast.walk(counter) if isinstance(n,ast.Try) for h in n.handlers]==['FileNotFoundError']
    assert load(S/'go.schema.json')['properties']['scope']['const']==p['scope']
    assert p['minimumFreeBytes']==10737418240 and p['byteBudget']==67108864
    assert len(m['toolPins'])==21 and len(m['libraries'])==7
    objs=[x for x in m['objects'] if x['includedInNewLink']];assert len(objs)==35
    item=next(x for x in objs if pathlib.Path(x['path']).name=='Timespan.obj');data=pathlib.Path(item['path']).read_bytes()
    ptr,count=struct.unpack_from('<II',data,8);base=ptr+count*18;i=0;symbols=[]
    while i<count:
        r=data[ptr+i*18:ptr+(i+1)*18];z,off=struct.unpack_from('<II',r)
        name=data[base+off:].split(b'\0')[0].decode('ascii') if z==0 else r[:8].split(b'\0')[0].decode('ascii')
        if struct.unpack_from('<h',r,12)[0]>0:symbols.append(name)
        i+=1+r[17]
    assert '??0Timespan@Poco@@QEAA@HHHHH@Z' in symbols
    with zipfile.ZipFile(m['referenceSourceZip']) as z:
        lines=z.read('source/Src/FilterEngine/FilterExpressionNodes.cpp').splitlines(keepends=True)
        for x in m['newOriginalSpans']:
            exact=b''.join(lines[x['startLine']-1:x['endLine']]);assert (S/'original-pieces'/(x['name']+'.inc')).read_bytes()==exact
        assert b'inline Timespan::TimeDiff Timespan::totalMicroseconds() const' in z.read('source/Externals/poco/Foundation/include/Poco/Timespan.h')
    assert not any((S/x).exists() for x in ('output','proof','execution-started.json','execution-result.json',p['requiredGoFileName']))
    return {'status':'local-readonly-prep-pass','cases':126,'bodyCandidates':108,'excluded':18,'allAuthorityPins':len(authority['pins']),'apiReceiptRegionEqualMeasuredV9':True,'brokenPipeWinError':109,'singleStatCounter':True,'sourceThreeSpansByteExact':True,'TimespanCtorSymbolDefined':True,'TimespanObjectSha256':sha(item['path']),'originalObjectsBytes':sum(x['size'] for x in objs),'sourceFiles':len(m['files']),'tools':21,'libraries':7,'NativeCompileLinkBodyCount':0,'dynamicFailureInjectionMeasured':False,'startofNativeResultsMeasured':False}
if __name__=='__main__':print(json.dumps(inspect(),ensure_ascii=False))
