"""既知MSIX Keep aliasを同FileID確認後、canonical pathだけ新v4へbindするPREP。"""
import pathlib,json,hashlib,shutil,ctypes,ctypes.wintypes as t,importlib.util,zipfile
T=pathlib.Path(__file__).resolve().parent;old=T/'candidate-v3';S=T/'candidate-v4'
literal=pathlib.Path(r'C:\Users\IMT\AppData\Local\Codex\TaskArtifacts\DiffBeacon\timestamp-startof-prep-20261012-230204-cf1a8210')
canonical=pathlib.Path(r'C:\Users\IMT\AppData\Local\Packages\OpenAI.Codex_2p2nqsd0c76g0\LocalCache\Local\Codex\TaskArtifacts\DiffBeacon\timestamp-startof-prep-20261012-230204-cf1a8210')
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(pathlib.Path(p).read_text(encoding='utf-8-sig'))
def new(n,v):
    with (S/n).open('x',encoding='utf-8') as f:f.write(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
k=ctypes.WinDLL('kernel32',use_last_error=True)
class INFO(ctypes.Structure):_fields_=[('attributes',t.DWORD),('created',t.FILETIME),('accessed',t.FILETIME),('written',t.FILETIME),('volume',t.DWORD),('sizeHigh',t.DWORD),('sizeLow',t.DWORD),('links',t.DWORD),('idHigh',t.DWORD),('idLow',t.DWORD)]
k.CreateFileW.argtypes=[t.LPCWSTR,t.DWORD,t.DWORD,ctypes.c_void_p,t.DWORD,t.DWORD,t.HANDLE];k.CreateFileW.restype=t.HANDLE
k.GetFileInformationByHandle.argtypes=[t.HANDLE,ctypes.POINTER(INFO)];k.GetFileInformationByHandle.restype=t.BOOL
k.GetFinalPathNameByHandleW.argtypes=[t.HANDLE,t.LPWSTR,t.DWORD,t.DWORD];k.GetFinalPathNameByHandleW.restype=t.DWORD
k.CloseHandle.argtypes=[t.HANDLE];k.CloseHandle.restype=t.BOOL
def identity(path):
    h=k.CreateFileW(str(path),0,7,None,3,0x02000000,None)
    if h==ctypes.c_void_p(-1).value:raise OSError(ctypes.get_last_error(),'CreateFileW readonly directory')
    try:
        info=INFO();assert k.GetFileInformationByHandle(h,ctypes.byref(info)),ctypes.get_last_error()
        buf=ctypes.create_unicode_buffer(32768);n=k.GetFinalPathNameByHandleW(h,buf,len(buf),0);assert 0<n<len(buf),ctypes.get_last_error()
        return {'input':str(path),'resolved':str(path.resolve(strict=True)),'volumeSerial':info.volume,'fileId':(info.idHigh<<32)|info.idLow,'heldFinalPath':buf.value,'attributes':info.attributes}
    finally:assert k.CloseHandle(h)
ids=[identity(literal),identity(canonical)]
assert (ids[0]['volumeSerial'],ids[0]['fileId'])==(ids[1]['volumeSerial'],ids[1]['fileId'])
assert literal.resolve(strict=True)==canonical and canonical.resolve(strict=True)==canonical
ancestors=[]
for root in (literal,canonical,T,S):
    assert all(x.lower()!='artifacts' for x in root.parts)
    resolved=root.resolve();assert not resolved.is_relative_to(pathlib.Path(r'C:\Users\IMT\dev\DiffBeacon')) and not resolved.is_relative_to(pathlib.Path(r'C:\Users\IMT\.codex'))
    for ancestor in (root,*root.parents):
        if ancestor.exists():
            attributes=ancestor.stat(follow_symlinks=False).st_file_attributes
            assert not attributes&0x400,('unapproved ancestor reparse',str(ancestor),attributes)
            ancestors.append({'path':str(ancestor),'attributes':attributes,'reparse':False})
assert shutil.disk_usage(T).free>=268435456 and not S.exists()
for filename in ('execution-started.json','output','proof','execution-result.json'):assert not (old/filename).exists()
S.mkdir()
excluded={'execution-authority.json','parent-exact-execution-go.json','review-delivery.json','local-reader-result.json','portable-reader-result.json','prepare_startof_v3.py','finalize_startof_v3.py'}
for f in old.rglob('*'):
    if f.is_file() and f.name not in excluded and not f.name.endswith('.before-symbol-name'):
        target=S/f.relative_to(old);target.parent.mkdir(exist_ok=True);shutil.copyfile(f,target)
def rebind(value):
    if isinstance(value,str):return value.replace(str(old),str(S))
    if isinstance(value,list):return [rebind(x) for x in value]
    if isinstance(value,dict):return {a:rebind(b) for a,b in value.items()}
    return value
# 保持済みv3を復元元とし、新v4だけを書き換える。Nativeコード/監視APIは不変。
for name in ('native-execution-plan.json','source-preflight-manifest.json','environment.sdk-only.json','preparation-result.json','launch-contract.json'):
    value=rebind(load(S/name))
    if name=='native-execution-plan.json':value['ownedKeepRoot']=str(canonical);value['retentionStageCanonical']=str(canonical)
    with (S/name).open('w',encoding='utf-8') as f:f.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
for name in ('native_executor.py','run_native_held.py','read_prep.py','read_portable.py','prove_structure.py','timestamp_startof.cpp','cases.inc'):
    assert (old/name).read_bytes()==(S/name).read_bytes(),name
new('keep-alias-proof.v4.json',{'scope':'this exact known MSIX LocalCache Keep alias only','identities':ids,'sameVolumeAndFileId':True,'literalResolvesToCanonical':True,'ancestorAttributes':ancestors,'allAncestorsNoReparse':True,'resolvedPathsOutsideRepoAndCodexHome':True,'genericAliasPermission':False,'nativeGuardChanged':False,'v3OriginalAuthoritySha256':sha(old/'execution-authority.json'),'v3GoRetainedSha256':sha(old/'parent-exact-execution-go.json'),'parentFailedExitEvidence':{'path':str(canonical/'parent-execute-v3-result.json'),'sha256':sha(canonical/'parent-execute-v3-result.json')},'nativeCompileLinkBody0':True,'v3NoStartedOutputProof':True})
shutil.copyfile(__file__,S/pathlib.Path(__file__).name)
p=load(S/'native-execution-plan.json');m=load(S/'source-preflight-manifest.json');a=load(old/'execution-authority.json')
pins={str(f.relative_to(S)).replace('\\','/'):sha(f) for f in sorted(S.rglob('*')) if f.is_file()}
new('execution-authority.json',{'schemaVersion':4,'status':'STARTOF_V4_CANONICAL_KEEP_PREP_FROZEN_NEW_PARENT_EXACTGO_REQUIRED','scope':p['scope'],'pins':pins,'python':m['toolPins']['python'],'measuredSupervisorReference':a['measuredSupervisorReference'],'NativeCompileLinkBodyCount':0,'noAutoRetry':True,'newNativeGORequired':True,'existingV3AndGoPreserved':True})
def inspect(name,*args):
    spec=importlib.util.spec_from_file_location(name,S/(name+'.py'));mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod.inspect(*args)
new('local-reader-result.json',inspect('read_prep'))
new('portable-reader-result.json',inspect('read_portable',m['referenceSourceZip']))
authority=sha(S/'execution-authority.json');exact={'approved':True,'authoritySha256':authority,'planSha256':sha(S/'native-execution-plan.json'),'supervisorSha256':sha(S/'native_executor.py'),'wrapperSha256':sha(S/'run_native_held.py'),'casePlanSha256':sha(S/'failure-case-plan.json'),'sourceManifestSha256':sha(S/'source-preflight-manifest.json'),'scope':p['scope'],'maxCommands':p['maxCommands']}
new('review-delivery.json',{'status':'PREP_ONLY_NATIVE0_NEW_GO_NOT_CREATED','authoritySha256':authority,'stage':str(S),'canonicalKeepRoot':str(canonical),'aliasProof':str(S/'keep-alias-proof.v4.json'),'exactGoShapeForParentReviewOnly':exact,'exactGoPath':str(S/p['requiredGoFileName']),'existingV3AndGoPreserved':True,'retireCondition':'parent supersedes/retire via common recycle helper; no deletion performed'})
archive=canonical/'startof-three-body-prep.v4.zip';files=sorted(f for f in S.rglob('*') if f.is_file())
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for f in files:z.write(f,str(f.relative_to(S)).replace('\\','/'))
with zipfile.ZipFile(archive) as z:
    assert len(z.infolist())==len(files)
    for f in files:
        b=z.read(str(f.relative_to(S)).replace('\\','/'));assert len(b)==f.stat().st_size and hashlib.sha256(b).hexdigest()==sha(f)
delivery={'archive':str(archive),'archiveSha256':sha(archive),'archiveBytes':archive.stat().st_size,'entries':len(files),'allEntriesSizeShaVerified':True,'authoritySha256':authority,'reviewDelivery':str(S/'review-delivery.json'),'v3AndGoRetained':True,'Native0':True,'retention':'minimal canonicalKeep PREP/restart evidence until parent retires; no deletion performed'}
with (canonical/'delivery.v4.json').open('x',encoding='utf-8') as f:f.write(json.dumps(delivery,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(delivery))
