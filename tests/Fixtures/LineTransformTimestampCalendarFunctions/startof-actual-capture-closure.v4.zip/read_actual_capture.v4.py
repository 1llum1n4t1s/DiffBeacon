"""完了済み3body採取を読取り照合。新golden候補を作るがNativeを起動しない。"""
import pathlib,json,hashlib,collections,zipfile,datetime
S=pathlib.Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(pathlib.Path(p).read_text(encoding='utf-8-sig'))
def new(n,v):
    with (S/n).open('x',encoding='utf-8') as f:f.write(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def typed(v):
    if v is None:return None
    kind=v['kind'];out={'variantIndex':v['variantIndex'],'kind':kind}
    if kind=='timestamp':out['epochSignedInt64Decimal']=v['epochSignedInt64Decimal']
    elif kind=='string':out['utf8Hex']=v['utf8Hex']
    elif kind in ('bool','double'):out['value']=v['value']
    elif kind=='int64':out['valueDecimal']=v['valueDecimal']
    elif kind=='array':out.update({'nullPointer':v['nullPointer'],'items':None if v['nullPointer'] else [typed(x) for x in v['items']]})
    return out
a=load(S/'execution-authority.json');p=load(S/'native-execution-plan.json');m=load(S/p['sourceManifest']);cases=load(S/p['casePlan'])['cases'];K=pathlib.Path(p['ownedKeepRoot'])
assert sha(S/'execution-authority.json')=='f2ab35bba5ff0b6f580c1d0ea3c1f3c186628a538baf2d6b85317851a7283195'
for n,h in a['pins'].items():assert sha(S/n)==h,('authority drift',n)
go=load(S/p['requiredGoFileName']);expected={'approved':True,'authoritySha256':sha(S/'execution-authority.json'),'planSha256':sha(S/'native-execution-plan.json'),'supervisorSha256':sha(S/'native_executor.py'),'wrapperSha256':sha(S/'run_native_held.py'),'casePlanSha256':sha(S/p['casePlan']),'sourceManifestSha256':sha(S/p['sourceManifest']),'scope':p['scope'],'maxCommands':p['maxCommands']};assert go==expected
for x in m['files']+m['objects']+m['libraries']:assert pathlib.Path(x['path']).stat().st_size==x['size'] and sha(x['path'])==x['sha256'],x['path']
for x in m['toolPins'].values():assert sha(x['path'])==x['sha256']
with zipfile.ZipFile(m['referenceSourceZip']) as z:
    assert sha(m['referenceSourceZip'])==m['referenceSourceZipSha256'];nodes=z.read('source/Src/FilterEngine/FilterExpressionNodes.cpp');assert hashlib.sha256(nodes).hexdigest()=='a2fcca950bd5e5cfa48f3ff43e4436ae0f5fd55eff9661da1d5a979cc9051135'
    spans={'toLocalDateTime':(1684,1691),'applyToScalarOrArray':(1693,1704),'StartOfWeekFunc':(2103,2117),'StartOfMonthFunc':(2119,2130),'StartOfYearFunc':(2132,2143)}
    for name,(lo,hi) in spans.items():assert (S/'original-pieces'/(name+'.inc')).read_bytes()==b''.join(nodes.splitlines(keepends=True)[lo-1:hi])
outer=load(K/'parent-execute-v4-result.json');launch=load(K/'parent-execute-v4-launch.json')
assert outer['pid']==launch['pid']==32276 and outer['birthUtc']==launch['birthUtc'] and outer['exitCode']==0
assert all(outer[k] for k in ('terminal','heldUntilExit','stdoutComplete','stderrComplete')) and not outer['timedOut']
assert launch['scriptSha256'].lower()==sha(S/'run_native_held.py') and launch['heldHandle']
result=load(S/'execution-result.json');assert result['status']=='complete-raw-three-startof-capture'
assert (result['compileCount'],result['linkCount'],result['nativeRunCount'],result['caseCount'],result['bodyCandidatesPerRun'],result['skippedPerRun'])==(1,1,2,126,108,18)
commands=p['compileCommands']+[p['linkCommand']]+p['nativeRunCommands'];assert len(result['receipts'])==len(commands)==4
captures=[];process=[]
for r,cmd in zip(result['receipts'],commands):
    assert r==load(S/'proof'/(r['id']+'.receipt.json')) and r['id']==cmd['id'] and r['command']==cmd['command']
    for k in ('childCreated','birthCaptured','qualification','birthValidatedOnHeldHandleAfterExit','handleHeldThroughOsExitAndBothEof','jobAssigned','jobAssignedBeforeResume','createdSuspended'):assert r[k] is True,(r['id'],k)
    assert r['osExitCode']==0 and r['waitForSingleObjectResult']==0 and r['osExitFileTime']>=r['birthFileTime']>0
    assert r['stopReason'] is None and not r['drainErrors'] and not r['terminationRequested'] and r['pythonExitCode'] is None
    assert r['sourcePreflightSha256']==sha(S/p['sourceManifest']) and r['bytesAdditional']<p['byteBudget']
    for key in ('stdout','stderr'):
        x=r[key];assert x['eof'] and pathlib.Path(x['path']).stat().st_size==x['size'] and sha(x['path'])==x['sha256']
    for x in r.get('outputs',[]):assert pathlib.Path(x['path']).stat().st_size==x['size'] and sha(x['path'])==x['sha256']
    process.append({'id':r['id'],'pid':r['pid'],'birthFileTime':r['birthFileTime'],'osExitFileTime':r['osExitFileTime'],'actualOSExit':0,'heldBothEOF':True,'birthMatches':True,'jobBeforeResume':True,'bytesAdditional':r['bytesAdditional']})
    if cmd['kind']=='native':
        rows=[json.loads(line) for line in pathlib.Path(r['stdout']['path']).read_text(encoding='utf-8').splitlines()];assert len(rows)==126
        for row,case in zip(rows,cases):
            assert (row['id'],row['function'],row['bodyDidRun'])==(case['id'],case['function'],case['bodyPlanned'])
            assert row['processId']==r['pid'] and int(row['processBirthFileTimeDecimal'])==r['birthFileTime']
            assert (row['userLcid'],row['userLocaleUtf8Hex'],row['timezoneState'],row['timezoneBiasMinutes'],row['timezoneStandardBiasMinutes'],row['timezoneDaylightBiasMinutes'],row['pocoTimezoneTzdSeconds'])==(1041,'6a612d4a50',0,-540,0,-60,32400)
            assert row['timezoneStandardNameUtf8Hex']=='e69db1e4baac2028e6a899e6ba96e6998229' and row['contextLineIndex']==-1 and row['contextPointersNull']
            if not row['bodyDidRun']:assert row['status']=='not-run-static-guard' and row['result'] is None
            elif row['status']=='exception':assert row['result'] is None and row['exceptionTypeNameHex'] and row['exceptionMessageHex'] is not None
            else:assert row['status']=='ok' and row['result']['kind'] in ('none','timestamp','array')
        assert sum(x['bodyDidRun'] for x in rows)==108;captures.append(rows)
exclude=set(p['stableCompareExclusions']);assert exclude=={'processId','processBirthFileTimeDecimal','clockBeforeEpochMicrosecondsInt64Decimal','clockAfterEpochMicrosecondsInt64Decimal'}
stable=lambda rows:[{k:v for k,v in x.items() if k not in exclude} for x in rows];assert len(captures)==2 and stable(captures[0])==stable(captures[1])
rows=captures[0];byid={r['id']:r for r in rows};serial=[]
def inspect(v,id):
    if v is None:return
    assert {0:'none',1:'bool',2:'double',3:'int64',4:'timestamp',6:'string',8:'array'}[v['variantIndex']]==v['kind']
    if v['kind']=='timestamp':
        n=int(v['epochSignedInt64Decimal']);assert -(1<<63)<=n<(1<<63)
        safe=-(1<<63)<=n*10<(1<<63) and -(1<<63)<=n*10+122192928000000000<(1<<63)
        assert v['serializerDidRun']==safe
        if not safe:assert v['serializedUtf8Hex'] is None
        serial.append({'id':id,'epochSignedInt64Decimal':str(n),'didRun':v['serializerDidRun'],'status':v['serializationStatus'],'serializedUtf8Hex':v['serializedUtf8Hex'],'isFormatSuccessQualified':False})
    if v['kind']=='array' and not v['nullPointer']:
        for i,e in enumerate(v['items']):inspect(e,id+'['+str(i)+']')
for r in rows:
    inspect(r['result'],r['id'])
    if not r['bodyDidRun']:continue
    suffix=r['id'].removeprefix(r['function']+'-')
    if suffix in ('none','bool','int','float'):assert r['status']=='ok' and r['result']['variantIndex']==0
    if suffix=='array-empty':assert r['result']['items']==[]
    if suffix=='array-nested':assert [x['kind'] for x in r['result']['items']]==['none']
    if suffix=='array-mixed':assert [x['kind'] for x in r['result']['items']]==['timestamp','none','none','none','timestamp','none']
    if suffix=='array-invalid-middle':assert r['status']=='exception' and r['result'] is None
for fn in ('startofmonth','startofyear'):
    for suffix in ('epoch-zero','raw-minus-us','raw-zero','raw-plus-us','raw-plus-second'):
        r=byid[fn+'-'+suffix];assert r['status']=='ok' and r['result']['epochSignedInt64Decimal']=='-32400000000' and bytes.fromhex(r['result']['serializedUtf8Hex'])==b'System exception'
    assert byid[fn+'-raw-minus-second']['status']=='exception'
    assert byid[fn+'-3000-end']['result']['epochSignedInt64Decimal']=='32535183600000000' and byid[fn+'-3001-start']['result']==byid[fn+'-3000-end']['result']
for suffix in ('sunday','monday','saturday'):assert byid['startofweek-'+suffix]['result']['epochSignedInt64Decimal']=='946738800000000'
for suffix in ('epoch-zero','raw-minus-us','raw-zero','raw-plus-us','raw-plus-second'):assert byid['startofweek-'+suffix]['status']=='exception'
counts={fn:{'rows':42,'bodyCalls':36,'excluded':6,'status':dict(collections.Counter(r['status'] for r in rows if r['function']==fn)),'resultKinds':dict(collections.Counter(r['result']['kind'] for r in rows if r['function']==fn and r['result']))} for fn in ('startofweek','startofmonth','startofyear')}
exceptions=[{'id':r['id'],'typeNameHex':r['exceptionTypeNameHex'],'nameHex':r['exceptionNameHex'],'messageHex':r['exceptionMessageHex'],'typeDisplay':bytes.fromhex(r['exceptionTypeNameHex']).decode('utf-8','replace'),'messageDisplay':bytes.fromhex(r['exceptionMessageHex']).decode('utf-8','replace')} for r in rows if r['status']=='exception']
entries=[];refs=[r['stdout']['sha256'] for r in result['receipts'] if r['id'].startswith('native-run-')]
for line,(row,case) in enumerate(zip(rows,cases),1):
    if not row['bodyDidRun']:continue
    entries.append({'id':row['id'],'function':row['function'],'inputDescriptor':case['argument'],'status':row['status'],'typedResult':typed(row['result']),'bodyException':{'typeNameHex':row['exceptionTypeNameHex'],'nameHex':row['exceptionNameHex'],'messageHex':row['exceptionMessageHex']} if row['status']=='exception' else None,'rawReferences':[{'run':i+1,'sha256':refs[i],'line':line} for i in range(2)],'TimestampDisplayGoldenGenerated':False})
assert len(entries)==108
new('native-golden-candidate.v4.json',{'schemaVersion':1,'status':'MINIMAL_ORIGINAL_3BODY_RESULT_CANDIDATE_NOT_PRODUCT_ADOPTED','sourceCommit':m['sourceCommit'],'nodesSha256':hashlib.sha256(nodes).hexdigest(),'sameProfileOnly':True,'profile':{'LCID':1041,'locale':'ja-JP','timezone':'Tokyo','Tzd':32400},'scope':p['scope'],'candidateCount':108,'entries':entries,'excludedNoGolden':[r['id'] for r in rows if not r['bodyDidRun']],'serializerDisplayObservationsSeparated':True,'clockFullASTParserOptimizeQualified':False,'dynamicNulNativeMeasured':False})
new('native-capture-statistics.v4.json',{'rowsPerRun':126,'bodyCallsPerRun':108,'excludedPerRun':18,'functions':counts,'exceptions':exceptions,'exceptionTypes':dict(collections.Counter(x['typeDisplay'] for x in exceptions)),'TimestampSerializerObservations':serial,'sourceConsequences':['Sunday based UTC fixed-day subtraction; firstweek negative reconstruction raises OS error','epochTime C++ signed division truncates -1us to0 seconds; -1second staysnegative and fails initial CRT','month/year 1970 localmidnight returnsnegative timestamp; caught serializer what is not body exception','3001 localcalendar ctor uncheckedmktime observed success; 9999 initial CRT observed SystemException'],'noAdditionalNativeExecution':True,'naturalTokyoOnly':True})
new('native-capture-qualified.v4.json',{'status':'ACTUAL_CAPTURE_READER_QUALIFIED','outer':outer,'goSha256':sha(S/p['requiredGoFileName']),'authoritySha256':sha(S/'execution-authority.json'),'sourceManifestSha256':sha(S/p['sourceManifest']),'actualCounts':{'compile':1,'link':1,'nativeRuns':2,'rowsEach':126,'bodyEach':108,'excludedEach':18},'processProof':process,'stableRowsEqual':True,'ignoredOnly':list(p['stableCompareExclusions']),'candidateSha256':sha(S/'native-golden-candidate.v4.json'),'statisticsSha256':sha(S/'native-capture-statistics.v4.json'),'NativeReexecution':False,'productAdopted':False,'clockFullASTParserOptimizeQualified':False,'parentFieldMistakePythonNotStartedNotNativeRetry':True})
print(json.dumps({'status':'actual-capture-reader-qualified','functions':counts,'exceptionTypes':dict(collections.Counter(x['typeDisplay'] for x in exceptions)),'candidates':108,'noGoldenExcludes':18,'stableRowsEqual':True,'additionalNative':0}))
