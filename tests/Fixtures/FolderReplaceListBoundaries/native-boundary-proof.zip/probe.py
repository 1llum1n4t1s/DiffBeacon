import pathlib, json, sys, os, hashlib, subprocess, time
sys.dont_write_bytecode=True
ROOT=pathlib.Path(__file__).resolve().parent
BASE=pathlib.Path(r'D:\Dev\DiffBeacon\tests\Fixtures\LineTransformReplaceLists')
SUP=[]
for fn in ['ReplaceWithList','RegexReplaceWithList']:
 for name,src,fh in [('empty-utf8-e',{'type':'string','value':'é'},'09580a'),('empty-utf8-ae',{'type':'string','value':'aé'},'09580a'),('empty-ascii-ab',{'type':'string','value':'ab'},'09580a'),('nonempty-raw-c3',{'type':'raw','hex':'c3'},'6109580a'),('inline-string-raw-c3',{'type':'raw','hex':'c3'},None)]:
  SUP.append(dict(id=('literal' if fn=='ReplaceWithList' else 'regex')+'-'+name,function=fn,caseSensitive=True,args=[src,{'type':'path'} if fh else {'type':'array','value':[{'type':'array','value':[{'type':'string','value':'a'},{'type':'string','value':'X'}]}]}],fileUtf8Hex=fh,nullArgs=False))
(ROOT/'supplementary-cases.json').write_text(json.dumps(SUP,indent=2,ensure_ascii=True)+'\n',encoding='utf8')
script=(BASE/'capture.py').read_text(encoding='utf8')
script=script.replace('BASE=pathlib.Path(__file__).resolve().parent','BASE=pathlib.Path('+repr(str(BASE))+')\nSUPPLEMENTARY=pathlib.Path('+repr(str(ROOT/'supplementary-cases.json'))+')')
script=script.replace("t=n['type'];v=n.get('value')", "t=n['type'];v=n.get('value')\n if t=='raw':return 'new StringLiteral(bytes({'+','.join(str(x) for x in bytes.fromhex(n['hex']))+'}))'")
script=script.replace("cases=json.loads((BASE/'cases.json').read_bytes());lines=[]", "cases=json.loads((BASE/'cases.json').read_bytes())+json.loads(SUPPLEMENTARY.read_bytes());lines=[]")
script=script.replace("if (BASE/'golden.ndjson').exists() and not a.initial_observation:assert stdout==(BASE/'golden.ndjson').read_bytes()", "if (BASE/'golden.ndjson').exists() and not a.initial_observation:assert b''.join(stdout.splitlines(keepends=True)[:70])==(BASE/'golden.ndjson').read_bytes()\n write(out/'supplementary.ndjson',b''.join(stdout.splitlines(keepends=True)[70:]))")
script=script.replace("'caseCount=len(cases)'", "'caseCount=len(cases)'")
script=script.replace('import pathlib,json,hashlib,zipfile,subprocess,ctypes,datetime,argparse,os','import pathlib,json,hashlib,zipfile,subprocess,ctypes,datetime,argparse,os,time')
script=script.replace("started=datetime.datetime.now(datetime.timezone.utc).isoformat();proc=subprocess.Popen", "childStart=time.monotonic();started=datetime.datetime.now(datetime.timezone.utc).isoformat();proc=subprocess.Popen")
script=script.replace('receipt=dict(sourceCommit=COMMIT,','receipt=dict(elapsedSeconds=time.monotonic()-childStart,supplementaryCasesSha256=sha(SUPPLEMENTARY.read_bytes()),supplementaryCount=10,baselineCount=70,sourceCommit=COMMIT,')
(ROOT/'supplementary-capture.py').write_text(script,encoding='utf8')
compiler=r'C:\Program Files\Microsoft Visual Studio\18\Community\VC\Tools\MSVC\14.51.36231\bin\Hostx64\x64\cl.exe'
vcvars=str(ROOT/'sdk-env.cmd')
assert pathlib.Path(compiler).is_file() and pathlib.Path(vcvars).is_file()
for run in ['run1-sdk','run2-sdk']:
 t=time.monotonic()
 cp=subprocess.run([sys.executable,'-B',str(ROOT/'supplementary-capture.py'),'--output',str(ROOT/run),'--compiler',compiler,'--vcvars',vcvars],capture_output=True,timeout=300)
 (ROOT/(run+'-capture.stdout')).write_bytes(cp.stdout);(ROOT/(run+'-capture.stderr')).write_bytes(cp.stderr)
 print(json.dumps(dict(run=run,exitCode=cp.returncode,elapsedSeconds=time.monotonic()-t)),flush=True)
 if cp.returncode: print(cp.stderr.decode(errors='replace'));sys.exit(cp.returncode)
a=(ROOT/'run1-sdk/supplementary.ndjson').read_bytes();b=(ROOT/'run2-sdk/supplementary.ndjson').read_bytes();assert a==b
assert (ROOT/'run1-sdk/golden.ndjson').read_bytes()==(ROOT/'run2-sdk/golden.ndjson').read_bytes()
assert (ROOT/'run1-sdk/provenance.json').read_bytes()==(BASE/'provenance.json').read_bytes()
print(a.decode(),flush=True)
(ROOT/'comparison.json').write_text(json.dumps(dict(baselineCount=70,baselineAllBytesMatch=True,supplementaryCount=10,twoIndependentCompilesAllBytesMatch=True,unchangedProvenanceAllBytesMatch=True,supplementarySha256=hashlib.sha256(a).hexdigest()),indent=2)+'\n')