// Adapter boundary: host context and unreachable APIs are stubs; *.inc are original bytes.
// No provider-present behavior or original parser claim is made.
#define NOMINMAX
#include <algorithm>
#include <cctype>
#include <cstdint>
#include <functional>
#include <iostream>
#include <limits>
#include <memory>
#include <stdexcept>
#include <string>
#include <string_view>
#include <variant>
#include <vector>
[[noreturn]] void unsupported(){throw std::runtime_error("UNSUPPORTED_ADAPTER_REACHED");}
namespace Poco {
struct Timestamp{}; struct RegularExpression{};
std::string toLower(std::string s){for(auto& c:s)c=static_cast<char>(std::tolower(static_cast<unsigned char>(c)));return s;}
int icompare(const std::string&,const std::string&){unsupported();}
}
struct FileContentRef{}; struct ValueType2;
using ValueType=std::variant<std::monostate,bool,double,int64_t,Poco::Timestamp,std::shared_ptr<Poco::RegularExpression>,std::string,std::shared_ptr<FileContentRef>,std::shared_ptr<std::vector<ValueType2>>>;
struct ValueType2{ValueType value;};
struct DIFFITEM{}; struct FilterExpression;
struct Provider {
int GetLineCount()const{unsupported();} int GetColumnCount(int,int)const{unsupported();}
std::string GetLine(int,int)const{unsupported();} std::string GetColumn(int,int,int)const{unsupported();}
std::string GetColumns(int,int,const std::vector<int>&)const{unsupported();}
};
struct FilterEvalContext {const FilterExpression* expr=nullptr;const DIFFITEM* di=nullptr;const Provider* provider=nullptr;const void* sharedContext=nullptr;int lineIndex=-1;};
struct HostContext{int dirs;int GetCompareDirs()const{return dirs;}};
struct FilterExpression{HostContext* ctxt;bool caseSensitive=true;const Poco::Timestamp* now=nullptr;const Poco::Timestamp* today=nullptr;};
struct InvalidArgumentError:std::invalid_argument{using std::invalid_argument::invalid_argument;};
struct InvalidArgumentCountError:std::invalid_argument{using std::invalid_argument::invalid_argument;};
#include "ExprNode.inc"
#include "StringLiteral.inc"
#include "IntLiteral.inc"
#include "DoubleLiteral.inc"
#include "ArrayLiteral.inc"
struct RegularExpressionLiteral:ExprNode {ValueType Evaluate(const FilterEvalContext&)const override{unsupported();}};
struct DateTimeLiteral:ExprNode {ValueType Evaluate(const FilterEvalContext&)const override{unsupported();}};
#include "FunctionNode.inc"
void FunctionNode::SetPropFunc(int,int,bool){unsupported();}
struct FunctionInfo{std::function<ValueType(const FilterEvalContext&,std::vector<ExprNode*>*)> func;int minArgs,maxArgs;};
const FunctionInfo* findFunction(const std::string&){unsupported();}
template<class T> ExprNode* ReplaceFunctionWithLiteral(FunctionNode*,T){unsupported();}
bool IsArrayConst(std::vector<ExprNode*>*){unsupported();}
ValueType2 ExprNodeToValueType2(ExprNode*){unsupported();}
ExprNode* CreateLiteralFromArrayElement(FunctionNode*,const ValueType&){unsupported();}
bool OptimizeRegexArg(std::vector<ExprNode*>*,int,bool,bool=false){unsupported();}
namespace ucr {std::string toTString(const std::string& s){return s;}}
struct ReplaceList{
static std::shared_ptr<std::vector<ValueType2>> LoadList(const FilterExpression&,const std::string&){unsupported();}
static std::shared_ptr<std::vector<ValueType2>> LoadRegexList(const FilterExpression&,const std::string&){unsupported();}
};
#include "attribute-name.inc"
#include "column-helpers.inc"
#include "side-functions.inc"
#include "constructor.inc"
#include "destructor.inc"
#include "optimize.inc"
#include "evaluate.inc"
std::vector<int> trace,optimized;
// Preserve original StringLiteral dynamic_cast/value; observe runtime cache bypass.
struct TrackedStringLiteral:StringLiteral {
 int id;
 TrackedStringLiteral(int i,const std::string& value):StringLiteral(value),id(i){}
 ValueType Evaluate(const FilterEvalContext& context)const override {
  trace.push_back(id);return StringLiteral::Evaluate(context);
 }
};
struct Probe:ExprNode {
 int id;std::string type,text;bool fail;
 Probe(int i,std::string t,std::string v,bool f):id(i),type(t),text(v),fail(f){}
 ExprNode* Optimize()override{optimized.push_back(id);return this;}
 ValueType Evaluate(const FilterEvalContext&)const override{
  trace.push_back(id);if(fail)throw std::runtime_error("probe throw");
  if(type=="none")return std::monostate{};if(type=="bool")return true;if(type=="double")return 1.0;
  if(type=="timestamp")return Poco::Timestamp{};
  if(type=="regex")return std::shared_ptr<Poco::RegularExpression>{};
  if(type=="file")return std::shared_ptr<FileContentRef>{};
  if(type=="array")return std::make_shared<std::vector<ValueType2>>();
  if(type=="string"||type=="empty-string")return text;
  return static_cast<int64_t>(std::stoll(text));
 }
};
struct Spec{std::string kind,type,text;};
std::string quote(const std::string& s){std::string o="\"";for(unsigned char c:s){if(c=='"'||c=='\\'){o+='\\';o+=c;}else if(c=='\n')o+="\\n";else if(c=='\r')o+="\\r";else if(c=='\t')o+="\\t";else if(c<32)unsupported();else o+=c;}return o+'"';}
std::string serialize(const ValueType& v){
 if(std::holds_alternative<std::monostate>(v))return "{\"kind\":\"none\"}";
 if(auto s=std::get_if<std::string>(&v))return "{\"kind\":\"string\",\"text\":"+quote(*s)+"}";
 if(auto a=std::get_if<std::shared_ptr<std::vector<ValueType2>>>(&v)){std::string o="{\"kind\":\"array\",\"items\":[";for(size_t i=0;i<(*a)->size();++i){if(i)o+=',';o+=serialize((**a)[i].value);}return o+"]}";}
 unsupported();
}
std::string ints(const std::vector<int>& a){std::string o="[";for(size_t i=0;i<a.size();++i){if(i)o+=',';o+=std::to_string(a[i]);}return o+"]";}
void Run(std::string id,int dirs,std::string name,bool opt,std::initializer_list<Spec> specs){
 HostContext host{dirs};FilterExpression expr{&host};FilterEvalContext ctx{&expr};
 auto args=new std::vector<ExprNode*>;int i=0;
 for(const auto& s:specs){
  if(s.kind=="constant")args->push_back(new TrackedStringLiteral(i,s.text));
  else if(s.kind=="nested-invalid-range"){auto nested=new std::vector<ExprNode*>{new StringLiteral(s.text)};args->push_back(new FunctionNode(&expr,"columnrange",nested));}
  else args->push_back(new Probe(i,s.type,s.text,s.kind=="throw"));++i;
 }
 trace.clear();optimized.clear();std::string phase="constructor",error,errorKind,result="null";FunctionNode* node=nullptr;
 try{node=new FunctionNode(&expr,name,args);phase="optimize";if(opt)node->Optimize();phase="evaluate";result=serialize(node->Evaluate(ctx));phase="complete";}
 catch(const InvalidArgumentCountError& e){error=e.what();errorKind="InvalidArgumentCount";}
 catch(const InvalidArgumentError& e){error=e.what();errorKind="InvalidArgument";}
 catch(const std::exception& e){error=e.what();errorKind="RuntimeError";}
 if(node)delete node;else{for(auto p:*args)delete p;delete args;}
 std::cout<<"{\"id\":"<<quote(id)<<",\"phase\":"<<quote(phase)<<",\"errorKind\":"<<quote(errorKind)<<",\"error\":"<<quote(error)<<",\"value\":"<<result<<",\"trace\":"<<ints(trace)<<",\"optimizeTrace\":"<<ints(optimized)<<",\"context\":{\"dirs\":"<<dirs<<",\"providerNull\":true,\"sharedContextNull\":true,\"lineIndex\":-1}}\n";
}
int main(){
#include "cases.inc"
}
