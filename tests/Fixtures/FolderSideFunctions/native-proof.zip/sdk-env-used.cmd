@echo off
rem Environment inherited from run-native.ps1 process-local VsDevShell; no global changes.
exit /b 0
