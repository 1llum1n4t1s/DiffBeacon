"""Independent Python reader. Expected values derive only from frozen case inputs."""
import pathlib,json,hashlib
R=pathlib.Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
REQUIRED_INPUTS=frozenset(('adapter.cpp','ArrayLiteral.inc','attribute-name.inc','cases.inc','column-helpers.inc','constructor.inc','destructor.inc','DoubleLiteral.inc','evaluate.inc','ExprNode.inc','FunctionNode.inc','IntLiteral.inc','optimize.inc','side-functions.inc','StringLiteral.inc'))
def read(n):return json.loads((R/n).read_bytes())
def reconstruct_calls(cases):
 calls=[]
 for c in cases:
  specs=','.join('{'+','.join(json.dumps(a[k],ensure_ascii=True) for k in ('kind','type','text'))+'}' for a in c['args'])
  calls.append('Run('+','.join([json.dumps(c['id']),str(c['dirs']),json.dumps(c['name']),'true' if c['optimize'] else 'false','{'+specs+'}'])+');')
 return ('\n'.join(calls)+'\n').encode('utf8')
def validate_calls(cases,inc):
 assert len(cases)==2416 and len({c['id'] for c in cases})==2416,'case count or unique ID coverage differs'
 suffixes=('lineat','lineoffsetat','column','columnrange','columnat','columnoffsetat')
 actual={(c['dirs'],c['name'],c['optimize']) for c in cases}
 desired={(d,p+s,o) for d in (2,3) for p in ('','left','middle','right') for s in suffixes for o in (False,True)}
 assert actual==desired,'function/side/directory/optimization coverage differs'
 assert all(c['name'] in tuple(p+c['suffix'] for p in ('','left','middle','right')) and c['suffix'] in suffixes for c in cases)
 assert inc==reconstruct_calls(cases),'cases.inc differs from all reconstructed JSON calls'
def validate_input_hashes(record,required_hashes):
 assert set(record)==REQUIRED_INPUTS,'compile receipt required input fileset differs'
 assert set(required_hashes)==REQUIRED_INPUTS,'fixed preparation fileset differs'
 assert record==required_hashes,'compile input hashes differ from fixed preparation'
def validate_prepared_inputs():
 cases=read('cases.json');validate_calls(cases,(R/'cases.inc').read_bytes())
 fixed=read('prepared-inputs.json')
 actual={f:sha((R/f).read_bytes()) for f in REQUIRED_INPUTS}
 validate_input_hashes(actual,fixed['inputSha256'])
 assert fixed['casesSha256']==sha((R/'cases.json').read_bytes())
 assert fixed['sourceManifestSha256']==sha((R/'source-manifest.json').read_bytes())
 return cases,actual
def expected(c):
 arity=2 if c['suffix'] in ('columnat','columnoffsetat') else 1
 if len(c['args'])!=arity:return 'constructor','InvalidArgumentCount',None,[],[]
 optimized=[i for i,a in enumerate(c['args']) if a['kind'] in ('probe','throw')] if c['optimize'] else []
 if c['optimize'] and any(a['kind']=='nested-invalid-range' for a in c['args']):
  # Optimize aborts at the nested argument; later arguments are not optimized.
  at=next(i for i,a in enumerate(c['args']) if a['kind']=='nested-invalid-range')
  return 'optimize','InvalidArgument',None,[],[i for i in optimized if i<at]
 count=c['dirs'] if c['name']==c['suffix'] else 1
 if c['suffix'] in ('lineat','lineoffsetat','columnat','columnoffsetat'):
  v=dict(kind='none');return 'complete','',dict(kind='array',items=[v]*count) if count>1 else v,[],optimized
 a=c['args'][0];trace=[0]
 if c['suffix']=='column':
  if a['kind']=='throw':return 'evaluate','RuntimeError',None,trace,optimized
  valid=a['type'] in ('string','empty-string','one','int-max')
  if not valid:return 'evaluate','InvalidArgument',None,trace,optimized
  v=dict(kind='none')
 else:
  text=a['text'];valid=a['type']=='string' and text in ['1','!1','2-3','4-','!1,2-3,4-','1,1,2-3','  ! 1 , 2 - 3 , 4 -  ']
  if not valid:return ('optimize' if c['optimize'] and a['kind']=='constant' else 'evaluate'),'InvalidArgument',None,([] if c['optimize'] and a['kind']=='constant' else trace),optimized
  v=dict(kind='string',text='')
  if c['optimize'] and a['kind']=='constant':trace=[]
 return 'complete','',dict(kind='array',items=[v]*count) if count>1 else v,trace*count,optimized
def main():
 m=read('source-manifest.json')
 for e in m['sources']:
  b=(R/(pathlib.Path(e['path']).name+'.original')).read_bytes();assert sha(b)==e['sha256']
  assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==e['blob']
 for e in m['extractions']:
  original=(R/(pathlib.Path(e['path']).name+'.original')).read_bytes()[e['startByte']:e['endByte']]
  assert sha(original)==e['sha256'] and (R/e['file']).read_bytes()==original+(b'\n' if e.get('outerLf') else b'')
 assert sha((R/'COPYING').read_bytes())==m['license']['sha256']
 cases,fixed_inputs=validate_prepared_inputs();out=[]
 for run in ('run1','run2'):
  receipt=read(run+'-receipt.json');comp=read(run+'-compile-receipt.json')
  assert comp['exitCode']==0 and not comp['timeout'] and comp['stdoutEof'] and comp['stderrEof']
  assert receipt['exitCode']==0 and not receipt['timeout'] and receipt['heldProcessHandleSignaled'] and receipt['stdoutEof'] and receipt['stderrEof']
  data=(R/(run+'-golden.ndjson')).read_bytes();out.append(data)
  assert sha(data)==receipt['stdoutSha256'] and sha((R/(run+'.exe')).read_bytes())==receipt['executableSha256']
  assert sha((R/'cases.json').read_bytes())==receipt['casesSha256']
  assert (R/(run+'-reference.stderr')).read_bytes()==b''
  validate_input_hashes(comp['inputSha256'],fixed_inputs)
  rows=[json.loads(x) for x in data.splitlines()];assert len(rows)==len(cases)
  for c,g in zip(cases,rows):
   phase,error,v,trace,opt=expected(c)
   assert g['id']==c['id'] and (g['phase'],g['errorKind'],g['value'],g['trace'],g['optimizeTrace'])==(phase,error,v,trace,opt),(c,g,expected(c))
   assert g['context']==dict(dirs=c['dirs'],providerNull=True,sharedContextNull=True,lineIndex=-1)
   assert 'UNSUPPORTED_ADAPTER_REACHED' not in g['error']
 assert out[0]==out[1]
 result=dict(passed=True,cases=len(cases),independentCompiles=2,independentChildren=2,originalConstructor=True,originalOptimize=True,originalEvaluate=True,providerPresent=False,parserExecuted=False)
 (R/'verification.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(json.dumps(result))
if __name__=='__main__':main()
