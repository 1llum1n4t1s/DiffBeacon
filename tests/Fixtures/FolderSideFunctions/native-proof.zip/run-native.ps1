$ErrorActionPreference = 'Stop'
$root = 'D:\Codex\DiffBeacon\folder-side-functions-20261023-native01'
if ([IO.Path]::GetFullPath($root) -cne $root) { throw 'Unexpected root' }
$cursor = $root
while ($cursor) {
    $item = Get-Item -LiteralPath $cursor -Force
    if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Reparse path: $cursor" }
    $cursor = Split-Path -Parent $cursor
}
$tempRoot = Join-Path $root 'temp'
if (-not (Test-Path -LiteralPath $tempRoot)) { New-Item -ItemType Directory -Path $tempRoot | Out-Null }
if ((Get-Item -LiteralPath $tempRoot -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Reparse temp' }
$env:TEMP=$tempRoot
$env:TMP=$tempRoot
$env:TMPDIR=$tempRoot
$vsRoot='C:\Program Files\Microsoft Visual Studio\18\Community'
Import-Module (Join-Path $vsRoot 'Common7\Tools\Microsoft.VisualStudio.DevShell.dll')
$env:WindowsSdkDir='C:\Program Files (x86)\Windows Kits\10\'
$env:WindowsSDKVersion='10.0.28000.0\'
Enter-VsDevShell -VsInstallPath $vsRoot -SkipAutomaticLocation -DevCmdArguments '-arch=x64 -host_arch=x64 -winsdk=none' | Out-Null
$msvc=Join-Path $vsRoot 'VC\Tools\MSVC\14.51.36231'
$sdk='C:\Program Files (x86)\Windows Kits\10'
$env:INCLUDE="${msvc}\include;${sdk}\Include\10.0.28000.0\ucrt;${sdk}\Include\10.0.28000.0\shared;${sdk}\Include\10.0.28000.0\um;${sdk}\Include\10.0.28000.0\winrt"
$env:LIB="${msvc}\lib\x64;${sdk}\Lib\10.0.28000.0\ucrt\x64;${sdk}\Lib\10.0.28000.0\um\x64"
$env:PATH="${msvc}\bin\Hostx64\x64;${sdk}\bin\10.0.28000.0\x64;C:\Windows\System32;C:\Windows"
[IO.File]::WriteAllText((Join-Path $root 'sdk-process-env.cmd'), "@echo off`r`nrem Environment inherited from run-native.ps1 process-local VsDevShell; no global changes.`r`nexit /b 0`r`n")
$record=[ordered]@{VsInstallPath=$vsRoot;SDK='10.0.28000.0';INCLUDE=$env:INCLUDE;LIB=$env:LIB;PATH=$env:PATH;TEMP=$env:TEMP;TMP=$env:TMP;TMPDIR=$env:TMPDIR}
[IO.File]::WriteAllText((Join-Path $root 'process-environment.json'), ($record | ConvertTo-Json))
$python='C:\Users\IMT\AppData\Roaming\uv\python\cpython-3.14-windows-x86_64-none\python.exe'
& $python -E -B -X utf8 (Join-Path $root 'capture.py') --capture --compiler (Join-Path $msvc 'bin\Hostx64\x64\cl.exe') --sdk-env (Join-Path $root 'sdk-process-env.cmd')
if ($LASTEXITCODE -ne 0) { throw "native capture failed: $LASTEXITCODE" }
& $python -E -B -X utf8 (Join-Path $root 'verify.py')
if ($LASTEXITCODE -ne 0) { throw "native reader failed: $LASTEXITCODE" }
