"""Explicit opt-in only. Do not invoke while parent AOT/GUI validation is running."""
import argparse, pathlib, os, json, hashlib, subprocess, time, datetime, ctypes
import verify
R=pathlib.Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(n,b):(R/n).write_bytes(b if isinstance(b,bytes) else (json.dumps(b,indent=2)+'\n').encode())
def main():
 p=argparse.ArgumentParser();p.add_argument('--capture',action='store_true',required=True);p.add_argument('--compiler',type=pathlib.Path,required=True);p.add_argument('--sdk-env',type=pathlib.Path,required=True);a=p.parse_args()
 assert a.compiler.is_absolute() and a.sdk_env.is_absolute()
 assert not any(R.glob('run*-receipt.json')) and not any(R.glob('run*.exe')),'Capture is single-use; preserve prior evidence'
 temp=R/'temp';temp.mkdir(exist_ok=True)
 env=dict(os.environ,TEMP=str(temp),TMP=str(temp),TMPDIR=str(temp))
 _,inputs=verify.validate_prepared_inputs()
 put('sdk-env-used.cmd',a.sdk_env.read_bytes())
 class FT(ctypes.Structure):_fields_=[('low',ctypes.c_uint32),('high',ctypes.c_uint32)]
 for run in ('run1','run2'):
  args=['/nologo','/utf-8','/std:c++20','/EHsc','/O2','/Fe:'+str(R/(run+'.exe')),'/Fo:'+str(R/(run+'.obj')),str(R/'adapter.cpp')]
  put(run+'-compile.rsp','\n'.join('"'+s+'"' for s in args).encode())
  cmd='@echo off\ncall "'+str(a.sdk_env)+'" >nul\nif errorlevel 1 exit /b %errorlevel%\n"'+str(a.compiler)+'" @"'+str(R/(run+'-compile.rsp'))+'"\nexit /b %errorlevel%\n'
  put(run+'-compile.cmd',cmd.encode());start=time.monotonic()
  try:cp=subprocess.run(['cmd.exe','/d','/c',str(R/(run+'-compile.cmd'))],cwd=R,env=env,capture_output=True,timeout=120)
  except subprocess.TimeoutExpired as ex:
   put(run+'-compile.stdout',ex.stdout or b'');put(run+'-compile.stderr',ex.stderr or b'')
   put(run+'-compile-receipt.json',dict(exitCode=None,timeout=True,stdoutEof=False,stderrEof=False,elapsedSeconds=time.monotonic()-start,inputSha256=inputs));raise
  put(run+'-compile.stdout',cp.stdout);put(run+'-compile.stderr',cp.stderr)
  put(run+'-compile-receipt.json',dict(exitCode=cp.returncode,timeout=False,stdoutEof=True,stderrEof=True,elapsedSeconds=time.monotonic()-start,compilerSha256=sha(a.compiler.read_bytes()),sdkEnvSha256=sha(a.sdk_env.read_bytes()),inputSha256=inputs,arguments=args,TEMP=str(temp),TMP=str(temp),TMPDIR=str(temp),PATH=env.get('PATH','')))
  assert cp.returncode==0,'compile failed: '+run
  started=datetime.datetime.now(datetime.timezone.utc).isoformat();start=time.monotonic()
  proc=subprocess.Popen([str(R/(run+'.exe'))],cwd=R,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  ft=[FT() for _ in range(4)];handle=ctypes.c_void_p(int(proc._handle))
  assert ctypes.windll.kernel32.GetProcessTimes(handle,*[ctypes.byref(t) for t in ft])
  timed=False
  try:out,err=proc.communicate(timeout=30)
  except subprocess.TimeoutExpired:timed=True;proc.kill();out,err=proc.communicate(timeout=10)
  signaled=ctypes.windll.kernel32.WaitForSingleObject(handle,0)==0
  put(run+'-golden.ndjson',out);put(run+'-reference.stderr',err)
  put(run+'-receipt.json',dict(pid=proc.pid,birthFileTime=(ft[0].high<<32)|ft[0].low,heldProcessHandleSignaled=signaled,startedUtc=started,endedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsedSeconds=time.monotonic()-start,exitCode=proc.returncode,timeout=timed,stdoutEof=True,stderrEof=True,stdoutSha256=sha(out),stderrSha256=sha(err),executableSha256=sha((R/(run+'.exe')).read_bytes()),casesSha256=sha((R/'cases.json').read_bytes())))
  assert proc.returncode==0 and signaled and not timed and not err
 print('Captured two independent compilations and child runs. Run verify.py separately.')
if __name__=='__main__':main()
