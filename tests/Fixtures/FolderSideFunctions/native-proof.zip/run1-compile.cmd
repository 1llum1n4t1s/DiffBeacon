@echo off
call "D:\Codex\DiffBeacon\folder-side-functions-20261023-native01\sdk-process-env.cmd" >nul
if errorlevel 1 exit /b %errorlevel%
"C:\Program Files\Microsoft Visual Studio\18\Community\VC\Tools\MSVC\14.51.36231\bin\Hostx64\x64\cl.exe" @"D:\Codex\DiffBeacon\folder-side-functions-20261023-native01\run1-compile.rsp"
exit /b %errorlevel%
