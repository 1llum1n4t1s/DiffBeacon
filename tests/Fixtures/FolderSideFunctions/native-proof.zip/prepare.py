import pathlib, json, hashlib, zipfile
R=pathlib.Path(__file__).resolve().parent
REPO=pathlib.Path(r'D:\Dev\DiffBeacon')
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(n,v):
    (R/n).write_bytes(v if isinstance(v,bytes) else v.encode('utf8'))
def js(n,v):write(n,json.dumps(v,ensure_ascii=False,indent=2)+'\n')
base=REPO/'tests/Fixtures/LineTransformAggregates'
manifest=json.loads((base/'source-manifest.json').read_bytes())
archive=REPO/'tests/Fixtures/LineTransformReplace/reference-source.zip'
assert sha(archive.read_bytes())==manifest['reusedArchiveSha256']
sources={}; spans=[]
with zipfile.ZipFile(archive) as z:
    for entry in manifest['sources']:
        p=entry['path']
        if p not in ['Src/FilterEngine/FilterExpressionNodes.cpp','Src/FilterEngine/FilterExpressionNodes.h']:continue
        b=z.read('original/'+p)
        assert sha(b)==entry['sha256']
        assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==entry['blob']
        sources[p]=b
        write(pathlib.Path(p).name+'.original',b)
cpp=sources['Src/FilterEngine/FilterExpressionNodes.cpp']
def lines(name,a,b):
    data=cpp.splitlines(keepends=True); start=sum(map(len,data[:a-1])); end=sum(map(len,data[:b]))
    body=cpp[start:end]; write(name,body)
    spans.append(dict(file=name,path='Src/FilterEngine/FilterExpressionNodes.cpp',startLine=a,endLine=b,startByte=start,endByte=end,sha256=sha(body)))
lines('column-helpers.inc',1408,1441)
lines('attribute-name.inc',1507,1518)
lines('side-functions.inc',3877,4219)
lines('constructor.inc',4221,4283)
lines('destructor.inc',4285,4295)
lines('optimize.inc',4297,4488)
lines('evaluate.inc',4490,4493)
h=sources['Src/FilterEngine/FilterExpressionNodes.h']
for name in ['ExprNode','FunctionNode','StringLiteral','IntLiteral','DoubleLiteral','ArrayLiteral']:
    a=h.index(('struct '+name+'\n').encode()) if ('struct '+name+'\n').encode() in h else h.index(('struct '+name+' ').encode())
    b=h.index(b'\n};',a)+3
    body=h[a:b]+b'\n';write(name+'.inc',body)
    spans.append(dict(file=name+'.inc',path='Src/FilterEngine/FilterExpressionNodes.h',startByte=a,endByte=b,sha256=sha(h[a:b]),outerLf=True))
license_path=REPO/'tests/Fixtures/FolderSubstrOracle/original/COPYING'
write('COPYING',license_path.read_bytes())
js('source-manifest.json',dict(commit=manifest['commit'],archiveSha256=sha(archive.read_bytes()),sources=[e for e in manifest['sources'] if e['path'] in sources],extractions=spans,license=dict(id='GPL-2.0',file='COPYING',sha256=sha(license_path.read_bytes()))))
js('status.json',dict(status='PREPARED_NOT_CAPTURED',nativeCompileExecuted=False,nativeChildExecuted=False,constructorExecution='unverified',optimizeExecution='unverified',evaluateExecution='unverified',providerPresent='out of scope; narrowing behavior unverified'))

# Failure inputs are frozen before any C++ compilation or child execution.
typed=[('none','none'),('bool','true'),('double','1.0'),('int-min','-9223372036854775808'),('negative','-1'),('zero','0'),('one','1'),('int-max','2147483647'),('int-over','2147483648'),('int64-max','9223372036854775807'),('string','header'),('empty-string',''),('timestamp','timestamp'),('regex','regex'),('file','file'),('array','array')]
ranges=['1','!1','2-3','4-','!1,2-3,4-','1,1,2-3','  ! 1 , 2 - 3 , 4 -  ','','1,','0','3-2','2147483648','999999999999999999999999999999','1 x','!','1,,2']
cases=[]
for dirs in (2,3):
 for prefix in ('','left','middle','right'):
  for opt in (False,True):
   for suffix,arity in [('lineat',1),('lineoffsetat',1),('column',1),('columnrange',1),('columnat',2),('columnoffsetat',2)]:
    common=dict(dirs=dirs,name=prefix+suffix,optimize=opt,suffix=suffix)
    def add(label,args):cases.append(dict(id=f'c{len(cases):05}',label=label,args=args,**common))
    for count in range(arity+2):
     if count!=arity:add('wrong-arity',[dict(kind='probe',type='one',text='1')]*count)
    if suffix=='columnrange':
     for text in ranges:
      for kind in ('probe','constant'):add('range-'+kind,[dict(kind=kind,type='string',text=text)])
     for typ,text in typed:
      if typ not in ('string','empty-string'):add('range-type',[dict(kind='probe',type=typ,text=text)])
    elif suffix=='column':
     for typ,text in typed:add('column-type',[dict(kind='probe',type=typ,text=text)])
     add('column-throw',[dict(kind='throw',type='none',text='')])
    else:
     for typ,text in typed:add('guard-type',[dict(kind='probe',type=typ,text=text)]*arity)
     add('guard-throw',[dict(kind='throw',type='none',text='')]*arity)
     for index in range(arity):
      args=[dict(kind='probe',type='one',text='1') for _ in range(arity)]
      args[index]=dict(kind='nested-invalid-range',type='string',text='0')
      add('optimize-before-guard',args)
js('cases.json',cases)
calls=[]
for c in cases:
    specs=','.join('{'+','.join(json.dumps(a[k],ensure_ascii=True) for k in ('kind','type','text'))+'}' for a in c['args'])
    calls.append('Run('+','.join([json.dumps(c['id']),str(c['dirs']),json.dumps(c['name']),'true' if c['optimize'] else 'false','{'+specs+'}'])+');')
write('cases.inc','\n'.join(calls)+'\n')
js('failure-matrix.json',dict(fixedBeforeCapture=True,dirs=[2,3],prefixes=['','left','middle','right'],optimization=[False,True],exactArity=True,types=[x[0] for x in typed],ranges=ranges,probes=['trace','throw','nested-invalid-range','TrackedStringLiteral runtime Evaluate'],expectedBoundaries=['At provider guard skips runtime children','all children Optimize before provider guard','Column child reevaluated per side','Range valid is empty string, not none','valid constant Range runtime trace is side count without Optimize and empty with Optimize; native observation pending'],caseCount=len(cases)))
# Compile closure is explicitly enumerated; mutation fixtures are never compiled.
required=('adapter.cpp','ArrayLiteral.inc','attribute-name.inc','cases.inc','column-helpers.inc','constructor.inc','destructor.inc','DoubleLiteral.inc','evaluate.inc','ExprNode.inc','FunctionNode.inc','IntLiteral.inc','optimize.inc','side-functions.inc','StringLiteral.inc')
js('prepared-inputs.json',dict(inputSha256={f:sha((R/f).read_bytes()) for f in required},casesSha256=sha((R/'cases.json').read_bytes()),sourceManifestSha256=sha((R/'source-manifest.json').read_bytes())))
print(json.dumps(dict(prepared=True,caseCount=len(cases),sourceCppSha256=sha(cpp),compileExecuted=False)))
