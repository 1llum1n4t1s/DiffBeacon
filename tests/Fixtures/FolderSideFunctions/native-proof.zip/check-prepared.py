"""Python-only integrity/mutation checks; never executes native code or compiler."""
import ast,hashlib,json,pathlib,verify
R=pathlib.Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(n,obj):(R/n).write_text(json.dumps(obj,indent=2)+'\n',encoding='utf8')
def must_reject(action):
 try:action()
 except AssertionError as ex:return str(ex)
 raise AssertionError('mutation was accepted')
cases,inputs=verify.validate_prepared_inputs()
original=(R/'cases.inc').read_bytes()
assert b'"middlelineat"' in original
mutation=original.replace(b'"middlelineat"',b'"rightlineat"',1)
(R/'reader-cases-middle-right-mutation.txt').write_bytes(mutation)
call_rejection=must_reject(lambda:verify.validate_calls(cases,mutation))
missing=dict(inputs);del missing['side-functions.inc']
put('reader-missing-input-mutation.json',dict(purpose='intentional reader test; NOT a native compile receipt',inputSha256=missing))
input_rejection=must_reject(lambda:verify.validate_input_hashes(missing,inputs))
for c in cases:verify.expected(c)
cache_cases=[c for c in cases if c['suffix']=='columnrange' and c['label']=='range-constant' and c['args'][0]['text']=='1']
assert len(cache_cases)==16
for c in cache_cases:
 count=c['dirs'] if c['name']=='columnrange' else 1
 assert verify.expected(c)[3]==([] if c['optimize'] else [0]*count)
before={e['file']:e['sha256'] for e in json.loads((R/'review-before-inputs.json').read_bytes())}
after={p.name:sha(p.read_bytes()) for p in R.iterdir() if p.is_file()}
source_files=[f for f in before if f.endswith('.inc') or f.endswith('.original') or f in ('COPYING','source-manifest.json','cases.json')]
assert all(after[f]==before[f] for f in source_files),'source proof/cases changed'
syntax=[]
for p in R.glob('*.py'):ast.parse(p.read_text(encoding='utf8'),filename=str(p));syntax.append(p.name)
result=dict(pythonOnly=True,caseCount=len(cases),callMutationRejected=call_rejection,missingCompileInputRejected=input_rejection,cacheExpectedTracePairs=8,sourceProofAndCasesUnchanged=source_files,changedExistingFiles=[f for f in before if after.get(f)!=before[f]],pythonSyntaxPassed=syntax,nativeCompileExecuted=False,nativeChildExecuted=False)
put('review-reader-checks.json',result)
print(json.dumps(result))
