import pathlib,json,hashlib,zipfile
import verify
R=pathlib.Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(n,x):(R/n).write_text(json.dumps(x,indent=2)+'\n',encoding='utf8')
cases,inputs=verify.validate_prepared_inputs()
assert json.loads((R/'verification.json').read_bytes())['passed']
summary=dict(passed=True,rowsPerChild=len(cases),independentCompiles=2,independentChildren=2,compileExitCodes=[],childExitCodes=[],outputSha256=[],allCompileInputsUnchanged=True,sourceManifestSha256=sha((R/'source-manifest.json').read_bytes()),providerPresent=False,parserExecuted=False)
for run in ('run1','run2'):
 c=json.loads((R/(run+'-compile-receipt.json')).read_bytes());g=json.loads((R/(run+'-receipt.json')).read_bytes())
 verify.validate_input_hashes(c['inputSha256'],inputs)
 summary['compileExitCodes'].append(c['exitCode']);summary['childExitCodes'].append(g['exitCode']);summary['outputSha256'].append(g['stdoutSha256'])
summary['allStdoutBytesMatch']=(R/'run1-golden.ndjson').read_bytes()==(R/'run2-golden.ndjson').read_bytes()
summary['nativeCacheTraceSamples']=[]
rows={r['id']:r for r in map(json.loads,(R/'run1-golden.ndjson').read_bytes().splitlines())}
for c in cases:
 if c['suffix']=='columnrange' and c['label']=='range-constant' and c['args'][0]['text']=='1':summary['nativeCacheTraceSamples'].append(dict(id=c['id'],dirs=c['dirs'],name=c['name'],optimize=c['optimize'],trace=rows[c['id']]['trace']))
put('capture-final-integrity.json',summary)
assert not (R/'native-proof.zip').exists(),'Never overwrite evidence archive'
excluded={'native-proof.zip','native-proof-manifest.json','proof-receipt.json'}
files=sorted(p for p in R.rglob('*') if p.is_file() and p.name not in excluded)
entries=[dict(path=p.relative_to(R).as_posix(),size=p.stat().st_size,sha256=sha(p.read_bytes())) for p in files]
put('native-proof-manifest.json',dict(entries=entries,sourceManifestSha256=summary['sourceManifestSha256'],license='GPL-2.0',nativeVerified=True))
with zipfile.ZipFile(R/'native-proof.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files+[R/'native-proof-manifest.json']:z.write(p,p.relative_to(R).as_posix())
with zipfile.ZipFile(R/'native-proof.zip') as z:
 assert z.testzip() is None
 for e in entries:
  b=z.read(e['path']);assert len(b)==e['size'] and sha(b)==e['sha256']
 assert z.read('native-proof-manifest.json')==(R/'native-proof-manifest.json').read_bytes()
put('proof-receipt.json',dict(archive='native-proof.zip',sha256=sha((R/'native-proof.zip').read_bytes()),entryCount=len(entries)+1,allEntrySizeAndShaVerified=True,nativeSummary=summary))
print(json.dumps(dict(passed=True,rowsPerChild=len(cases),archiveSha256=sha((R/'native-proof.zip').read_bytes()),entryCount=len(entries)+1,allEntrySizeAndShaVerified=True)))
